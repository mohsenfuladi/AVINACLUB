<?php
/**
 * User Controller
 * Handles user management operations (CRUD)
 */

require_once '../helpers/response.php';
require_once '../helpers/security.php';
require_once '../models/User.php';

class UserController {
    
    private $db;
    private $userModel;
    
    public function __construct($database) {
        $this->db = $database;
        $this->userModel = new User($database);
    }
    
    public function list() {
        $filters = [];
        
        // Get filters from request
        if (isset($_GET['role'])) {
            $filters['role'] = Security::sanitize($_GET['role']);
        }
        
        if (isset($_GET['status'])) {
            $filters['status'] = Security::sanitize($_GET['status']);
        }
        
        if (isset($_GET['search'])) {
            $filters['search'] = Security::sanitize($_GET['search']);
        }
        
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $perPage = isset($_GET['per_page']) ? (int)$_GET['per_page'] : 20;
        
        $result = $this->userModel->list($filters, $page, $perPage);
        
        Response::success([
            'users' => $result['data'],
            'pagination' => [
                'total' => $result['total'],
                'page' => $result['page'],
                'per_page' => $result['per_page'],
                'total_pages' => $result['total_pages']
            ]
        ]);
    }
    
    public function create() {
        $data = Request::getJsonInput();
        
        // Validate required fields
        $required = ['username', 'email', 'password', 'full_name'];
        $validation = Request::validateRequired($data, $required);
        
        if (!$validation['valid']) {
            Response::validationError('فیلدهای الزامی: ' . implode(', ', $validation['missing']));
        }
        
        // Sanitize input
        $username = Security::sanitize($data['username']);
        $email = Security::sanitize($data['email']);
        $password = $data['password'];
        $full_name = Security::sanitize($data['full_name']);
        $role = isset($data['role']) ? Security::sanitize($data['role']) : 'user';
        $status = isset($data['status']) ? Security::sanitize($data['status']) : 'active';
        
        // Validate email format
        if (!Security::isValidEmail($email)) {
            Response::validationError('ایمیل نامعتبر است');
        }
        
        // Validate password strength
        if (strlen($password) < 6) {
            Response::validationError('رمز عبور باید حداقل 6 کاراکتر باشد');
        }
        
        // Validate role
        $validRoles = ['admin', 'manager', 'user', 'viewer'];
        if (!in_array($role, $validRoles)) {
            Response::validationError('نقش نامعتبر است');
        }
        
        // Validate status
        $validStatuses = ['active', 'inactive', 'suspended'];
        if (!in_array($status, $validStatuses)) {
            Response::validationError('وضعیت نامعتبر است');
        }
        
        // Check if username or email already exists
        if ($this->userModel->exists($username, $email)) {
            Response::error('نام کاربری یا ایمیل قبلاً ثبت شده است', 409);
        }
        
        // Create user data
        $userData = [
            'username' => $username,
            'email' => $email,
            'password' => Security::hashPassword($password),
            'full_name' => $full_name,
            'role' => $role,
            'status' => $status,
            'avatar' => $data['avatar'] ?? null,
            'phone' => isset($data['phone']) ? Security::sanitize($data['phone']) : null,
            'mobile' => isset($data['mobile']) ? Security::sanitize($data['mobile']) : null,
            'address' => isset($data['address']) ? Security::sanitize($data['address']) : null,
            'bio' => isset($data['bio']) ? Security::sanitize($data['bio']) : null,
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        $userId = $this->userModel->create($userData);
        
        if (!$userId) {
            Response::error('خطا در ایجاد کاربر', 500);
        }
        
        // Get created user
        $createdUser = $this->userModel->findById($userId);
        
        Response::success([
            'user' => [
                'id' => $createdUser['id'],
                'username' => $createdUser['username'],
                'email' => $createdUser['email'],
                'full_name' => $createdUser['full_name'],
                'role' => $createdUser['role'],
                'status' => $createdUser['status'],
                'avatar' => $createdUser['avatar'],
                'phone' => $createdUser['phone'],
                'mobile' => $createdUser['mobile'],
                'address' => $createdUser['address'],
                'bio' => $createdUser['bio'],
                'created_at' => $createdUser['created_at']
            ]
        ], 'کاربر با موفقیت ایجاد شد', 201);
    }
    
    public function update($id) {
        $data = Request::getJsonInput();
        
        // Check if user exists
        $existingUser = $this->userModel->findById($id);
        if (!$existingUser) {
            Response::error('کاربر یافت نشد', 404);
        }
        
        // Prepare update data
        $updateData = [];
        
        if (isset($data['full_name'])) {
            $updateData['full_name'] = Security::sanitize($data['full_name']);
        }
        
        if (isset($data['email'])) {
            $email = Security::sanitize($data['email']);
            if (!Security::isValidEmail($email)) {
                Response::validationError('ایمیل نامعتبر است');
            }
            
            // Check if email is already taken by another user
            if ($this->userModel->emailExists($email, $id)) {
                Response::error('ایمیل قبلاً توسط کاربر دیگری استفاده شده است', 409);
            }
            
            $updateData['email'] = $email;
        }
        
        if (isset($data['role'])) {
            $role = Security::sanitize($data['role']);
            $validRoles = ['admin', 'manager', 'user', 'viewer'];
            if (!in_array($role, $validRoles)) {
                Response::validationError('نقش نامعتبر است');
            }
            $updateData['role'] = $role;
        }
        
        if (isset($data['status'])) {
            $status = Security::sanitize($data['status']);
            $validStatuses = ['active', 'inactive', 'suspended'];
            if (!in_array($status, $validStatuses)) {
                Response::validationError('وضعیت نامعتبر است');
            }
            $updateData['status'] = $status;
        }
        
        if (isset($data['phone'])) {
            $updateData['phone'] = Security::sanitize($data['phone']);
        }
        
        if (isset($data['mobile'])) {
            $mobile = Security::sanitize($data['mobile']);
            if (!Security::isValidMobile($mobile)) {
                Response::validationError('شماره موبایل نامعتبر است');
            }
            $updateData['mobile'] = $mobile;
        }
        
        if (isset($data['address'])) {
            $updateData['address'] = Security::sanitize($data['address']);
        }
        
        if (isset($data['bio'])) {
            $updateData['bio'] = Security::sanitize($data['bio']);
        }
        
        if (isset($data['avatar'])) {
            $updateData['avatar'] = Security::sanitize($data['avatar']);
        }
        
        if (empty($updateData)) {
            Response::error('داده‌ای برای به‌روزرسانی وجود ندارد', 400);
        }
        
        $updateData['updated_at'] = date('Y-m-d H:i:s');
        
        $success = $this->userModel->update($id, $updateData);
        
        if (!$success) {
            Response::error('خطا در به‌روزرسانی کاربر', 500);
        }
        
        // Get updated user
        $updatedUser = $this->userModel->findById($id);
        
        Response::success([
            'user' => [
                'id' => $updatedUser['id'],
                'username' => $updatedUser['username'],
                'email' => $updatedUser['email'],
                'full_name' => $updatedUser['full_name'],
                'role' => $updatedUser['role'],
                'status' => $updatedUser['status'],
                'avatar' => $updatedUser['avatar'],
                'phone' => $updatedUser['phone'],
                'mobile' => $updatedUser['mobile'],
                'address' => $updatedUser['address'],
                'bio' => $updatedUser['bio'],
                'updated_at' => $updatedUser['updated_at']
            ]
        ], 'کاربر با موفقیت به‌روزرسانی شد');
    }
    
    public function delete($id) {
        // Check if user exists
        $existingUser = $this->userModel->findById($id);
        if (!$existingUser) {
            Response::error('کاربر یافت نشد', 404);
        }
        
        // Prevent deleting the last admin
        if ($existingUser['role'] === 'admin') {
            $sql = "SELECT COUNT(*) as count FROM users WHERE role = 'admin' AND deleted_at IS NULL";
            $result = $this->db->fetch($sql);
            if ($result['count'] <= 1) {
                Response::error('امکان حذف آخرین مدیر وجود ندارد', 400);
            }
        }
        
        // Prevent deleting own account
        $currentUser = $_SESSION['user'];
        if ($id == $currentUser['user_id']) {
            Response::error('امکان حذف حساب کاربری خود وجود ندارد', 400);
        }
        
        $success = $this->userModel->delete($id);
        
        if (!$success) {
            Response::error('خطا در حذف کاربر', 500);
        }
        
        Response::success(null, 'کاربر با موفقیت حذف شد');
    }
}