<?php
/**
 * Email Helper Class
 * Handles email sending functionality
 */

class Email {
    
    private static $config;
    
    /**
     * Load email configuration
     */
    private static function loadConfig() {
        if (!self::$config) {
            $configFile = __DIR__ . '/../config/config.json';
            if (file_exists($configFile)) {
                $config = json_decode(file_get_contents($configFile), true);
                self::$config = $config['email'] ?? [];
            } else {
                self::$config = [];
            }
        }
        return self::$config;
    }
    
    /**
     * Send email using SMTP or PHP mail
     */
    public static function send($to, $subject, $body, $from = null, $isHTML = true) {
        try {
            $config = self::loadConfig();
            
            // Set default from if not provided
            if (!$from) {
                $from = $config['from_email'] ?? 'noreply@avinakanban.com';
            }
            
            // Use SMTP if configured, otherwise use PHP mail
            if (isset($config['smtp_host']) && $config['smtp_host']) {
                return self::sendSMTP($to, $subject, $body, $from, $isHTML);
            } else {
                return self::sendMail($to, $subject, $body, $from, $isHTML);
            }
        } catch (Exception $e) {
            error_log('Email send error: ' . $e->getMessage());
            throw new Exception('خطا در ارسال ایمیل: ' . $e->getMessage());
        }
    }
    
    /**
     * Send email using PHP mail function
     */
    private static function sendMail($to, $subject, $body, $from, $isHTML = true) {
        $headers = [];
        $headers[] = 'From: ' . $from;
        $headers[] = 'Reply-To: ' . $from;
        $headers[] = 'X-Mailer: PHP/' . phpversion();
        
        if ($isHTML) {
            $headers[] = 'Content-Type: text/html; charset=UTF-8';
        } else {
            $headers[] = 'Content-Type: text/plain; charset=UTF-8';
        }
        
        $headers = implode("\r\n", $headers);
        
        // Convert subject to UTF-8
        $subject = '=?UTF-8?B?' . base64_encode($subject) . '?=';
        
        return mail($to, $subject, $body, $headers);
    }
    
    /**
     * Send email using SMTP
     */
    private static function sendSMTP($to, $subject, $body, $from, $isHTML = true) {
        $config = self::loadConfig();
        
        require_once __DIR__ . '/../vendor/phpmailer/phpmailer/src/PHPMailer.php';
        require_once __DIR__ . '/../vendor/phpmailer/phpmailer/src/SMTP.php';
        require_once __DIR__ . '/../vendor/phpmailer/phpmailer/src/Exception.php';
        
        $mail = new PHPMailer\PHPMailer\PHPMailer(true);
        
        // Server settings
        $mail->isSMTP();
        $mail->Host = $config['smtp_host'];
        $mail->SMTPAuth = true;
        $mail->Username = $config['smtp_username'];
        $mail->Password = $config['smtp_password'];
        $mail->SMTPSecure = $config['smtp_secure'] ?? 'tls';
        $mail->Port = $config['smtp_port'] ?? 587;
        
        // Recipients
        $mail->setFrom($from, $config['from_name'] ?? 'Avina Kanban');
        $mail->addAddress($to);
        
        // Content
        $mail->isHTML($isHTML);
        $mail->Subject = $subject;
        $mail->Body = $body;
        
        if (!$isHTML) {
            $mail->AltBody = strip_tags($body);
        }
        
        $mail->CharSet = 'UTF-8';
        
        return $mail->send();
    }
    
    /**
     * Send password reset email
     */
    public static function sendPasswordReset($to, $resetLink) {
        $subject = 'بازنشانی رمز عبور - Avina Kanban';
        
        $body = '
        <div style="direction: rtl; text-align: right; font-family: Tahoma, Arial, sans-serif;">
            <h2>بازنشانی رمز عبور</h2>
            <p>سلام</p>
            <p>برای بازنشانی رمز عبور خود روی لینک زیر کلیک کنید:</p>
            <p><a href="' . $resetLink . '" style="background-color: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">بازنشانی رمز عبور</a></p>
            <p>اگر شما درخواست بازنشانی رمز عبور نداده‌اید، این ایمیل را نادیده بگیرید.</p>
            <p>این لینک تا ۲۴ ساعت آینده معتبر است.</p>
            <hr>
            <p style="color: #666; font-size: 12px;">این ایمیل به صورت خودکار ارسال شده است.</p>
        </div>
        ';
        
        return self::send($to, $subject, $body);
    }
    
    /**
     * Send welcome email
     */
    public static function sendWelcomeEmail($to, $username) {
        $subject = 'خوش آمدید به Avina Kanban';
        
        $body = '
        <div style="direction: rtl; text-align: right; font-family: Tahoma, Arial, sans-serif;">
            <h2>خوش آمدید!</h2>
            <p>سلام ' . htmlspecialchars($username) . '</p>
            <p>به Avina Kanban خوش آمدید!</p>
            <p>اکنون می‌توانید از تمام امکانات سیستم مدیریت پروژه ما استفاده کنید.</p>
            <p>اگر سوالی دارید، با پشتیبانی تماس بگیرید.</p>
            <hr>
            <p style="color: #666; font-size: 12px;">این ایمیل به صورت خودکار ارسال شده است.</p>
        </div>
        ';
        
        return self::send($to, $subject, $body);
    }
    
    /**
     * Send invoice email
     */
    public static function sendInvoiceEmail($to, $invoiceData) {
        $subject = 'فاکتور شما - شماره: ' . $invoiceData['invoice_number'];
        
        $body = '
        <div style="direction: rtl; text-align: right; font-family: Tahoma, Arial, sans-serif;">
            <h2>فاکتور شما</h2>
            <p>سلام</p>
            <p>فاکتور شما با جزئیات زیر صادر شده است:</p>
            
            <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
                <tr>
                    <td style="padding: 10px; border: 1px solid #ddd;"><strong>شماره فاکتور:</strong></td>
                    <td style="padding: 10px; border: 1px solid #ddd;">' . htmlspecialchars($invoiceData['invoice_number']) . '</td>
                </tr>
                <tr>
                    <td style="padding: 10px; border: 1px solid #ddd;"><strong>مبلغ کل:</strong></td>
                    <td style="padding: 10px; border: 1px solid #ddd;">' . number_format($invoiceData['total_amount']) . ' تومان</td>
                </tr>
                <tr>
                    <td style="padding: 10px; border: 1px solid #ddd;"><strong>تاریخ صدور:</strong></td>
                    <td style="padding: 10px; border: 1px solid #ddd;">' . $invoiceData['issue_date'] . '</td>
                </tr>
            </table>
            
            <p>برای مشاهده جزئیات کامل فاکتور به حساب کاربری خود مراجعه کنید.</p>
            <hr>
            <p style="color: #666; font-size: 12px;">این ایمیل به صورت خودکار ارسال شده است.</p>
        </div>
        ';
        
        return self::send($to, $subject, $body);
    }
    
    /**
     * Send notification email
     */
    public static function sendNotification($to, $title, $message) {
        $subject = 'اعلان جدید - ' . $title;
        
        $body = '
        <div style="direction: rtl; text-align: right; font-family: Tahoma, Arial, sans-serif;">
            <h2>' . htmlspecialchars($title) . '</h2>
            <p>' . nl2br(htmlspecialchars($message)) . '</p>
            <hr>
            <p style="color: #666; font-size: 12px;">این ایمیل به صورت خودکار ارسال شده است.</p>
        </div>
        ';
        
        return self::send($to, $subject, $body);
    }
    
    /**
     * Check if email is valid and exists
     */
    public static function isValidEmail($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }
    
    /**
     * Mask email address
     */
    public static function maskEmail($email) {
        $parts = explode('@', $email);
        if (count($parts) !== 2) {
            return $email;
        }
        
        $username = $parts[0];
        $domain = $parts[1];
        
        $maskedUsername = substr($username, 0, 2) . str_repeat('*', max(1, strlen($username) - 2));
        $maskedDomain = substr($domain, 0, 1) . str_repeat('*', max(1, strpos($domain, '.') - 1)) . substr($domain, strpos($domain, '.'));
        
        return $maskedUsername . '@' . $maskedDomain;
    }
}