<?php
/**
 * Faraz SMS Client (IPPanel API compatible)
 * Minimal client for sending custom and pattern SMS
 */

class SmsClient {

    private $apiKey;
    private $baseUrl;

    public function __construct($apiKey, $baseUrl = 'https://api.ippanel.com/v1/') {
        $this->apiKey = $apiKey;
        $this->baseUrl = rtrim($baseUrl, '/') . '/';
    }

    public static function normalizeIranMobile($mobile) {
        // Accept formats like 09xxxxxxxxx or 9xxxxxxxxx; convert to 98xxxxxxxxxx
        $mobile = preg_replace('/\D+/', '', $mobile);
        if (preg_match('/^09\d{9}$/', $mobile)) {
            return '98' . substr($mobile, 1);
        }
        if (preg_match('/^9\d{9}$/', $mobile)) {
            return '98' . $mobile;
        }
        // Already in 98xxxxxxxxxx
        if (preg_match('/^98\d{10}$/', $mobile)) {
            return $mobile;
        }
        return $mobile; // return as-is if unknown; server may reject
    }

    public function send($originator, $recipients, $message) {
        $url = $this->baseUrl . 'messages';
        $payload = [
            'originator' => $originator,
            'recipients' => is_array($recipients) ? $recipients : [$recipients],
            'message' => $message,
        ];
        return $this->request('POST', $url, $payload);
    }

    public function sendPattern($patternCode, $originator, $recipient, $patternValues) {
        $url = $this->baseUrl . 'messages/pattern';
        $payload = [
            'pattern_code' => $patternCode,
            'originator' => $originator,
            'recipient' => $recipient,
            'values' => $patternValues,
        ];
        return $this->request('POST', $url, $payload);
    }

    private function request($method, $url, $payload = null) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        $headers = [
            'Content-Type: application/json',
            'Accept: application/json',
            'apikey: ' . $this->apiKey,
        ];
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        if ($payload !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        }
        $response = curl_exec($ch);
        $err = curl_error($ch);
        $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($err) {
            return [
                'success' => false,
                'status' => 0,
                'error' => 'cURL error: ' . $err,
            ];
        }

        $json = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            return [
                'success' => false,
                'status' => $status,
                'error' => 'Invalid JSON response',
                'raw' => $response,
            ];
        }

        return [
            'success' => $status >= 200 && $status < 300,
            'status' => $status,
            'data' => $json,
        ];
    }
}