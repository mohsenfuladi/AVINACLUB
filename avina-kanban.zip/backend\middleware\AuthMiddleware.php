<?php
/**
 * Authentication Middleware
 * Handles JWT authentication and authorization
 */

require_once __DIR__ . '/../helpers/jwt.php';
require_once __DIR__ . '/../helpers/response.php';

class AuthMiddleware {
    
    /**
     * Handle authentication
     */
    public function handle($requiredRole = null) {
        try {
            // Get token from request
            $token = $this->getTokenFromRequest();
            
            if (!$token) {
                Response::unauthorized('توکن احراز هویت مورد نیاز است');
                exit;
            }
            
            // Validate token
            $payload = JWT::validate($token);
            
            // Check if token is expired
            if (JWT::isExpired($token)) {
                Response::unauthorized('توکن منقضی شده است');
                exit;
            }
            
            // Check user role if required
            if ($requiredRole && !$this->hasRole($payload, $requiredRole)) {
                Response::forbidden('دسترسی غیرمجاز');
                exit;
            }
            
            // Set user data in request
            $_REQUEST['user'] = $payload;
            $_REQUEST['user_id'] = $payload['user_id'];
            $_REQUEST['user_role'] = $payload['role'];
            
            return true;
        } catch (Exception $e) {
            Response::unauthorized('توکن نامعتبر است: ' . $e->getMessage());
            exit;
        }
    }
    
    /**
     * Get token from request
     */
    private function getTokenFromRequest() {
        // Check Authorization header
        $headers = getallheaders();
        
        if (isset($headers['Authorization'])) {
            $authHeader = $headers['Authorization'];
            if (preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
                return $matches[1];
            }
        }
        
        // Check alternative Authorization header
        if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
            $authHeader = $_SERVER['HTTP_AUTHORIZATION'];
            if (preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
                return $matches[1];
            }
        }
        
        // Check X-Access-Token header
        if (isset($headers['X-Access-Token'])) {
            return $headers['X-Access-Token'];
        }
        
        // Check token in query parameter (for development only)
        if (isset($_GET['token'])) {
            return $_GET['token'];
        }
        
        return null;
    }
    
    /**
     * Check if user has required role
     */
    private function hasRole($payload, $requiredRole) {
        $userRole = $payload['role'] ?? null;
        
        if (!$userRole) {
            return false;
        }
        
        // Admin has all permissions
        if ($userRole === 'admin') {
            return true;
        }
        
        // Check exact role match
        return $userRole === $requiredRole;
    }
    
    /**
     * Check if user has any of the required roles
     */
    public function hasAnyRole($roles) {
        try {
            $token = $this->getTokenFromRequest();
            
            if (!$token) {
                return false;
            }
            
            $payload = JWT::validate($token);
            $userRole = $payload['role'] ?? null;
            
            if (!$userRole) {
                return false;
            }
            
            // Admin has all permissions
            if ($userRole === 'admin') {
                return true;
            }
            
            // Check if user has any of the required roles
            return in_array($userRole, $roles);
        } catch (Exception $e) {
            return false;
        }
    }
    
    /**
     * Check if user has permission for specific action
     */
    public function hasPermission($permission) {
        try {
            $token = $this->getTokenFromRequest();
            
            if (!$token) {
                return false;
            }
            
            $payload = JWT::validate($token);
            $userRole = $payload['role'] ?? null;
            
            if (!$userRole) {
                return false;
            }
            
            // Define role permissions
            $permissions = [
                'admin' => ['*'], // Admin has all permissions
                'manager' => ['read', 'write', 'update', 'delete_own'],
                'user' => ['read', 'write_own', 'update_own'],
                'viewer' => ['read']
            ];
            
            // Check if role exists in permissions
            if (!isset($permissions[$userRole])) {
                return false;
            }
            
            // Admin has all permissions
            if (in_array('*', $permissions[$userRole])) {
                return true;
            }
            
            // Check if user has the required permission
            return in_array($permission, $permissions[$userRole]);
        } catch (Exception $e) {
            return false;
        }
    }
    
    /**
     * Get current user data
     */
    public function getCurrentUser() {
        try {
            $token = $this->getTokenFromRequest();
            
            if (!$token) {
                return null;
            }
            
            return JWT::validate($token);
        } catch (Exception $e) {
            return null;
        }
    }
    
    /**
     * Refresh token
     */
    public function refreshToken() {
        try {
            $token = $this->getTokenFromRequest();
            
            if (!$token) {
                Response::unauthorized('توکن احراز هویت مورد نیاز است');
                exit;
            }
            
            // Validate current token
            $payload = JWT::validate($token);
            
            // Generate new token
            $newToken = JWT::refresh($token);
            
            return $newToken;
        } catch (Exception $e) {
            Response::unauthorized('توکن نامعتبر است: ' . $e->getMessage());
            exit;
        }
    }
    
    /**
     * Optional authentication (doesn't fail if no token)
     */
    public function optionalAuth() {
        try {
            $token = $this->getTokenFromRequest();
            
            if ($token) {
                $payload = JWT::validate($token);
                
                // Set user data in request
                $_REQUEST['user'] = $payload;
                $_REQUEST['user_id'] = $payload['user_id'];
                $_REQUEST['user_role'] = $payload['role'];
            }
            
            return true;
        } catch (Exception $e) {
            // Ignore authentication errors for optional auth
            return true;
        }
    }
}