<?php
/**
 * Authentication Controller
 * Handles user authentication, registration, and password reset
 */

require_once '../models/User.php';
require_once '../helpers/jwt.php';
require_once '../helpers/security.php';
require_once '../helpers/response.php';
require_once '../helpers/email.php';

class AuthController {
    
    private $userModel;
    
    public function __construct($database = null) {
        $this->userModel = new User();
    }
    
    /**
     * User login
     */
    public function login() {
        try {
            $data = Request::getInput();
            
            // Validate required fields
            Request::validateRequired(['email', 'password'], $data);
            
            $email = Security::sanitize($data['email']);
            $password = $data['password'];
            
            // Find user by email
            $user = $this->userModel->findByEmail($email);
            if (!$user) {
                Response::error('کاربری با این ایمیل یافت نشد', 401);
                return;
            }
            
            // Verify password
            if (!password_verify($password, $user['password'])) {
                Response::error('رمز عبور نادرست است', 401);
                return;
            }
            
            // Check if user is active
            if ($user['status'] !== 'active') {
                Response::error('حساب کاربری شما غیرفعال است', 403);
                return;
            }
            
            // Update last login
            $this->userModel->updateLastLogin($user['id']);
            
            // Generate JWT token
            $token = JWT::generate([
                'user_id' => $user['id'],
                'email' => $user['email'],
                'role' => $user['role'],
                'exp' => time() + (60 * 60 * 24 * 7) // 7 days
            ]);
            
            Response::success('ورود با موفقیت انجام شد', [
                'user' => [
                    'id' => $user['id'],
                    'name' => $user['name'],
                    'email' => $user['email'],
                    'role' => $user['role'],
                    'avatar' => $user['avatar']
                ],
                'token' => $token
            ]);
            
        } catch (Exception $e) {
            Response::error('خطا در ورود: ' . $e->getMessage());
        }
    }
    
    /**
     * User registration (if enabled)
     */
    public function register() {
        try {
            $data = Request::getInput();
            
            // Validate required fields
            Request::validateRequired(['name', 'email', 'password'], $data);
            
            // Validate email format
            if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
                Response::error('فرمت ایمیل نامعتبر است');
                return;
            }
            
            // Check if email already exists
            if ($this->userModel->findByEmail($data['email'])) {
                Response::error('این ایمیل قبلاً ثبت شده است');
                return;
            }
            
            // Create user
            $userId = $this->userModel->create([
                'name' => Security::sanitize($data['name']),
                'email' => Security::sanitize($data['email']),
                'password' => password_hash($data['password'], PASSWORD_BCRYPT),
                'role' => 'user',
                'status' => 'active',
                'created_at' => date('Y-m-d H:i:s')
            ]);
            
            $user = $this->userModel->findById($userId);
            
            // Generate token
            $token = JWT::generate([
                'user_id' => $user['id'],
                'email' => $user['email'],
                'role' => $user['role'],
                'exp' => time() + (60 * 60 * 24 * 7)
            ]);
            
            Response::success('ثبت‌نام با موفقیت انجام شد', [
                'user' => [
                    'id' => $user['id'],
                    'name' => $user['name'],
                    'email' => $user['email'],
                    'role' => $user['role']
                ],
                'token' => $token
            ], 201);
            
        } catch (Exception $e) {
            Response::error('خطا در ثبت‌نام: ' . $e->getMessage());
        }
    }
    
    /**
     * Request password reset
     */
    public function forgotPassword() {
        try {
            $data = Request::getInput();
            
            Request::validateRequired(['email'], $data);
            
            $email = Security::sanitize($data['email']);
            $user = $this->userModel->findByEmail($email);
            
            if (!$user) {
                // Don't reveal if user exists or not for security
                Response::success('اگر ایمیل وارد شده معتبر باشد، لینک بازیابی ارسال خواهد شد');
                return;
            }
            
            // Generate reset token
            $resetToken = bin2hex(random_bytes(32));
            $resetExpiry = date('Y-m-d H:i:s', time() + (60 * 60)); // 1 hour
            
            // Save reset token
            $this->userModel->saveResetToken($user['id'], $resetToken, $resetExpiry);
            
            // Send reset email
            $resetUrl = $_SERVER['HTTP_ORIGIN'] . '/reset-password?token=' . $resetToken;
            
            Email::sendResetPassword($user['email'], $user['name'], $resetUrl);
            
            Response::success('ایمیل بازیابی رمز عبور ارسال شد');
            
        } catch (Exception $e) {
            Response::error('خطا در ارسال ایمیل بازیابی: ' . $e->getMessage());
        }
    }
    
    /**
     * Reset password with token
     */
    public function resetPassword() {
        try {
            $data = Request::getInput();
            
            Request::validateRequired(['token', 'password'], $data);
            
            $token = Security::sanitize($data['token']);
            $password = $data['password'];
            
            // Find user by reset token
            $user = $this->userModel->findByResetToken($token);
            if (!$user) {
                Response::error('توکن بازیابی نامعتبر است');
                return;
            }
            
            // Check if token is expired
            if (strtotime($user['reset_token_expiry']) < time()) {
                Response::error('توکن بازیابی منقضی شده است');
                return;
            }
            
            // Update password and clear reset token
            $this->userModel->updatePassword($user['id'], password_hash($password, PASSWORD_BCRYPT));
            $this->userModel->clearResetToken($user['id']);
            
            Response::success('رمز عبور با موفقیت تغییر یافت');
            
        } catch (Exception $e) {
            Response::error('خطا در تغییر رمز عبور: ' . $e->getMessage());
        }
    }
    
    /**
     * Get current user info
     */
    public function me() {
        try {
            $userId = $this->getCurrentUserId();
            $user = $this->userModel->findById($userId);
            
            if (!$user) {
                Response::error('کاربر یافت نشد', 404);
                return;
            }
            
            Response::success('اطلاعات کاربر', [
                'user' => [
                    'id' => $user['id'],
                    'name' => $user['name'],
                    'email' => $user['email'],
                    'role' => $user['role'],
                    'avatar' => $user['avatar'],
                    'status' => $user['status'],
                    'last_login' => $user['last_login'],
                    'created_at' => $user['created_at']
                ]
            ]);
            
        } catch (Exception $e) {
            Response::error('خطا در دریافت اطلاعات کاربر: ' . $e->getMessage());
        }
    }

    /**
     * Alias for current user profile (compatibility with routes)
     */
    public function profile() {
        // Delegate to me() to return the same response structure
        return $this->me();
    }
    
    /**
     * Update current user profile
     */
    public function updateProfile() {
        try {
            $userId = $this->getCurrentUserId();
            $data = Request::getInput();
            
            $updateData = [];
            
            if (isset($data['name'])) {
                $updateData['name'] = Security::sanitize($data['name']);
            }
            
            if (isset($data['email'])) {
                $email = Security::sanitize($data['email']);
                if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    Response::error('فرمت ایمیل نامعتبر است');
                    return;
                }
                
                // Check if email already exists for another user
                $existingUser = $this->userModel->findByEmail($email);
                if ($existingUser && $existingUser['id'] != $userId) {
                    Response::error('این ایمیل قبلاً توسط کاربر دیگری استفاده شده است');
                    return;
                }
                
                $updateData['email'] = $email;
            }
            
            if (isset($data['avatar'])) {
                $updateData['avatar'] = Security::sanitize($data['avatar']);
            }
            
            if (!empty($updateData)) {
                $this->userModel->update($userId, $updateData);
            }
            
            $user = $this->userModel->findById($userId);
            
            Response::success('پروفایل با موفقیت بروزرسانی شد', [
                'user' => [
                    'id' => $user['id'],
                    'name' => $user['name'],
                    'email' => $user['email'],
                    'avatar' => $user['avatar']
                ]
            ]);
            
        } catch (Exception $e) {
            Response::error('خطا در بروزرسانی پروفایل: ' . $e->getMessage());
        }
    }
    
    /**
     * Change current user password
     */
    public function changePassword() {
        try {
            $userId = $this->getCurrentUserId();
            $data = Request::getInput();
            
            Request::validateRequired(['current_password', 'new_password'], $data);
            
            $user = $this->userModel->findById($userId);
            
            // Verify current password
            if (!password_verify($data['current_password'], $user['password'])) {
                Response::error('رمز عبور فعلی نادرست است');
                return;
            }
            
            // Update password
            $this->userModel->updatePassword($userId, password_hash($data['new_password'], PASSWORD_BCRYPT));
            
            Response::success('رمز عبور با موفقیت تغییر یافت');
            
        } catch (Exception $e) {
            Response::error('خطا در تغییر رمز عبور: ' . $e->getMessage());
        }
    }
    
    /**
     * Logout current user
     */
    public function logout() {
        // In a stateless JWT system, logout is handled client-side
        // But we can still log this action
        $userId = $this->getCurrentUserId();
        
        Response::success('خروج با موفقیت انجام شد');
    }

    /**
     * Request OTP login code via SMS
     */
    public function requestOtp() {
        try {
            $data = Request::getJsonInput();
            $mobile = Security::sanitize($data['mobile'] ?? '');
            if (!Security::isValidMobile($mobile)) {
                Response::validationError('شماره موبایل نامعتبر است');
            }

            // Normalize to 98xxxxxxxxxx for SMS dispatch
            require_once '../helpers/SmsClient.php';
            $normalizedRecipient = SmsClient::normalizeIranMobile($mobile);

            // Load settings
            require_once '../models/Settings.php';
            $settings = new Settings(Database::getInstance());
            $apiKey = $settings->get('faraz_api_key');
            $originator = $settings->get('faraz_originator') ?? '+9810001';
            $patternCode = $settings->get('faraz_otp_pattern_code');
            if (!$apiKey) {
                Response::error('کلید API فراز SMS تنظیم نشده است', 500);
            }

            // Generate 6-digit OTP
            $code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
            $expiresAt = time() + (60 * 5); // 5 minutes

            // Persist OTP in settings (ephemeral)
            $settings->set('otp_' . $mobile, json_encode([
                'code' => $code,
                'expires_at' => $expiresAt,
                'attempts' => 0,
                'purpose' => 'login',
            ]));

            $client = new SmsClient($apiKey);
            if ($patternCode) {
                $resp = $client->sendPattern($patternCode, $originator, $normalizedRecipient, [
                    'code' => $code,
                ]);
            } else {
                $message = 'کد ورود شما: ' . $code;
                $resp = $client->send($originator, [$normalizedRecipient], $message);
            }

            if (!$resp['success']) {
                Response::error('ارسال OTP ناموفق بود: ' . ($resp['error'] ?? 'unknown'), $resp['status'] ?: 500);
            }

            Response::success(['expires_in' => 300], 'کد ورود پیامک شد');

        } catch (Exception $e) {
            Response::error('خطا در درخواست OTP: ' . $e->getMessage());
        }
    }

    /**
     * Verify OTP and issue JWT
     */
    public function verifyOtp() {
        try {
            $data = Request::getJsonInput();
            $mobile = Security::sanitize($data['mobile'] ?? '');
            $code = Security::sanitize($data['code'] ?? '');
            if (!Security::isValidMobile($mobile)) {
                Response::validationError('شماره موبایل نامعتبر است');
            }
            if (!preg_match('/^\d{6}$/', $code)) {
                Response::validationError('کد OTP نامعتبر است');
            }

            // Load OTP from settings
            require_once '../models/Settings.php';
            $settings = new Settings(Database::getInstance());
            $otpJson = $settings->get('otp_' . $mobile);
            if (!$otpJson) {
                Response::error('کد OTP یافت نشد یا منقضی شده است', 400);
            }
            $otpData = json_decode($otpJson, true);
            if (!$otpData || !isset($otpData['code'])) {
                Response::error('کد OTP نامعتبر است', 400);
            }
            if ($otpData['expires_at'] < time()) {
                $settings->delete('otp_' . $mobile);
                Response::error('کد OTP منقضی شده است', 400);
            }
            if (!hash_equals($otpData['code'], $code)) {
                // Increment attempts
                $otpData['attempts'] = ($otpData['attempts'] ?? 0) + 1;
                $settings->set('otp_' . $mobile, json_encode($otpData));
                Response::error('کد OTP نادرست است', 401);
            }

            // Find user by mobile
            $user = $this->userModel->findByMobile($mobile);
            if (!$user) {
                Response::error('کاربری با این موبایل یافت نشد', 404);
            }

            // Clear OTP
            $settings->delete('otp_' . $mobile);

            // Update last login
            $this->userModel->updateLastLogin($user['id']);

            // Generate JWT token
            require_once '../helpers/jwt.php';
            $token = JWT::generate([
                'user_id' => $user['id'],
                'email' => $user['email'],
                'role' => $user['role'],
                'exp' => time() + (60 * 60 * 24 * 7)
            ]);

            Response::success('ورود با موفقیت انجام شد', [
                'user' => [
                    'id' => $user['id'],
                    'name' => $user['name'] ?? $user['full_name'] ?? ($user['username'] ?? ''),
                    'email' => $user['email'],
                    'role' => $user['role'],
                    'avatar' => $user['avatar'] ?? null,
                ],
                'token' => $token
            ]);

        } catch (Exception $e) {
            Response::error('خطا در تایید OTP: ' . $e->getMessage());
        }
    }
    
    /**
     * Get current user ID from JWT token
     */
    private function getCurrentUserId() {
        $token = $this->getBearerToken();
        if (!$token) {
            Response::unauthorized('توکن احراز هویت مورد نیاز است');
            exit;
        }
        
        try {
            $payload = JWT::validate($token);
            return $payload['user_id'];
        } catch (Exception $e) {
            Response::unauthorized('توکن نامعتبر است');
            exit;
        }
    }
    
    /**
     * Get bearer token from request headers
     */
    private function getBearerToken() {
        $headers = apache_request_headers();
        if (isset($headers['Authorization'])) {
            if (preg_match('/Bearer\s+(.*)$/i', $headers['Authorization'], $matches)) {
                return $matches[1];
            }
        }
        return null;
    }
}