<?php
/**
 * Request Helper
 * Handles HTTP request operations and validation
 */

class Request {
    
    /**
     * Get JSON input from request body
     */
    public static function getJsonInput() {
        $input = file_get_contents('php://input');
        $data = json_decode($input, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            Response::error('Invalid JSON input', 400);
        }
        
        return $data ?: [];
    }

    /**
     * Backward-compatible input getter: JSON body if present, otherwise POST
     */
    public static function getInput() {
        $contentType = $_SERVER['CONTENT_TYPE'] ?? $_SERVER['HTTP_CONTENT_TYPE'] ?? '';
        if (stripos($contentType, 'application/json') !== false) {
            return self::getJsonInput();
        }
        // Fallback to POST form fields
        return self::getPostInput();
    }
    
    /**
     * Get POST input
     */
    public static function getPostInput() {
        return $_POST ?: [];
    }
    
    /**
     * Get GET parameters
     */
    public static function getQueryParams() {
        return $_GET ?: [];
    }
    
    /**
     * Get specific query parameter
     */
    public static function getQueryParam($key, $default = null) {
        return isset($_GET[$key]) ? $_GET[$key] : $default;
    }
    
    /**
     * Validate required fields
     */
    public static function validateRequired($data, $requiredFields) {
        $missing = [];
        
        foreach ($requiredFields as $field) {
            if (!isset($data[$field]) || empty($data[$field])) {
                $missing[] = $field;
            }
        }
        
        return [
            'valid' => empty($missing),
            'missing' => $missing
        ];
    }
    
    /**
     * Validate email format
     */
    public static function validateEmail($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }
    
    /**
     * Validate mobile number (Iranian format)
     */
    public static function validateMobile($mobile) {
        // Remove spaces and convert to English numbers
        $mobile = str_replace(' ', '', $mobile);
        $mobile = self::convertToEnglishNumbers($mobile);
        
        // Check if it's a valid Iranian mobile number
        return preg_match('/^09[0-9]{9}$/', $mobile);
    }
    
    /**
     * Convert Persian/Arabic numbers to English
     */
    public static function convertToEnglishNumbers($string) {
        $persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        $arabic = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
        $english = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
        
        $string = str_replace($persian, $english, $string);
        $string = str_replace($arabic, $english, $string);
        
        return $string;
    }
    
    /**
     * Validate date format (YYYY-MM-DD)
     */
    public static function validateDate($date) {
        $d = DateTime::createFromFormat('Y-m-d', $date);
        return $d && $d->format('Y-m-d') === $date;
    }
    
    /**
     * Validate time format (HH:MM)
     */
    public static function validateTime($time) {
        return preg_match('/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/', $time);
    }
    
    /**
     * Get client IP address
     */
    public static function getClientIp() {
        $ipKeys = ['HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'];
        
        foreach ($ipKeys as $key) {
            if (array_key_exists($key, $_SERVER) === true) {
                foreach (explode(',', $_SERVER[$key]) as $ip) {
                    $ip = trim($ip);
                    
                    if (filter_var($ip, FILTER_VALIDATE_IP, 
                        FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                        return $ip;
                    }
                }
            }
        }
        
        return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }
    
    /**
     * Get user agent
     */
    public static function getUserAgent() {
        return $_SERVER['HTTP_USER_AGENT'] ?? '';
    }
    
    /**
     * Check if request is AJAX
     */
    public static function isAjax() {
        return isset($_SERVER['HTTP_X_REQUESTED_WITH']) && 
               strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    }
    
    /**
     * Get request method
     */
    public static function getMethod() {
        return $_SERVER['REQUEST_METHOD'];
    }
    
    /**
     * Check if request method matches
     */
    public static function isMethod($method) {
        return self::getMethod() === strtoupper($method);
    }
    
    /**
     * Get uploaded file info
     */
    public static function getUploadedFile($fieldName) {
        if (!isset($_FILES[$fieldName])) {
            return null;
        }
        
        $file = $_FILES[$fieldName];
        
        // Check for upload errors
        if ($file['error'] !== UPLOAD_ERR_OK) {
            return null;
        }
        
        return $file;
    }
    
    /**
     * Validate file upload
     */
    public static function validateFileUpload($file, $allowedTypes = [], $maxSize = 0) {
        if (!$file || !isset($file['error'])) {
            return ['valid' => false, 'error' => 'فایل ارسال نشده است'];
        }
        
        if ($file['error'] !== UPLOAD_ERR_OK) {
            $errors = [
                UPLOAD_ERR_INI_SIZE => 'حجم فایل بیش از حد مجاز است',
                UPLOAD_ERR_FORM_SIZE => 'حجم فایل بیش از حد مجاز است',
                UPLOAD_ERR_PARTIAL => 'آپلود فایل ناقص بود',
                UPLOAD_ERR_NO_FILE => 'فایلی انتخاب نشده است',
                UPLOAD_ERR_NO_TMP_DIR => 'پوشه موقت یافت نشد',
                UPLOAD_ERR_CANT_WRITE => 'خطا در نوشتن فایل',
                UPLOAD_ERR_EXTENSION => 'پسوند فایل مجاز نیست'
            ];
            
            return ['valid' => false, 'error' => $errors[$file['error']] ?? 'خطای ناشناخته در آپلود'];
        }
        
        // Check file size
        if ($maxSize > 0 && $file['size'] > $maxSize) {
            return ['valid' => false, 'error' => 'حجم فایل بیش از حد مجاز است'];
        }
        
        // Check file type
        if (!empty($allowedTypes)) {
            $fileInfo = finfo_open(FILEINFO_MIME_TYPE);
            $mimeType = finfo_file($fileInfo, $file['tmp_name']);
            finfo_close($fileInfo);
            
            if (!in_array($mimeType, $allowedTypes)) {
                return ['valid' => false, 'error' => 'نوع فایل مجاز نیست'];
            }
        }
        
        return ['valid' => true];
    }
}