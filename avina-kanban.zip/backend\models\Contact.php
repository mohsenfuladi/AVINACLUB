<?php
/**
 * Contact Model
 * Handles CRUD operations for contacts (phonebook style)
 */

class Contact {
    private $db;

    public function __construct($database) {
        $this->db = $database;
    }

    public function findById($id) {
        $sql = "SELECT id, name, phone AS mobile, category, notes, created_by, created_at, updated_at
                FROM contacts WHERE id = ? AND deleted_at IS NULL";
        return $this->db->fetch($sql, [$id]);
    }

    public function list($filters = []) {
        $where = "WHERE deleted_at IS NULL";
        $params = [];

        if (isset($filters['category'])) {
            $where .= " AND category = ?";
            $params[] = $filters['category'];
        }

        if (isset($filters['search'])) {
            $where .= " AND (name LIKE ? OR phone LIKE ?)";
            $term = '%' . $filters['search'] . '%';
            $params[] = $term;
            $params[] = $term;
        }

        $sql = "SELECT id, name, phone AS mobile, category, notes, created_by, created_at, updated_at
                FROM contacts {$where} ORDER BY created_at DESC";

        // Pagination support
        if (isset($filters['limit'])) {
            $limit = intval($filters['limit']);
            if ($limit > 0) {
                $sql .= " LIMIT ?";
                $params[] = $limit;
                if (isset($filters['offset'])) {
                    $offset = intval($filters['offset']);
                    if ($offset >= 0) {
                        // MySQL requires OFFSET after LIMIT
                        $sql .= " OFFSET ?";
                        $params[] = $offset;
                    }
                }
            }
        }

        return $this->db->fetchAll($sql, $params);
    }

    public function count($filters = []) {
        $where = "WHERE deleted_at IS NULL";
        $params = [];

        if (isset($filters['category'])) {
            $where .= " AND category = ?";
            $params[] = $filters['category'];
        }

        if (isset($filters['search'])) {
            $where .= " AND (name LIKE ? OR phone LIKE ?)";
            $term = '%' . $filters['search'] . '%';
            $params[] = $term;
            $params[] = $term;
        }

        $sql = "SELECT COUNT(*) AS total FROM contacts {$where}";
        $row = $this->db->fetch($sql, $params);
        return isset($row['total']) ? intval($row['total']) : 0;
    }

    public function create($data) {
        $sql = "INSERT INTO contacts (name, phone, category, notes, created_by, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)";
        $params = [
            $data['name'],
            $data['mobile'],
            $data['category'],
            $data['notes'] ?? null,
            $data['created_by'] ?? null,
            date('Y-m-d H:i:s'),
            date('Y-m-d H:i:s')
        ];
        return $this->db->insert($sql, $params);
    }

    public function update($id, $data) {
        $fields = [];
        $params = [];

        if (isset($data['name'])) { $fields[] = "name = ?"; $params[] = $data['name']; }
        if (isset($data['mobile'])) { $fields[] = "phone = ?"; $params[] = $data['mobile']; }
        if (isset($data['category'])) { $fields[] = "category = ?"; $params[] = $data['category']; }
        if (array_key_exists('notes', $data)) { $fields[] = "notes = ?"; $params[] = $data['notes']; }

        $fields[] = "updated_at = ?"; $params[] = date('Y-m-d H:i:s');
        $params[] = $id;

        $sql = "UPDATE contacts SET " . implode(', ', $fields) . " WHERE id = ? AND deleted_at IS NULL";
        return $this->db->execute($sql, $params);
    }

    public function delete($id) {
        $sql = "UPDATE contacts SET deleted_at = ? WHERE id = ? AND deleted_at IS NULL";
        return $this->db->execute($sql, [date('Y-m-d H:i:s'), $id]);
    }
}