<?php
/**
 * Backup Controller
 * Handles database backup and restore operations
 */

require_once '../helpers/response.php';
require_once '../helpers/security.php';
require_once '../models/Backup.php';

class BackupController {
    
    private $db;
    private $backupModel;
    private $backupDir;
    
    public function __construct($database) {
        $this->db = $database;
        $this->backupModel = new Backup($database);
        $this->backupDir = dirname(__DIR__) . '/backups/';
        
        // Ensure backup directory exists
        if (!is_dir($this->backupDir)) {
            mkdir($this->backupDir, 0755, true);
        }
    }
    
    public function list() {
        $backups = $this->backupModel->list();
        
        Response::success([
            'backups' => $backups
        ]);
    }
    
    public function create() {
        $data = Request::getJsonInput();
        
        $backupName = isset($data['name']) ? Security::sanitize($data['name']) : '';
        $backupType = isset($data['type']) ? Security::sanitize($data['type']) : 'full';
        
        if (empty($backupName)) {
            $backupName = 'backup_' . date('Y-m-d_H-i-s');
        }
        
        // Validate backup type
        if (!in_array($backupType, ['full', 'data', 'structure'])) {
            Response::validationError('نوع پشتیبان‌گیری نامعتبر است');
        }
        
        // Generate backup filename
        $filename = $backupName . '_' . time() . '.sql';
        $filepath = $this->backupDir . $filename;
        
        try {
            // Create backup based on type
            $backupContent = $this->createBackup($backupType);
            
            // Save backup file
            if (file_put_contents($filepath, $backupContent) === false) {
                throw new Exception('خطا در ذخیره فایل پشتیبان');
            }
            
            // Get file size
            $fileSize = filesize($filepath);
            
            // Record backup in database
            $backupId = $this->backupModel->create([
                'name' => $backupName,
                'filename' => $filename,
                'type' => $backupType,
                'size' => $fileSize,
                'path' => $filepath
            ]);
            
            if (!$backupId) {
                throw new Exception('خطا در ثبت اطلاعات پشتیبان');
            }
            
            // Get created backup info
            $backup = $this->backupModel->findById($backupId);
            
            Response::success([
                'backup' => $backup
            ], 'پشتیبان‌گیری با موفقیت انجام شد', 201);
            
        } catch (Exception $e) {
            // Clean up file if it was created
            if (file_exists($filepath)) {
                unlink($filepath);
            }
            
            Response::error($e->getMessage(), 500);
        }
    }
    
    public function download($id) {
        // Get backup info
        $backup = $this->backupModel->findById($id);
        
        if (!$backup) {
            Response::error('فایل پشتیبان یافت نشد', 404);
        }
        
        $filepath = $backup['path'];
        
        if (!file_exists($filepath)) {
            Response::error('فایل پشتیبان در سرور یافت نشد', 404);
        }
        
        // Set headers for file download
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $backup['filename'] . '"');
        header('Content-Length: ' . filesize($filepath));
        header('Cache-Control: no-cache, must-revalidate');
        
        // Read and output file
        readfile($filepath);
        exit;
    }
    
    public function restore($id) {
        // Get backup info
        $backup = $this->backupModel->findById($id);
        
        if (!$backup) {
            Response::error('فایل پشتیبان یافت نشد', 404);
        }
        
        $filepath = $backup['path'];
        
        if (!file_exists($filepath)) {
            Response::error('فایل پشتیبان در سرور یافت نشد', 404);
        }
        
        // Read backup content
        $backupContent = file_get_contents($filepath);
        
        if ($backupContent === false) {
            Response::error('خطا در خواندن فایل پشتیبان', 500);
        }
        
        try {
            // Start transaction
            $this->db->beginTransaction();
            
            // Execute backup SQL
            $this->executeBackup($backupContent);
            
            // Record restore operation
            $this->backupModel->recordRestore($id);
            
            $this->db->commit();
            
            Response::success(null, 'بازیابی با موفقیت انجام شد');
            
        } catch (Exception $e) {
            $this->db->rollback();
            Response::error('خطا در بازیابی: ' . $e->getMessage(), 500);
        }
    }
    
    public function delete($id) {
        // Get backup info
        $backup = $this->backupModel->findById($id);
        
        if (!$backup) {
            Response::error('فایل پشتیبان یافت نشد', 404);
        }
        
        $filepath = $backup['path'];
        
        try {
            // Delete backup file
            if (file_exists($filepath)) {
                if (!unlink($filepath)) {
                    throw new Exception('خطا در حذف فایل پشتیبان');
                }
            }
            
            // Delete backup record
            $success = $this->backupModel->delete($id);
            
            if (!$success) {
                throw new Exception('خطا در حذف رکورد پشتیبان');
            }
            
            Response::success(null, 'پشتیبان با موفقیت حذف شد');
            
        } catch (Exception $e) {
            Response::error($e->getMessage(), 500);
        }
    }
    
    public function upload() {
        // Check if file was uploaded
        if (!isset($_FILES['backup_file'])) {
            Response::error('فایل پشتیبان ارسال نشده است', 400);
        }
        
        $file = $_FILES['backup_file'];
        
        // Validate file upload
        if ($file['error'] !== UPLOAD_ERR_OK) {
            Response::error('خطا در آپلود فایل', 400);
        }
        
        // Validate file type
        $allowedTypes = ['application/sql', 'text/plain', 'application/octet-stream'];
        if (!in_array($file['type'], $allowedTypes)) {
            Response::error('نوع فایل نامعتبر است. فقط فایل‌های SQL مجاز هستند', 400);
        }
        
        // Validate file extension
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        if (!in_array(strtolower($extension), ['sql', 'txt'])) {
            Response::error('پسوند فایل نامعتبر است. فقط فایل‌های SQL مجاز هستند', 400);
        }
        
        // Validate file size (max 50MB)
        if ($file['size'] > 50 * 1024 * 1024) {
            Response::error('حجم فایل بیش از حد مجاز است (حداکثر 50 مگابایت)', 400);
        }
        
        // Generate unique filename
        $filename = 'uploaded_' . date('Y-m-d_H-i-s') . '_' . uniqid() . '.sql';
        $filepath = $this->backupDir . $filename;
        
        try {
            // Move uploaded file
            if (!move_uploaded_file($file['tmp_name'], $filepath)) {
                throw new Exception('خطا در انتقال فایل آپلود شده');
            }
            
            // Validate backup content
            $content = file_get_contents($filepath);
            if (!$this->validateBackupContent($content)) {
                unlink($filepath);
                throw new Exception('محتوای فایل پشتیبان نامعتبر است');
            }
            
            // Record backup in database
            $backupId = $this->backupModel->create([
                'name' => pathinfo($file['name'], PATHINFO_FILENAME),
                'filename' => $filename,
                'type' => 'uploaded',
                'size' => $file['size'],
                'path' => $filepath,
                'is_uploaded' => 1
            ]);
            
            if (!$backupId) {
                throw new Exception('خطا در ثبت اطلاعات پشتیبان');
            }
            
            // Get created backup info
            $backup = $this->backupModel->findById($backupId);
            
            Response::success([
                'backup' => $backup
            ], 'فایل پشتیبان با موفقیت آپلود شد', 201);
            
        } catch (Exception $e) {
            // Clean up file if it was created
            if (file_exists($filepath)) {
                unlink($filepath);
            }
            
            Response::error($e->getMessage(), 500);
        }
    }
    
    public function schedule() {
        $data = Request::getJsonInput();
        
        $enabled = isset($data['enabled']) ? (int)$data['enabled'] : 0;
        $frequency = isset($data['frequency']) ? Security::sanitize($data['frequency']) : 'daily';
        $time = isset($data['time']) ? Security::sanitize($data['time']) : '02:00';
        $retention = isset($data['retention']) ? (int)$data['retention'] : 7;
        
        // Validate frequency
        if (!in_array($frequency, ['daily', 'weekly', 'monthly'])) {
            Response::validationError('فرمت زمان‌بندی نامعتبر است');
        }
        
        // Validate time format
        if (!preg_match('/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/', $time)) {
            Response::validationError('فرمت زمان نامعتبر است');
        }
        
        // Validate retention
        if ($retention < 1 || $retention > 30) {
            Response::validationError('مدت نگهداری باید بین 1 تا 30 روز باشد');
        }
        
        // Update schedule settings
        $scheduleSettings = [
            'backup_schedule_enabled' => $enabled,
            'backup_schedule_frequency' => $frequency,
            'backup_schedule_time' => $time,
            'backup_retention_days' => $retention
        ];
        
        // Use settings model to store schedule configuration
        $settingsModel = new \Settings($this->db);
        
        $success = true;
        foreach ($scheduleSettings as $key => $value) {
            if (!$settingsModel->set($key, $value)) {
                $success = false;
                break;
            }
        }
        
        if (!$success) {
            Response::error('خطا در ذخیره تنظیمات زمان‌بندی', 500);
        }
        
        Response::success([
            'schedule' => $scheduleSettings
        ], 'تنظیمات زمان‌بندی با موفقیت به‌روزرسانی شد');
    }
    
    public function getSchedule() {
        $settingsModel = new \Settings($this->db);
        
        $schedule = [
            'enabled' => (int)$settingsModel->get('backup_schedule_enabled'),
            'frequency' => $settingsModel->get('backup_schedule_frequency'),
            'time' => $settingsModel->get('backup_schedule_time'),
            'retention' => (int)$settingsModel->get('backup_retention_days')
        ];
        
        Response::success([
            'schedule' => $schedule
        ]);
    }
    
    private function createBackup($type = 'full') {
        $backupContent = "-- CRM Backup\n";
        $backupContent .= "-- Generated: " . date('Y-m-d H:i:s') . "\n";
        $backupContent .= "-- Type: " . $type . "\n\n";
        
        // Get all tables
        $tables = $this->getAllTables();
        
        foreach ($tables as $table) {
            // Skip backup log table
            if ($table === 'backup_log') {
                continue;
            }
            
            // Add table structure if needed
            if ($type === 'full' || $type === 'structure') {
                $backupContent .= $this->getTableStructure($table);
            }
            
            // Add table data if needed
            if ($type === 'full' || $type === 'data') {
                $backupContent .= $this->getTableData($table);
            }
        }
        
        return $backupContent;
    }
    
    private function executeBackup($sqlContent) {
        // Split SQL content into statements
        $statements = array_filter(array_map('trim', explode(';', $sqlContent)));
        
        foreach ($statements as $statement) {
            if (empty($statement)) {
                continue;
            }
            
            // Skip comments and empty statements
            if (preg_match('/^--/', $statement) || preg_match('/^$/', $statement)) {
                continue;
            }
            
            // Execute statement
            $stmt = $this->db->prepare($statement);
            $stmt->execute();
        }
    }
    
    private function getAllTables() {
        $query = "SHOW TABLES";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        
        $tables = [];
        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $tables[] = $row[0];
        }
        
        return $tables;
    }
    
    private function getTableStructure($table) {
        $content = "-- Table structure for table `$table`\n";
        $content .= "DROP TABLE IF EXISTS `$table`;\n";
        
        $query = "SHOW CREATE TABLE `$table`";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        
        $row = $stmt->fetch(PDO::FETCH_NUM);
        $content .= $row[1] . ";\n\n";
        
        return $content;
    }
    
    private function getTableData($table) {
        $content = "-- Data for table `$table`\n";
        
        $query = "SELECT * FROM `$table`";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (empty($rows)) {
            return $content . "-- No data in table `$table`\n\n";
        }
        
        // Get column names
        $columns = array_keys($rows[0]);
        $columnList = '`' . implode('`, `', $columns) . '`';
        
        foreach ($rows as $row) {
            $values = [];
            foreach ($row as $value) {
                if ($value === null) {
                    $values[] = 'NULL';
                } else {
                    $values[] = $this->db->quote($value);
                }
            }
            
            $content .= "INSERT INTO `$table` ($columnList) VALUES (" . implode(', ', $values) . ");\n";
        }
        
        return $content . "\n";
    }
    
    private function validateBackupContent($content) {
        // Basic validation - should contain SQL statements
        return (bool)preg_match('/^(CREATE|INSERT|DROP|UPDATE|DELETE)/mi', trim($content));
    }
}