<?php
require_once __DIR__ . '/../helpers/response.php';
require_once __DIR__ . '/../helpers/request.php';
require_once __DIR__ . '/../helpers/security.php';
require_once __DIR__ . '/../models/Contact.php';

class ContactController {
    private $db;
    private $contactModel;

    public function __construct($database) {
        $this->db = $database;
        $this->contactModel = new Contact($this->db);
    }

    public function view($id) {
        $id = intval($id);
        if ($id <= 0) {
            Response::error('ID مخاطب نامعتبر است', 400);
        }

        $contact = $this->contactModel->findById($id);
        if (!$contact) {
            Response::error('مخاطب یافت نشد', 404);
        }

        Response::success(['contact' => $contact]);
    }

    public function list() {
        $query = $_GET['q'] ?? null;
        $category = $_GET['category'] ?? null;
        $page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : null;
        $limit = isset($_GET['limit']) ? max(1, intval($_GET['limit'])) : null;

        $filters = [];
        if ($query) { $filters['search'] = Security::sanitize($query); }
        if ($category) { $filters['category'] = Security::sanitize($category); }
        if ($page && $limit) {
            $filters['limit'] = $limit;
            $filters['offset'] = ($page - 1) * $limit;
        }

        $contacts = $this->contactModel->list($filters);
        $total = $this->contactModel->count($filters);

        Response::success([
            'contacts' => $contacts,
            'meta' => [
                'total' => $total,
                'page' => $page ?? 1,
                'limit' => $limit ?? count($contacts)
            ]
        ]);
    }

    public function create() {
        $data = Request::getJsonInput() ?? $_POST;

        Request::validateRequired(['name', 'mobile', 'category'], $data);

        $contactData = [
            'name' => Security::sanitize($data['name']),
            'mobile' => Security::sanitize($data['mobile']),
            'category' => Security::sanitize($data['category']),
            'notes' => isset($data['notes']) ? Security::sanitize($data['notes']) : null,
            'created_by' => isset($data['created_by']) ? (int)$data['created_by'] : null,
        ];

        // Validate mobile (basic Iran mobile regex) if available
        if (!empty($contactData['mobile']) && !Security::isValidMobile($contactData['mobile'])) {
            Response::validationError('شماره موبایل نامعتبر است');
        }

        $id = $this->contactModel->create($contactData);
        if (!$id) {
            Response::error('خطا در ایجاد مخاطب', 500);
        }

        $created = $this->contactModel->findById($id);
        Response::success([
            'contact' => $created
        ], 'مخاطب با موفقیت ایجاد شد', 201);
    }

    public function update($id) {
        $data = Request::getJsonInput() ?? $_POST;

        $updateData = [];
        if (isset($data['name'])) { $updateData['name'] = Security::sanitize($data['name']); }
        if (isset($data['mobile'])) {
            $mobile = Security::sanitize($data['mobile']);
            if (!Security::isValidMobile($mobile)) {
                Response::validationError('شماره موبایل نامعتبر است');
            }
            $updateData['mobile'] = $mobile;
        }
        if (isset($data['category'])) { $updateData['category'] = Security::sanitize($data['category']); }
        if (array_key_exists('notes', $data)) { $updateData['notes'] = Security::sanitize($data['notes']); }

        if (empty($updateData)) {
            Response::error('داده‌ای برای به‌روزرسانی وجود ندارد', 400);
        }

        $success = $this->contactModel->update($id, $updateData);
        if (!$success) {
            Response::error('خطا در به‌روزرسانی مخاطب', 500);
        }

        $updated = $this->contactModel->findById($id);
        Response::success([
            'contact' => $updated
        ], 'مخاطب با موفقیت به‌روزرسانی شد');
    }

    public function delete($id) {
        $success = $this->contactModel->delete($id);
        if (!$success) {
            Response::error('خطا در حذف مخاطب', 500);
        }
        Response::success(null, 'مخاطب با موفقیت حذف شد');
    }
}