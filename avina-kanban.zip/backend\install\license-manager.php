<?php
// backend/install/license-manager.php
// ساده و کاربرپسند برای تولید و مدیریت لایسنس ۱۶ رقمی فارسی (RTL)

header('Content-Type: text/html; charset=utf-8');

$licensesFile = __DIR__ . '/licenses.json';

function loadLicenses($path) {
    if (!file_exists($path)) return [];
    $data = json_decode(file_get_contents($path), true);
    return is_array($data) ? $data : [];
}

function saveLicenses($path, $licenses) {
    $dir = dirname($path);
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    file_put_contents($path, json_encode($licenses, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

function sanitize($s) { return htmlspecialchars(trim($s), ENT_QUOTES, 'UTF-8'); }

function generateLicense16() {
    // تولید ۱۶ رقم تصادفی امن
    $digits = '';
    for ($i = 0; $i < 16; $i++) { $digits .= random_int(0, 9); }
    return $digits;
}

// عملیات تولید
$message = null; $error = null; $generatedCode = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'generate') {
    $name = sanitize($_POST['name'] ?? '');
    $mobile = preg_replace('/[^0-9]/', '', $_POST['mobile'] ?? '');

    if ($name === '' || $mobile === '') {
        $error = 'نام و شماره موبایل الزامی است.';
    } else {
        $licenses = loadLicenses($licensesFile);
        // اطمینان از یکتا بودن کد
        do { $code = generateLicense16(); } while (array_filter($licenses, fn($l) => ($l['code'] ?? '') === $code));

        $entry = [
            'id' => bin2hex(random_bytes(8)),
            'name' => $name,
            'mobile' => $mobile,
            'code' => $code,
            'status' => 'new', // فقط پس از نصب موفق به used تغییر می‌کند
            'created_at' => date('Y-m-d H:i:s'),
            'used_at' => null,
            'domain' => null
        ];

        $licenses[] = $entry;
        saveLicenses($licensesFile, $licenses);
        $generatedCode = $code;
        $message = 'لایسنس جدید با موفقیت ایجاد شد.';
    }
}

$licenses = loadLicenses($licensesFile);
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>مدیریت لایسنس | نصب سیستم</title>
  <style>
    body { font-family: Vazirmatn, Tahoma, sans-serif; background:#0f172a; color:#e5e7eb; margin:0; }
    .container { max-width: 960px; margin: 40px auto; padding: 24px; background:#111827; border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,.3); }
    h1 { margin-top:0; font-size: 22px; }
    .grid { display:grid; grid-template-columns: 1fr 1fr; gap:24px; }
    .card { background:#0b1220; border:1px solid #1f2937; border-radius:10px; padding:16px; }
    label { display:block; margin-bottom:8px; color:#9ca3af; font-size:13px; }
    input { width:100%; padding:10px 12px; border-radius:8px; border:1px solid #374151; background:#0d1526; color:#e5e7eb; }
    button { background:#06b6d4; color:#00131a; border:none; padding:10px 14px; border-radius:8px; cursor:pointer; font-weight:700; }
    button:hover { background:#22d3ee; }
    .msg { margin-top:10px; font-size:13px; }
    .table { width:100%; border-collapse: collapse; margin-top: 12px; }
    .table th, .table td { border-bottom: 1px solid #1f2937; padding:8px 10px; font-size:13px; }
    .badge { display:inline-block; padding:4px 8px; border-radius:999px; font-size:12px; }
    .badge-new { background:#1f2937; color:#9ca3af; }
    .badge-used { background:#064e3b; color:#a7f3d0; }
    .flex { display:flex; gap:8px; align-items:center; }
    .copy { background:#334155; color:#cbd5e1; }
    .copy:hover { background:#475569; }
    .hint { color:#93c5fd; font-size:12px; margin-top:6px; }
  </style>
</head>
<body>
  <div class="container">
    <h1>مدیریت لایسنس نصب سیستم</h1>
    <div class="grid">
      <div class="card">
        <form method="post">
          <input type="hidden" name="action" value="generate" />
          <label>نام</label>
          <input type="text" name="name" placeholder="نام مشتری" required />
          <label style="margin-top:12px;">شماره موبایل</label>
          <input type="text" name="mobile" placeholder="0912xxxxxxx" required />
          <div style="margin-top:12px;" class="flex">
            <button type="submit">ایجاد لایسنس جدید</button>
            <?php if ($generatedCode): ?>
              <button type="button" class="copy" onclick="copyCode('<?php echo $generatedCode; ?>')">کپی کد</button>
            <?php endif; ?>
          </div>
          <?php if ($message): ?><div class="msg" style="color:#10b981;"><?php echo $message; ?></div><?php endif; ?>
          <?php if ($error): ?><div class="msg" style="color:#ef4444;"><?php echo $error; ?></div><?php endif; ?>
          <?php if ($generatedCode): ?><div class="hint">کد تولید شده: <strong><?php echo $generatedCode; ?></strong></div><?php endif; ?>
          <div class="hint">این کد ۱۶ رقمی را در مرحله لایسنس نصب وارد کنید.</div>
        </form>
      </div>
      <div class="card">
        <div class="flex" style="justify-content:space-between;">
          <div>لیست لایسنس‌ها</div>
          <button type="button" class="copy" onclick="refreshList()">بازخوانی</button>
        </div>
        <table class="table">
          <thead>
            <tr>
              <th>کد</th>
              <th>نام</th>
              <th>موبایل</th>
              <th>وضعیت</th>
              <th>دامنه</th>
              <th>اقدام</th>
            </tr>
          </thead>
          <tbody id="tbody">
            <?php foreach ($licenses as $lic): ?>
              <tr>
                <td style="font-family: monospace;"><?php echo sanitize($lic['code'] ?? ''); ?></td>
                <td><?php echo sanitize($lic['name'] ?? ''); ?></td>
                <td><?php echo sanitize($lic['mobile'] ?? ''); ?></td>
                <td>
                  <?php $st = $lic['status'] ?? 'new'; ?>
                  <span class="badge <?php echo $st === 'used' ? 'badge-used' : 'badge-new'; ?>">
                    <?php echo $st === 'used' ? 'مصرف شده' : 'جدید'; ?>
                  </span>
                </td>
                <td><?php echo sanitize($lic['domain'] ?? '—'); ?></td>
                <td><button class="copy" onclick="copyCode('<?php echo sanitize($lic['code'] ?? ''); ?>')">کپی</button></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <script>
    function copyCode(code) {
      navigator.clipboard.writeText(code).then(() => alert('کد کپی شد')).catch(() => alert('خطا در کپی'));
    }
    function refreshList() { window.location.reload(); }
  </script>
</body>
</html>