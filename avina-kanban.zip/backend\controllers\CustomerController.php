<?php
/**
 * Customer Controller
 * Handles customer management operations
 */

require_once '../helpers/response.php';
require_once '../helpers/security.php';
require_once '../helpers/jalali.php';
require_once '../models/Customer.php';

class CustomerController {
    
    private $db;
    private $customerModel;
    
    public function __construct($database) {
        $this->db = $database;
        $this->customerModel = new Customer($database);
    }
    
    public function list() {
        $filters = [];
        
        // Get filters from request
        if (isset($_GET['type'])) {
            $filters['type'] = Security::sanitize($_GET['type']);
        }
        
        if (isset($_GET['status'])) {
            $filters['status'] = Security::sanitize($_GET['status']);
        }
        
        if (isset($_GET['search'])) {
            $filters['search'] = Security::sanitize($_GET['search']);
        }
        
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $perPage = isset($_GET['per_page']) ? (int)$_GET['per_page'] : 20;
        
        $result = $this->customerModel->list($filters, $page, $perPage);
        
        Response::success([
            'customers' => $result['data'],
            'pagination' => [
                'total' => $result['total'],
                'page' => $result['page'],
                'per_page' => $result['per_page'],
                'total_pages' => $result['total_pages']
            ]
        ]);
    }

    public function exportCsv() {
        // Optional filters similar to list
        $filters = [];
        if (isset($_GET['type'])) { $filters['type'] = Security::sanitize($_GET['type']); }
        if (isset($_GET['status'])) { $filters['status'] = Security::sanitize($_GET['status']); }
        if (isset($_GET['search'])) { $filters['search'] = Security::sanitize($_GET['search']); }

        // Fetch all without pagination for export
        $result = $this->customerModel->list($filters, 1, 100000);
        $rows = $result['data'];

        // Build CSV header
        $headers = [
            'ID','نام','نام خانوادگی','موبایل','تلفن','ایمیل','شرکت','نوع','وضعیت','آدرس','توضیحات','تاریخ تولد','کد ملی','کد اقتصادی','شماره ثبت','ایجاد','به‌روز'
        ];

        $csv = implode(',', array_map([$this, 'escapeCsv'], $headers)) . "\n";

        foreach ($rows as $r) {
            $csvRow = [
                $r['id'] ?? '',
                $r['first_name'] ?? '',
                $r['last_name'] ?? '',
                $r['mobile'] ?? '',
                $r['phone'] ?? '',
                $r['email'] ?? '',
                $r['company'] ?? '',
                $r['type'] ?? '',
                $r['status'] ?? '',
                $r['address'] ?? '',
                $r['notes'] ?? '',
                $r['birth_date'] ? JalaliDate::toJalaliDate($r['birth_date']) : '',
                $r['national_id'] ?? '',
                $r['economic_code'] ?? '',
                $r['registration_number'] ?? '',
                isset($r['created_at']) ? JalaliDate::toJalaliDateTime($r['created_at']) : '',
                isset($r['updated_at']) ? JalaliDate::toJalaliDateTime($r['updated_at']) : ''
            ];
            $csv .= implode(',', array_map([$this, 'escapeCsv'], $csvRow)) . "\n";
        }

        Response::success([
            'filename' => 'customers_export_' . date('Ymd_His') . '.csv',
            'mime' => 'text/csv; charset=UTF-8',
            'data' => $csv
        ], 'اکسپورت مشتری‌ها آماده شد');
    }

    private function escapeCsv($value) {
        $v = (string)$value;
        $needQuotes = strpos($v, ',') !== false || strpos($v, '"') !== false || strpos($v, "\n") !== false || strpos($v, "\r") !== false;
        $v = str_replace('"', '""', $v);
        return $needQuotes ? '"' . $v . '"' : $v;
    }
    
    public function create() {
        $data = Request::getJsonInput();
        
        // Validate required fields
        $required = ['first_name', 'last_name', 'mobile'];
        $validation = Request::validateRequired($data, $required);
        
        if (!$validation['valid']) {
            Response::validationError('فیلدهای الزامی: ' . implode(', ', $validation['missing']));
        }
        
        // Sanitize input
        $customerData = [
            'first_name' => Security::sanitize($data['first_name']),
            'last_name' => Security::sanitize($data['last_name']),
            'mobile' => Security::sanitize($data['mobile']),
            'phone' => isset($data['phone']) ? Security::sanitize($data['phone']) : null,
            'email' => isset($data['email']) ? Security::sanitize($data['email']) : null,
            'company' => isset($data['company']) ? Security::sanitize($data['company']) : null,
            'type' => isset($data['type']) ? Security::sanitize($data['type']) : 'individual',
            'status' => isset($data['status']) ? Security::sanitize($data['status']) : 'active',
            'address' => isset($data['address']) ? Security::sanitize($data['address']) : null,
            'notes' => isset($data['notes']) ? Security::sanitize($data['notes']) : null,
            'birth_date' => isset($data['birth_date']) ? Security::sanitize($data['birth_date']) : null,
            'national_id' => isset($data['national_id']) ? Security::sanitize($data['national_id']) : null,
            'economic_code' => isset($data['economic_code']) ? Security::sanitize($data['economic_code']) : null,
            'registration_number' => isset($data['registration_number']) ? Security::sanitize($data['registration_number']) : null,
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        // Validate email if provided
        if ($customerData['email'] && !Security::isValidEmail($customerData['email'])) {
            Response::validationError('ایمیل نامعتبر است');
        }
        
        // Validate mobile number
        if (!Security::isValidMobile($customerData['mobile'])) {
            Response::validationError('شماره موبایل نامعتبر است');
        }
        
        // Validate type
        $validTypes = ['individual', 'company'];
        if (!in_array($customerData['type'], $validTypes)) {
            Response::validationError('نوع مشتری نامعتبر است');
        }
        
        // Validate status
        $validStatuses = ['active', 'inactive', 'suspended'];
        if (!in_array($customerData['status'], $validStatuses)) {
            Response::validationError('وضعیت نامعتبر است');
        }
        
        // Check if mobile already exists
        if ($this->customerModel->mobileExists($customerData['mobile'])) {
            Response::error('شماره موبایل قبلاً ثبت شده است', 409);
        }
        
        // Check if email already exists
        if ($customerData['email'] && $this->customerModel->emailExists($customerData['email'])) {
            Response::error('ایمیل قبلاً ثبت شده است', 409);
        }
        
        $customerId = $this->customerModel->create($customerData);
        
        if (!$customerId) {
            Response::error('خطا در ایجاد مشتری', 500);
        }
        
        // Get created customer
        $createdCustomer = $this->customerModel->findById($customerId);
        
        Response::success([
            'customer' => $createdCustomer
        ], 'مشتری با موفقیت ایجاد شد', 201);
    }
    
    public function update($id) {
        $data = Request::getJsonInput();
        
        // Check if customer exists
        $existingCustomer = $this->customerModel->findById($id);
        if (!$existingCustomer) {
            Response::error('مشتری یافت نشد', 404);
        }
        
        // Prepare update data
        $updateData = [];
        
        if (isset($data['first_name'])) {
            $updateData['first_name'] = Security::sanitize($data['first_name']);
        }
        
        if (isset($data['last_name'])) {
            $updateData['last_name'] = Security::sanitize($data['last_name']);
        }
        
        if (isset($data['mobile'])) {
            $mobile = Security::sanitize($data['mobile']);
            if (!Security::isValidMobile($mobile)) {
                Response::validationError('شماره موبایل نامعتبر است');
            }
            
            // Check if mobile is already taken by another customer
            if ($this->customerModel->mobileExists($mobile, $id)) {
                Response::error('شماره موبایل قبلاً توسط مشتری دیگری استفاده شده است', 409);
            }
            
            $updateData['mobile'] = $mobile;
        }
        
        if (isset($data['email'])) {
            $email = Security::sanitize($data['email']);
            if (!Security::isValidEmail($email)) {
                Response::validationError('ایمیل نامعتبر است');
            }
            
            // Check if email is already taken by another customer
            if ($this->customerModel->emailExists($email, $id)) {
                Response::error('ایمیل قبلاً توسط مشتری دیگری استفاده شده است', 409);
            }
            
            $updateData['email'] = $email;
        }
        
        if (isset($data['phone'])) {
            $updateData['phone'] = Security::sanitize($data['phone']);
        }
        
        if (isset($data['company'])) {
            $updateData['company'] = Security::sanitize($data['company']);
        }
        
        if (isset($data['type'])) {
            $type = Security::sanitize($data['type']);
            $validTypes = ['individual', 'company'];
            if (!in_array($type, $validTypes)) {
                Response::validationError('نوع مشتری نامعتبر است');
            }
            $updateData['type'] = $type;
        }
        
        if (isset($data['status'])) {
            $status = Security::sanitize($data['status']);
            $validStatuses = ['active', 'inactive', 'suspended'];
            if (!in_array($status, $validStatuses)) {
                Response::validationError('وضعیت نامعتبر است');
            }
            $updateData['status'] = $status;
        }
        
        if (isset($data['address'])) {
            $updateData['address'] = Security::sanitize($data['address']);
        }
        
        if (isset($data['notes'])) {
            $updateData['notes'] = Security::sanitize($data['notes']);
        }
        
        if (isset($data['birth_date'])) {
            $updateData['birth_date'] = Security::sanitize($data['birth_date']);
        }
        
        if (isset($data['national_id'])) {
            $updateData['national_id'] = Security::sanitize($data['national_id']);
        }
        
        if (isset($data['economic_code'])) {
            $updateData['economic_code'] = Security::sanitize($data['economic_code']);
        }
        
        if (isset($data['registration_number'])) {
            $updateData['registration_number'] = Security::sanitize($data['registration_number']);
        }
        
        if (empty($updateData)) {
            Response::error('داده‌ای برای به‌روزرسانی وجود ندارد', 400);
        }
        
        $updateData['updated_at'] = date('Y-m-d H:i:s');
        
        $success = $this->customerModel->update($id, $updateData);
        
        if (!$success) {
            Response::error('خطا در به‌روزرسانی مشتری', 500);
        }
        
        // Get updated customer
        $updatedCustomer = $this->customerModel->findById($id);
        
        Response::success([
            'customer' => $updatedCustomer
        ], 'مشتری با موفقیت به‌روزرسانی شد');
    }
    
    public function delete($id) {
        // Check if customer exists
        $existingCustomer = $this->customerModel->findById($id);
        if (!$existingCustomer) {
            Response::error('مشتری یافت نشد', 404);
        }
        
        // Check if customer has any related data (invoices, etc.)
        if ($this->customerModel->hasRelatedData($id)) {
            Response::error('امکان حذف مشتری با اطلاعات وابسته وجود ندارد', 400);
        }
        
        $success = $this->customerModel->delete($id);
        
        if (!$success) {
            Response::error('خطا در حذف مشتری', 500);
        }
        
        Response::success(null, 'مشتری با موفقیت حذف شد');
    }
}