-- Default data for Avina Kanban
-- Insert default admin user (password: admin)
INSERT INTO users (name, email, username, password, role, status, created_at) VALUES 
('مدیر سیستم', 'admin@avina.local', 'admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'active', NOW());

-- Insert default settings
INSERT INTO settings (key_name, value, type, description) VALUES
('app_name', 'آوینا کَنبَن', 'string', 'نام برنامه'),
('app_version', '1.0.0', 'string', 'نسخه برنامه'),
('app_timezone', 'Asia/Tehran', 'string', 'منطقه زمانی'),
('app_language', 'fa', 'string', 'زبان برنامه'),
('app_direction', 'rtl', 'string', 'جهت برنامه'),
('company_name', 'آوینا', 'string', 'نام شرکت'),
('company_logo', '', 'string', 'لوگوی شرکت'),
('company_address', '', 'text', 'آدرس شرکت'),
('company_phone', '', 'string', 'تلفن شرکت'),
('company_email', '', 'string', 'ایمیل شرکت'),
('invoice_prefix', 'INV-', 'string', 'پیش‌وند شماره فاکتور'),
('invoice_tax_rate', '9', 'number', 'نرخ مالیات (٪)'),
('invoice_currency', 'ریال', 'string', 'واحد پول'),
('task_default_priority', 'medium', 'string', 'اولویت پیش‌فرض تسک‌ها'),
('task_default_status', 'todo', 'string', 'وضعیت پیش‌فرض تسک‌ها'),
('email_smtp_host', '', 'string', 'SMTP Host'),
('email_smtp_port', '587', 'number', 'SMTP Port'),
('email_smtp_user', '', 'string', 'SMTP Username'),
('email_smtp_pass', '', 'string', 'SMTP Password'),
('email_from_address', '', 'string', 'آدرس ایمیل فرستنده'),
('email_from_name', '', 'string', 'نام فرستنده ایمیل'),
('backup_auto_enabled', '0', 'boolean', 'فعال‌سازی پشتیبان‌گیری خودکار'),
('backup_auto_frequency', 'daily', 'string', 'فرکانس پشتیبان‌گیری خودکار'),
('backup_auto_retention', '7', 'number', 'مدت نگهداری پشتیبان‌ها (روز)'),
('user_registration_enabled', '1', 'boolean', 'فعال‌سازی ثبت‌نام کاربران'),
('user_default_role', 'user', 'string', 'نقش پیش‌فرض کاربران جدید');

-- Insert default boards
INSERT INTO boards (name, description, color, created_by, created_at) VALUES
('پروژه اول', 'پروژه تستی برای شروع کار', '#007bff', 1, NOW()),
('پروژه دوم', 'پروژه دوم برای تست', '#28a745', 1, NOW());

-- Insert default columns for first board
INSERT INTO columns (board_id, name, color, position, created_at) VALUES
(1, 'در انتظار', '#6c757d', 1, NOW()),
(1, 'در حال انجام', '#007bff', 2, NOW()),
(1, 'تکمیل شده', '#28a745', 3, NOW()),
(1, 'آرشیو', '#dc3545', 4, NOW());

-- Insert default columns for second board
INSERT INTO columns (board_id, name, color, position, created_at) VALUES
(2, 'در انتظار', '#6c757d', 1, NOW()),
(2, 'در حال انجام', '#007bff', 2, NOW()),
(2, 'تکمیل شده', '#28a745', 3, NOW());

-- Insert default customers
INSERT INTO customers (name, email, phone, company, address, notes, status, created_by, created_at) VALUES
('مشتری تستی ۱', 'customer1@example.com', '09123456789', 'شرکت تست ۱', 'تهران، خیابان test', 'این یک مشتری تستی است', 'active', 1, NOW()),
('مشتری تستی ۲', 'customer2@example.com', '09876543210', 'شرکت تست ۲', 'اصفهان، خیابان demo', 'این هم یک مشتری تستی دیگر است', 'active', 1, NOW());

-- Insert default tasks
INSERT INTO tasks (title, description, column_id, assigned_to, customer_id, priority, status, due_date, estimated_hours, tags, created_by, created_at) VALUES
('تسک تستی ۱', 'این یک تسک تستی برای ستون اول است', 1, 1, 1, 'high', 'todo', DATE_ADD(NOW(), INTERVAL 3 DAY), 2.5, 'تست,آزمایش', 1, NOW()),
('تسک تستی ۲', 'این یک تسک تستی برای ستون دوم است', 2, 1, 2, 'medium', 'in_progress', DATE_ADD(NOW(), INTERVAL 5 DAY), 4, 'تست,دمو', 1, NOW()),
('تسک تستی ۳', 'این یک تسک تستی برای ستون سوم است', 3, 1, 1, 'low', 'done', DATE_ADD(NOW(), INTERVAL 1 DAY), 1.5, 'تست,کامل شده', 1, NOW());

-- Insert default task comments
INSERT INTO task_comments (task_id, user_id, comment, created_at) VALUES
(1, 1, 'این یک کامنت تستی برای تسک اول است', NOW()),
(2, 1, 'این هم یک کامنت تستی برای تسک دوم است', NOW());

-- Insert default task activities
INSERT INTO task_activities (task_id, user_id, action, old_value, new_value, created_at) VALUES
(1, 1, 'created', NULL, 'تسک ایجاد شد', NOW()),
(2, 1, 'status_changed', 'todo', 'in_progress', NOW()),
(3, 1, 'status_changed', 'in_progress', 'done', NOW());