<?php
/**
 * Installation script for Avina Kanban
 * Handles database setup and initial configuration
 */

require_once '../config/database.php';
require_once '../helpers/response.php';
require_once '../helpers/security.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

class Installer {
    
    private $db;
    private $config;
    
    public function __construct() {
        $this->config = [];
    }
    
    public function install($data) {
        try {
            // Validate input data
            $this->validateInstallData($data);
            
            // Test database connection
            $this->testDatabaseConnection($data);
            
            // Create configuration file
            $this->createConfigFile($data);
            
            // Create database tables
            $this->createDatabaseTables($data);
            
            // Create admin user
            $this->createAdminUser($data['admin']);
            
            // Insert default settings
            $this->insertDefaultSettings();
            
            // Insert default kanban columns
            $this->insertDefaultColumns();
            
            Response::success('نصب با موفقیت انجام شد. در حال انتقال به صفحه ورود...');
            
        } catch (Exception $e) {
            Response::error('خطا در فرآیند نصب: ' . $e->getMessage(), 500);
        }
    }
    
    private function validateInstallData($data) {
        $required = ['dbHost', 'dbName', 'dbUser', 'admin'];
        foreach ($required as $field) {
            if (empty($data[$field])) {
                throw new Exception("فیلد {$field} الزامی است");
            }
        }
        
        // Validate admin payload (expects name, email, password)
        if (empty($data['admin']['email']) || empty($data['admin']['password'])) {
            throw new Exception('اطلاعات مدیر سیستم کامل نیست');
        }
        
        if (!Security::isValidEmail($data['admin']['email'])) {
            throw new Exception('ایمیل مدیر معتبر نیست');
        }
        
        if (strlen($data['admin']['password']) < 6) {
            throw new Exception('رمز عبور مدیر باید حداقل 6 کاراکتر باشد');
        }
    }
    
    private function testDatabaseConnection($data) {
        try {
            $dsn = "mysql:host={$data['dbHost']};charset=utf8mb4";
            $pdo = new PDO($dsn, $data['dbUser'], $data['dbPass'] ?? '', [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
            
            // Try to create database if not exists
            $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$data['dbName']}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            
        } catch (PDOException $e) {
            throw new Exception('اتصال به دیتابیس ناموفق بود: ' . $e->getMessage());
        }
    }
    
    private function createConfigFile($data) {
        $config = [
            'db_host' => $data['dbHost'],
            'db_name' => $data['dbName'],
            'db_user' => $data['dbUser'],
            'db_pass' => $data['dbPass'] ?? '',
            'jwt_secret' => Security::generateToken(64),
            'app_key' => Security::generateToken(32),
            'installed_at' => date('Y-m-d H:i:s')
        ];
        
        $configPath = __DIR__ . '/../config/config.json';
        $configDir = dirname($configPath);
        
        if (!is_dir($configDir)) {
            mkdir($configDir, 0755, true);
        }
        
        if (!file_put_contents($configPath, json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE))) {
            throw new Exception('امکان ایجاد فایل پیکربندی وجود ندارد');
        }
        
        $this->config = $config;
    }
    
    private function createDatabaseTables($data) {
        try {
            $dsn = "mysql:host={$data['dbHost']};dbname={$data['dbName']};charset=utf8mb4";
            $this->db = new PDO($dsn, $data['dbUser'], $data['dbPass'] ?? '', [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
            
            $this->createTables();
            
        } catch (PDOException $e) {
            throw new Exception('ایجاد جداول دیتابیس ناموفق بود: ' . $e->getMessage());
        }
    }
    
    private function createTables() {
        $sqlFile = __DIR__ . '/install.sql';
        if (!file_exists($sqlFile)) {
            throw new Exception('فایل SQL یافت نشد');
        }
        
        $sql = file_get_contents($sqlFile);
        $statements = array_filter(array_map('trim', explode(';', $sql)));
        
        foreach ($statements as $statement) {
            if (!empty($statement)) {
                $this->db->exec($statement);
            }
        }
    }
    
    private function createAdminUser($adminData) {
        $hashedPassword = password_hash($adminData['password'], PASSWORD_DEFAULT);
        
        $stmt = $this->db->prepare("
            INSERT INTO users (name, email, password, role, status, created_at) 
            VALUES (:name, :email, :password, 'admin', 'active', NOW())
        ");
        
        $stmt->execute([
            ':name' => $adminData['name'],
            ':email' => $adminData['email'],
            ':password' => $hashedPassword
        ]);
    }
    
    private function insertDefaultSettings() {
        $settings = [
            ['key' => 'app_name', 'value' => 'Avina CRM', 'category' => 'general'],
            ['key' => 'app_version', 'value' => '1.0.0', 'category' => 'general'],
            ['key' => 'company_name', 'value' => '', 'category' => 'company'],
            ['key' => 'company_phone', 'value' => '', 'category' => 'company'],
            ['key' => 'company_address', 'value' => '', 'category' => 'company'],
            ['key' => 'currency', 'value' => 'IRR', 'category' => 'financial'],
            ['key' => 'tax_rate', 'value' => '9', 'category' => 'financial'],
            ['key' => 'timezone', 'value' => 'Asia/Tehran', 'category' => 'general'],
            ['key' => 'date_format', 'value' => 'Y/m/d', 'category' => 'general'],
            ['key' => 'time_format', 'value' => 'H:i', 'category' => 'general'],
            ['key' => 'language', 'value' => 'fa', 'category' => 'general'],
            ['key' => 'theme', 'value' => 'light', 'category' => 'appearance'],
            ['key' => 'items_per_page', 'value' => '20', 'category' => 'general'],
            ['key' => 'allow_registration', 'value' => '0', 'category' => 'security'],
            ['key' => 'email_verification', 'value' => '0', 'category' => 'security'],
            ['key' => 'backup_enabled', 'value' => '1', 'category' => 'backup'],
            ['key' => 'backup_frequency', 'value' => 'daily', 'category' => 'backup'],
            ['key' => 'backup_retention', 'value' => '30', 'category' => 'backup']
        ];
        
        $stmt = $this->db->prepare("
            INSERT INTO settings (key, value, category, created_at) 
            VALUES (:key, :value, :category, NOW())
        ");
        
        foreach ($settings as $setting) {
            $stmt->execute([
                ':key' => $setting['key'],
                ':value' => $setting['value'],
                ':category' => $setting['category']
            ]);
        }
    }
    
    private function insertDefaultColumns() {
        $columns = [
            ['title' => 'در انتظار', 'color' => '#fbbf24', 'position' => 1, 'is_default' => 1],
            ['title' => 'در حال انجام', 'color' => '#3b82f6', 'position' => 2, 'is_default' => 1],
            ['title' => 'انجام شده', 'color' => '#10b981', 'position' => 3, 'is_default' => 1]
        ];
        
        $stmt = $this->db->prepare("
            INSERT INTO kanban_columns (title, color, position, is_default, created_at) 
            VALUES (:title, :color, :position, :is_default, NOW())
        ");
        
        foreach ($columns as $column) {
            $stmt->execute([
                ':title' => $column['title'],
                ':color' => $column['color'],
                ':position' => $column['position'],
                ':is_default' => $column['is_default']
            ]);
        }
    }
    
    public function testDatabaseConnection($data) {
        try {
            $dsn = "mysql:host={$data['host']};charset=utf8mb4";
            $pdo = new PDO($dsn, $data['user'], $data['password'] ?? '', [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
            
            // Test query
            $pdo->query("SELECT 1");
            
            Response::success('اتصال به دیتابیس با موفقیت برقرار شد');
            
        } catch (PDOException $e) {
            Response::error('اتصال به دیتابیس ناموفق بود: ' . $e->getMessage());
        }
    }
    
    public function checkInstallationStatus() {
        $configPath = __DIR__ . '/../config/config.json';
        
        if (file_exists($configPath)) {
            Response::success('سیستم قبلاً نصب شده است', ['installed' => true]);
        } else {
            Response::success('سیستم نصب نشده است', ['installed' => false]);
        }
    }
}

// Handle API requests
try {
    $installer = new Installer();
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        Response::error('داده‌های ورودی معتبر نیستند');
    }
    
    $action = $input['action'] ?? '';
    
    switch ($action) {
        case 'install':
            $installer->install($input);
            break;
            
        case 'test_db':
            $installer->testDatabaseConnection($input);
            break;
            
        case 'check_status':
            $installer->checkInstallationStatus();
            break;
            
        default:
            Response::error('عملیات نامعتبر');
    }
    
} catch (Exception $e) {
    Response::error('خطای سرور: ' . $e->getMessage());
}