<?php
/**
 * Invoice Controller
 * Handles invoice management operations
 */

require_once '../helpers/response.php';
require_once '../helpers/security.php';
require_once '../helpers/jalali.php';
require_once '../models/Invoice.php';
require_once '../models/Customer.php';

class InvoiceController {
    
    private $db;
    private $invoiceModel;
    private $customerModel;
    
    public function __construct($database) {
        $this->db = $database;
        $this->invoiceModel = new Invoice($database);
        $this->customerModel = new Customer($database);
    }
    
    public function list() {
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
        $search = isset($_GET['search']) ? Security::sanitize($_GET['search']) : '';
        $status = isset($_GET['status']) ? Security::sanitize($_GET['status']) : '';
        $customerId = isset($_GET['customer_id']) ? (int)$_GET['customer_id'] : 0;
        $dateFrom = isset($_GET['date_from']) ? Security::sanitize($_GET['date_from']) : '';
        $dateTo = isset($_GET['date_to']) ? Security::sanitize($_GET['date_to']) : '';
        
        $result = $this->invoiceModel->list([
            'page' => $page,
            'limit' => $limit,
            'search' => $search,
            'status' => $status,
            'customer_id' => $customerId,
            'date_from' => $dateFrom,
            'date_to' => $dateTo
        ]);
        
        Response::success([
            'invoices' => $result['invoices'],
            'pagination' => $result['pagination']
        ]);
    }
    
    public function create() {
        $data = Request::getJsonInput();
        
        // Validate required fields
        $required = ['customer_id', 'items'];
        $validation = Request::validateRequired($data, $required);
        
        if (!$validation['valid']) {
            Response::validationError('فیلدهای الزامی: ' . implode(', ', $validation['missing']));
        }
        
        // Check if customer exists
        $customer = $this->customerModel->findById($data['customer_id']);
        if (!$customer) {
            Response::error('مشتری یافت نشد', 404);
        }
        
        // Validate items
        if (!is_array($data['items']) || empty($data['items'])) {
            Response::validationError('اقلام فاکتور الزامی است');
        }
        
        foreach ($data['items'] as $item) {
            if (!isset($item['description']) || !isset($item['quantity']) || !isset($item['unit_price'])) {
                Response::validationError('اقلام فاکتور باید شامل توضیحات، تعداد و قیمت واحد باشند');
            }
            
            if ((int)$item['quantity'] <= 0 || (float)$item['unit_price'] < 0) {
                Response::validationError('مقادیر اقلام فاکتور نامعتبر است');
            }
        }
        
        // Calculate totals
        $subtotal = 0;
        foreach ($data['items'] as $item) {
            $subtotal += (float)$item['quantity'] * (float)$item['unit_price'];
        }
        
        $tax = isset($data['tax']) ? (float)$data['tax'] : 0;
        $discount = isset($data['discount']) ? (float)$data['discount'] : 0;
        $total = $subtotal + $tax - $discount;
        
        // Generate invoice number
        $invoiceNumber = $this->generateInvoiceNumber();
        
        // Prepare invoice data
        $invoiceData = [
            'invoice_number' => $invoiceNumber,
            'customer_id' => (int)$data['customer_id'],
            'issue_date' => isset($data['issue_date']) ? Security::sanitize($data['issue_date']) : date('Y-m-d'),
            'due_date' => isset($data['due_date']) ? Security::sanitize($data['due_date']) : date('Y-m-d', strtotime('+30 days')),
            'subtotal' => $subtotal,
            'tax' => $tax,
            'discount' => $discount,
            'total' => $total,
            'status' => isset($data['status']) ? Security::sanitize($data['status']) : 'draft',
            'notes' => isset($data['notes']) ? Security::sanitize($data['notes']) : '',
            'terms' => isset($data['terms']) ? Security::sanitize($data['terms']) : ''
        ];
        
        // Validate dates
        if (!$this->validateDate($invoiceData['issue_date']) || !$this->validateDate($invoiceData['due_date'])) {
            Response::validationError('فرمت تاریخ نامعتبر است');
        }
        
        if (strtotime($invoiceData['due_date']) < strtotime($invoiceData['issue_date'])) {
            Response::validationError('تاریخ سررسید باید بعد از تاریخ صدور باشد');
        }
        
        // Start transaction
        $this->db->beginTransaction();
        
        try {
            // Create invoice
            $invoiceId = $this->invoiceModel->create($invoiceData);
            
            if (!$invoiceId) {
                throw new Exception('خطا در ایجاد فاکتور');
            }
            
            // Add items
            foreach ($data['items'] as $item) {
                $itemData = [
                    'invoice_id' => $invoiceId,
                    'description' => Security::sanitize($item['description']),
                    'quantity' => (int)$item['quantity'],
                    'unit_price' => (float)$item['unit_price'],
                    'total' => (int)$item['quantity'] * (float)$item['unit_price']
                ];
                
                $this->invoiceModel->addItem($itemData);
            }
            
            $this->db->commit();
            
            // Get created invoice with items
            $createdInvoice = $this->invoiceModel->findById($invoiceId);
            
            Response::success([
                'invoice' => $createdInvoice
            ], 'فاکتور با موفقیت ایجاد شد', 201);
            
        } catch (Exception $e) {
            $this->db->rollback();
            Response::error($e->getMessage(), 500);
        }
    }
    
    public function update($id) {
        $data = Request::getJsonInput();
        
        // Check if invoice exists
        $existingInvoice = $this->invoiceModel->findById($id);
        if (!$existingInvoice) {
            Response::error('فاکتور یافت نشد', 404);
        }
        
        // Prevent updating paid invoices
        if ($existingInvoice['status'] === 'paid') {
            Response::error('امکان ویرایش فاکتورهای پرداخت شده وجود ندارد', 400);
        }
        
        // Prepare update data
        $updateData = [];
        
        if (isset($data['customer_id'])) {
            // Check if customer exists
            $customer = $this->customerModel->findById($data['customer_id']);
            if (!$customer) {
                Response::error('مشتری یافت نشد', 404);
            }
            $updateData['customer_id'] = (int)$data['customer_id'];
        }
        
        if (isset($data['issue_date'])) {
            if (!$this->validateDate($data['issue_date'])) {
                Response::validationError('فرمت تاریخ صدور نامعتبر است');
            }
            $updateData['issue_date'] = Security::sanitize($data['issue_date']);
        }
        
        if (isset($data['due_date'])) {
            if (!$this->validateDate($data['due_date'])) {
                Response::validationError('فرمت تاریخ سررسید نامعتبر است');
            }
            $updateData['due_date'] = Security::sanitize($data['due_date']);
        }
        
        if (isset($data['status'])) {
            $status = Security::sanitize($data['status']);
            if (!in_array($status, ['draft', 'sent', 'paid', 'cancelled'])) {
                Response::validationError('وضعیت فاکتور نامعتبر است');
            }
            $updateData['status'] = $status;
        }
        
        if (isset($data['notes'])) {
            $updateData['notes'] = Security::sanitize($data['notes']);
        }
        
        if (isset($data['terms'])) {
            $updateData['terms'] = Security::sanitize($data['terms']);
        }
        
        if (isset($data['tax'])) {
            $updateData['tax'] = (float)$data['tax'];
        }
        
        if (isset($data['discount'])) {
            $updateData['discount'] = (float)$data['discount'];
        }
        
        if (empty($updateData)) {
            Response::error('داده‌ای برای به‌روزرسانی وجود ندارد', 400);
        }
        
        // Recalculate total if tax or discount changed
        if (isset($updateData['tax']) || isset($updateData['discount'])) {
            $tax = isset($updateData['tax']) ? $updateData['tax'] : $existingInvoice['tax'];
            $discount = isset($updateData['discount']) ? $updateData['discount'] : $existingInvoice['discount'];
            $subtotal = $existingInvoice['subtotal'];
            $updateData['total'] = $subtotal + $tax - $discount;
        }
        
        $updateData['updated_at'] = date('Y-m-d H:i:s');
        
        $success = $this->invoiceModel->update($id, $updateData);
        
        if (!$success) {
            Response::error('خطا در به‌روزرسانی فاکتور', 500);
        }
        
        // Get updated invoice
        $updatedInvoice = $this->invoiceModel->findById($id);
        
        Response::success([
            'invoice' => $updatedInvoice
        ], 'فاکتور با موفقیت به‌روزرسانی شد');
    }
    
    public function delete($id) {
        // Check if invoice exists
        $existingInvoice = $this->invoiceModel->findById($id);
        if (!$existingInvoice) {
            Response::error('فاکتور یافت نشد', 404);
        }
        
        // Prevent deleting paid invoices
        if ($existingInvoice['status'] === 'paid') {
            Response::error('امکان حذف فاکتورهای پرداخت شده وجود ندارد', 400);
        }
        
        $success = $this->invoiceModel->delete($id);
        
        if (!$success) {
            Response::error('خطا در حذف فاکتور', 500);
        }
        
        Response::success(null, 'فاکتور با موفقیت حذف شد');
    }
    
    public function view($id) {
        // Check if invoice exists
        $invoice = $this->invoiceModel->findById($id);
        if (!$invoice) {
            Response::error('فاکتور یافت نشد', 404);
        }
        
        // Get invoice items
        $items = $this->invoiceModel->getItems($id);
        
        // Get customer info
        $customer = $this->customerModel->findById($invoice['customer_id']);
        
        Response::success([
            'invoice' => $invoice,
            'items' => $items,
            'customer' => $customer
        ]);
    }
    
    public function statistics() {
        $stats = $this->invoiceModel->getStatistics();
        
        Response::success([
            'statistics' => $stats
        ]);
    }

    public function exportCsv() {
        // Filters
        $search = isset($_GET['search']) ? Security::sanitize($_GET['search']) : '';
        $status = isset($_GET['status']) ? Security::sanitize($_GET['status']) : '';
        $customerId = isset($_GET['customer_id']) ? (int)$_GET['customer_id'] : 0;
        $dateFrom = isset($_GET['date_from']) ? Security::sanitize($_GET['date_from']) : '';
        $dateTo = isset($_GET['date_to']) ? Security::sanitize($_GET['date_to']) : '';

        // Fetch large page for export
        $result = $this->invoiceModel->list([
            'page' => 1,
            'limit' => 100000,
            'search' => $search,
            'status' => $status,
            'customer_id' => $customerId,
            'date_from' => $dateFrom,
            'date_to' => $dateTo
        ]);

        $rows = $result['invoices'];

        $headers = ['شماره','مشتری','تاریخ صدور','تاریخ سررسید','زیرمجموع','مالیات','تخفیف','جمع کل','وضعیت','توضیحات'];
        $csv = implode(',', array_map([$this, 'escapeCsv'], $headers)) . "\n";

        foreach ($rows as $r) {
            $customer = $this->customerModel->findById($r['customer_id']);
            $csvRow = [
                $r['invoice_number'] ?? '',
                $customer ? (($customer['first_name'] ?? '') . ' ' . ($customer['last_name'] ?? '')) : '',
                isset($r['issue_date']) ? JalaliDate::toJalaliDate($r['issue_date']) : '',
                isset($r['due_date']) ? JalaliDate::toJalaliDate($r['due_date']) : '',
                $r['subtotal'] ?? 0,
                $r['tax'] ?? 0,
                $r['discount'] ?? 0,
                $r['total'] ?? 0,
                $r['status'] ?? '',
                $r['notes'] ?? ''
            ];
            $csv .= implode(',', array_map([$this, 'escapeCsv'], $csvRow)) . "\n";
        }

        Response::success([
            'filename' => 'invoices_export_' . date('Ymd_His') . '.csv',
            'mime' => 'text/csv; charset=UTF-8',
            'data' => $csv
        ], 'اکسپورت فاکتورها آماده شد');
    }
    
    private function generateInvoiceNumber() {
        $prefix = 'INV';
        $year = date('Y');
        $month = date('m');
        
        // Get last invoice number
        $lastNumber = $this->invoiceModel->getLastInvoiceNumber();
        $nextNumber = $lastNumber + 1;
        
        return $prefix . $year . $month . str_pad($nextNumber, 4, '0', STR_PAD_LEFT);
    }
    
    private function validateDate($date) {
        $d = DateTime::createFromFormat('Y-m-d', $date);
        return $d && $d->format('Y-m-d') === $date;
    }

    private function escapeCsv($value) {
        $v = (string)$value;
        $needQuotes = strpos($v, ',') !== false || strpos($v, '"') !== false || strpos($v, "\n") !== false || strpos($v, "\r") !== false;
        $v = str_replace('"', '""', $v);
        return $needQuotes ? '"' . $v . '"' : $v;
    }
}