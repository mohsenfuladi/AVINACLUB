<?php
/**
 * JWT Helper Class
 * Handles JWT token generation and validation
 */

class JWT {
    
    private static $secret;
    private static $algorithm = 'HS256';
    
    public static function init() {
        if (!self::$secret) {
            // Generate secret from config or use a default one
            $configFile = __DIR__ . '/../config/config.json';
            if (file_exists($configFile)) {
                $config = json_decode(file_get_contents($configFile), true);
                self::$secret = $config['jwt_secret'] ?? self::generateDefaultSecret();
            } else {
                self::$secret = self::generateDefaultSecret();
            }
        }
    }
    
    /**
     * Generate a default secret key
     */
    private static function generateDefaultSecret() {
        // This should be replaced with a proper secret in production
        return 'avina_kanban_jwt_secret_key_2024_secure_random_string';
    }
    
    /**
     * Generate JWT token
     */
    public static function generate($payload) {
        self::init();
        
        $header = [
            'typ' => 'JWT',
            'alg' => self::$algorithm
        ];
        
        $headerEncoded = self::base64UrlEncode(json_encode($header));
        $payloadEncoded = self::base64UrlEncode(json_encode($payload));
        
        $signature = hash_hmac('sha256', $headerEncoded . '.' . $payloadEncoded, self::$secret, true);
        $signatureEncoded = self::base64UrlEncode($signature);
        
        return $headerEncoded . '.' . $payloadEncoded . '.' . $signatureEncoded;
    }
    
    /**
     * Validate JWT token
     */
    public static function validate($token) {
        self::init();
        
        $parts = explode('.', $token);
        
        if (count($parts) !== 3) {
            throw new Exception('توکن نامعتبر است');
        }
        
        list($headerEncoded, $payloadEncoded, $signatureEncoded) = $parts;
        
        // Decode and validate header
        $header = json_decode(self::base64UrlDecode($headerEncoded), true);
        if (!$header || $header['alg'] !== self::$algorithm) {
            throw new Exception('الگوریتم توکن نامعتبر است');
        }
        
        // Decode payload
        $payload = json_decode(self::base64UrlDecode($payloadEncoded), true);
        if (!$payload) {
            throw new Exception('بار توکن نامعتبر است');
        }
        
        // Verify signature
        $signature = self::base64UrlDecode($signatureEncoded);
        $expectedSignature = hash_hmac('sha256', $headerEncoded . '.' . $payloadEncoded, self::$secret, true);
        
        if (!hash_equals($expectedSignature, $signature)) {
            throw new Exception('امضای توکن نامعتبر است');
        }
        
        // Check expiration
        if (isset($payload['exp']) && $payload['exp'] < time()) {
            throw new Exception('توکن منقضی شده است');
        }
        
        return $payload;
    }
    
    /**
     * Decode token without validation (for debugging)
     */
    public static function decode($token) {
        $parts = explode('.', $token);
        
        if (count($parts) !== 3) {
            throw new Exception('توکن نامعتبر است');
        }
        
        $payload = json_decode(self::base64UrlDecode($parts[1]), true);
        if (!$payload) {
            throw new Exception('بار توکن نامعتبر است');
        }
        
        return $payload;
    }
    
    /**
     * Base64 URL encode
     */
    private static function base64UrlEncode($data) {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }
    
    /**
     * Base64 URL decode
     */
    private static function base64UrlDecode($data) {
        return base64_decode(strtr($data, '-_', '+/'));
    }
    
    /**
     * Get user ID from token
     */
    public static function getUserId($token) {
        $payload = self::validate($token);
        return $payload['user_id'] ?? null;
    }
    
    /**
     * Get user role from token
     */
    public static function getUserRole($token) {
        $payload = self::validate($token);
        return $payload['role'] ?? null;
    }
    
    /**
     * Check if token is expired
     */
    public static function isExpired($token) {
        try {
            $payload = self::decode($token);
            return isset($payload['exp']) && $payload['exp'] < time();
        } catch (Exception $e) {
            return true;
        }
    }
    
    /**
     * Refresh token (extend expiration)
     */
    public static function refresh($token) {
        $payload = self::validate($token);
        
        // Remove old expiration
        unset($payload['exp']);
        
        // Generate new token with fresh expiration
        return self::generate($payload);
    }
}