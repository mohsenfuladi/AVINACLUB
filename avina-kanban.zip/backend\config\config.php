<?php
/**
 * Configuration File
 * System configuration settings
 */

// Database configuration
if (file_exists(__DIR__ . '/config.json')) {
    $config = json_decode(file_get_contents(__DIR__ . '/config.json'), true);
    
    if (!$config) {
        die('خطا در خواندن فایل پیکربندی');
    }
    
    // Database settings
    define('DB_HOST', $config['database']['host'] ?? 'localhost');
    define('DB_NAME', $config['database']['name']);
    define('DB_USER', $config['database']['user']);
    define('DB_PASS', $config['database']['password']);
    define('DB_CHARSET', $config['database']['charset'] ?? 'utf8mb4');
    
    // Application settings
    define('APP_NAME', $config['app']['name'] ?? 'Avina Kanban');
    define('APP_VERSION', $config['app']['version'] ?? '1.0.0');
    define('APP_URL', $config['app']['url'] ?? 'http://localhost');
    define('APP_TIMEZONE', $config['app']['timezone'] ?? 'Asia/Tehran');
    define('APP_LANGUAGE', $config['app']['language'] ?? 'fa');
    
    // Security settings
    define('JWT_SECRET', $config['security']['jwt_secret'] ?? bin2hex(random_bytes(32)));
    define('JWT_EXPIRATION', $config['security']['jwt_expiration'] ?? 86400); // 24 hours
    define('ENCRYPTION_KEY', $config['security']['encryption_key'] ?? bin2hex(random_bytes(32)));
    define('PASSWORD_SALT', $config['security']['password_salt'] ?? bin2hex(random_bytes(16)));
    
    // Email settings
    define('SMTP_HOST', $config['email']['smtp_host'] ?? '');
    define('SMTP_PORT', $config['email']['smtp_port'] ?? 587);
    define('SMTP_USER', $config['email']['smtp_user'] ?? '');
    define('SMTP_PASS', $config['email']['smtp_pass'] ?? '');
    define('SMTP_ENCRYPTION', $config['email']['smtp_encryption'] ?? 'tls');
    define('EMAIL_FROM', $config['email']['from_email'] ?? 'noreply@avinakanban.com');
    define('EMAIL_FROM_NAME', $config['email']['from_name'] ?? 'Avina Kanban');
    
    // Invoice settings
    define('INVOICE_PREFIX', $config['invoice']['prefix'] ?? 'AV');
    define('INVOICE_TAX_RATE', $config['invoice']['tax_rate'] ?? 9);
    define('INVOICE_CURRENCY', $config['invoice']['currency'] ?? 'IRR');
    
    // License settings
    define('LICENSE_KEY', $config['license']['key'] ?? '');
    define('LICENSE_VALIDATED', $config['license']['validated'] ?? false);
    
    // Backup settings
    define('BACKUP_RETENTION_DAYS', $config['backup']['retention_days'] ?? 30);
    define('BACKUP_SCHEDULE_ENABLED', $config['backup']['schedule_enabled'] ?? false);
    define('BACKUP_SCHEDULE_TIME', $config['backup']['schedule_time'] ?? '02:00');
    
} else {
    // Default configuration for installation
    define('DB_HOST', 'localhost');
    define('DB_NAME', '');
    define('DB_USER', '');
    define('DB_PASS', '');
    define('DB_CHARSET', 'utf8mb8');
    
    define('APP_NAME', 'Avina Kanban');
    define('APP_VERSION', '1.0.0');
    define('APP_URL', 'http://localhost');
    define('APP_TIMEZONE', 'Asia/Tehran');
    define('APP_LANGUAGE', 'fa');
    
    define('JWT_SECRET', bin2hex(random_bytes(32)));
    define('JWT_EXPIRATION', 86400);
    define('ENCRYPTION_KEY', bin2hex(random_bytes(32)));
    define('PASSWORD_SALT', bin2hex(random_bytes(16)));
    
    define('SMTP_HOST', '');
    define('SMTP_PORT', 587);
    define('SMTP_USER', '');
    define('SMTP_PASS', '');
    define('SMTP_ENCRYPTION', 'tls');
    define('EMAIL_FROM', 'noreply@avinakanban.com');
    define('EMAIL_FROM_NAME', 'Avina Kanban');
    
    define('INVOICE_PREFIX', 'AV');
    define('INVOICE_TAX_RATE', 9);
    define('INVOICE_CURRENCY', 'IRR');
    
    define('LICENSE_KEY', '');
    define('LICENSE_VALIDATED', false);
    
    define('BACKUP_RETENTION_DAYS', 30);
    define('BACKUP_SCHEDULE_ENABLED', false);
    define('BACKUP_SCHEDULE_TIME', '02:00');
}