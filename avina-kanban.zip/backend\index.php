<?php
/**
 * API Entry Point
 * Main entry point for all API requests
 */

// Set error reporting
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// Set timezone
date_default_timezone_set('Asia/Tehran');

// Start session
session_start();

// Define constants
define('API_VERSION', '1.0.0');
define('API_BASE_URL', '/api');
define('UPLOAD_DIR', __DIR__ . '/uploads/');
define('BACKUP_DIR', __DIR__ . '/backups/');

// Create necessary directories if they don't exist
$directories = [UPLOAD_DIR, BACKUP_DIR];
foreach ($directories as $dir) {
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
}

// Load configuration
require_once 'config/config.php';

// Load helper functions
require_once 'helpers/response.php';
require_once 'helpers/security.php';
require_once 'helpers/request.php';
require_once 'helpers/validation.php';

// Load database configuration
try {
    require_once 'config/database.php';
    $database = new Database();
    $db = $database->getConnection();
} catch (Exception $e) {
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'message' => 'خطای اتصال به پایگاه داده: ' . $e->getMessage()
    ]);
    exit;
}

// Check if system is installed
try {
    $query = "SELECT COUNT(*) FROM users";
    $stmt = $db->prepare($query);
    $stmt->execute();
} catch (Exception $e) {
    // System not installed, redirect to installation
    header('Location: /install/');
    exit;
}

// Load routes
require_once 'routes.php';