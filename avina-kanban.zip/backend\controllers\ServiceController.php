<?php
/**
 * Service Controller
 * Provides integration endpoints for external services (SMS)
 */

require_once '../helpers/response.php';
require_once '../helpers/security.php';
require_once '../helpers/request.php';
require_once '../helpers/SmsClient.php';
require_once '../models/Settings.php';

class ServiceController {

    private $db;
    private $settingsModel;

    public function __construct($database) {
        $this->db = $database;
        $this->settingsModel = new Settings($database);
    }

    public function sendSms() {
        $data = Request::getJsonInput();

        // Validate domain if configured
        $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
        $allowedDomainsCsv = $this->settingsModel->get('allowed_domains');
        if ($allowedDomainsCsv) {
            $allowed = array_filter(array_map('trim', explode(',', $allowedDomainsCsv)));
            if ($origin && !$this->isOriginAllowed($origin, $allowed)) {
                Response::forbidden('دامنه شما مجاز نیست');
            }
        }

        $type = $data['type'] ?? 'custom';
        $recipient = $data['recipient'] ?? null;
        if (!$recipient) {
            Response::validationError('فیلد recipient الزامی است');
        }

        $apiKey = $this->settingsModel->get('faraz_api_key');
        $originator = $this->settingsModel->get('faraz_originator') ?? '+9810001';
        if (!$apiKey) {
            Response::error('کلید API فراز SMS تنظیم نشده است', 500);
        }

        $client = new SmsClient($apiKey);
        $normalizedRecipient = SmsClient::normalizeIranMobile($recipient);

        if ($type === 'pattern') {
            $patternCode = $data['pattern_code'] ?? $this->settingsModel->get('faraz_otp_pattern_code');
            $values = $data['values'] ?? [];
            if (!$patternCode) {
                Response::validationError('کد الگو (pattern_code) الزامی است');
            }
            $resp = $client->sendPattern($patternCode, $originator, $normalizedRecipient, $values);
        } else {
            $message = $data['message'] ?? null;
            if (!$message) {
                Response::validationError('پیام الزامی است');
            }
            $resp = $client->send($originator, [$normalizedRecipient], $message);
        }

        if (!$resp['success']) {
            Response::error('ارسال پیامک ناموفق بود: ' . ($resp['error'] ?? 'unknown'), $resp['status'] ?: 500);
        }

        Response::success([
            'result' => $resp['data'] ?? null,
        ], 'پیامک با موفقیت ارسال شد');
    }

    private function isOriginAllowed($origin, $allowedDomains) {
        $host = parse_url($origin, PHP_URL_HOST) ?? $origin;
        foreach ($allowedDomains as $allowed) {
            if ($host === $allowed || (substr($allowed, 0, 2) === '*.' && str_ends_with($host, substr($allowed, 1)))) {
                return true;
            }
        }
        return false;
    }
}