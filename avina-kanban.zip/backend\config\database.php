<?php
/**
 * Database configuration and connection class
 */

class Database {
    private static $instance = null;
    private $connection;
    private $config;

    private function __construct() {
        $this->config = $this->loadConfig();
        $this->connect();
    }

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new Database();
        }
        return self::$instance;
    }

    public function getConnection() {
        return $this->connection;
    }

    private function loadConfig() {
        $configFile = __DIR__ . '/config.json';
        if (!file_exists($configFile)) {
            // Use default configuration for installation
            return [
                'db_host' => DB_HOST,
                'db_name' => DB_NAME,
                'db_user' => DB_USER,
                'db_pass' => DB_PASS,
                'db_charset' => DB_CHARSET
            ];
        }

        $config = json_decode(file_get_contents($configFile), true);
        if (!$config) {
            throw new Exception('فایل پیکربندی معتبر نیست.');
        }

        return [
            'db_host' => $config['database']['host'],
            'db_name' => $config['database']['name'],
            'db_user' => $config['database']['user'],
            'db_pass' => $config['database']['password'],
            'db_charset' => $config['database']['charset'] ?? 'utf8mb4'
        ];
    }

    private function connect() {
        $host = $this->config['db_host'];
        $dbname = $this->config['db_name'];
        $username = $this->config['db_user'];
        $password = $this->config['db_pass'];
        $charset = 'utf8mb4';

        try {
            $dsn = "mysql:host={$host};dbname={$dbname};charset={$charset}";
            $this->connection = new PDO($dsn, $username, $password, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
        } catch (PDOException $e) {
            throw new Exception('اتصال به دیتابیس ناموفق بود: ' . $e->getMessage());
        }
    }

    public function query($sql, $params = []) {
        try {
            $stmt = $this->connection->prepare($sql);
            $stmt->execute($params);
            return $stmt;
        } catch (PDOException $e) {
            throw new Exception('خطا در اجرای کوئری: ' . $e->getMessage());
        }
    }

    public function fetch($sql, $params = []) {
        $stmt = $this->query($sql, $params);
        return $stmt->fetch();
    }

    public function fetchAll($sql, $params = []) {
        $stmt = $this->query($sql, $params);
        return $stmt->fetchAll();
    }

    public function insert($table, $data) {
        // Support two calling styles:
        // 1) insert('table_name', ['col' => 'val'])
        // 2) insert('INSERT INTO table (..) VALUES (?, ...)', [val1, ...])

        // If $table looks like a full SQL INSERT statement, execute it directly
        if (is_string($table) && stripos(trim($table), 'insert') === 0) {
            $this->query($table, is_array($data) ? $data : []);
            return $this->connection->lastInsertId();
        }

        // Otherwise, treat as table + associative data
        $columns = implode(', ', array_keys($data));
        $placeholders = ':' . implode(', :', array_keys($data));
        $sql = "INSERT INTO {$table} ({$columns}) VALUES ({$placeholders})";

        $this->query($sql, $data);
        return $this->connection->lastInsertId();
    }

    public function update($table, $data, $where, $whereParams) {
        $set = [];
        foreach ($data as $key => $value) {
            $set[] = "{$key} = :{$key}";
        }
        $setClause = implode(', ', $set);
        
        $sql = "UPDATE {$table} SET {$setClause} WHERE {$where}";
        $params = array_merge($data, $whereParams);
        
        $stmt = $this->query($sql, $params);
        return $stmt->rowCount();
    }

    public function delete($table, $where, $params) {
        $sql = "DELETE FROM {$table} WHERE {$where}";
        $stmt = $this->query($sql, $params);
        return $stmt->rowCount();
    }

    // Convenience method to execute non-select queries and return affected rows
    public function execute($sql, $params = []) {
        $stmt = $this->query($sql, $params);
        return $stmt->rowCount();
    }

    public function beginTransaction() {
        return $this->connection->beginTransaction();
    }

    public function commit() {
        return $this->connection->commit();
    }

    public function rollback() {
        return $this->connection->rollback();
    }

    public function getConfig() {
        return $this->config;
    }
}

function getDatabase() {
    return Database::getInstance();
}