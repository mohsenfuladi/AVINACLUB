<?php
/**
 * Jalali (Shamsi) date helper
 * Provides conversion utilities between Gregorian and Jalali calendars.
 */

class JalaliDate {
    /**
     * Convert Gregorian date to Jalali.
     * @param int $g_y Gregorian year
     * @param int $g_m Gregorian month
     * @param int $g_d Gregorian day
     * @return array [j_y, j_m, j_d]
     */
    public static function gregorianToJalali($g_y, $g_m, $g_d) {
        $g_days_in_month = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
        $j_days_in_month = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29];

        $gy = $g_y - 1600;
        $gm = $g_m - 1;
        $gd = $g_d - 1;

        $g_day_no = 365 * $gy + self::div($gy + 3, 4) - self::div($gy + 99, 100) + self::div($gy + 399, 400);
        for ($i = 0; $i < $gm; ++$i) {
            $g_day_no += $g_days_in_month[$i];
        }
        if ($gm > 1 && self::isGregorianLeap($g_y)) {
            $g_day_no++;
        }
        $g_day_no += $gd;

        $j_day_no = $g_day_no - 79;

        $j_np = self::div($j_day_no, 12053);
        $j_day_no = $j_day_no % 12053;

        $jy = 979 + 33 * $j_np + 4 * self::div($j_day_no, 1461);

        $j_day_no %= 1461;
        if ($j_day_no >= 366) {
            $jy += self::div($j_day_no - 366, 365);
            $j_day_no = ($j_day_no - 366) % 365;
        }

        for ($i = 0; $i < 11 && $j_day_no >= $j_days_in_month[$i]; ++$i) {
            $j_day_no -= $j_days_in_month[$i];
        }
        $jm = $i + 1;
        $jd = $j_day_no + 1;

        return [$jy, $jm, $jd];
    }

    /**
     * Convert a `Y-m-d` string to Jalali `Y/m/d`.
     */
    public static function toJalaliDate($gregorianDateStr) {
        $dt = DateTime::createFromFormat('Y-m-d', $gregorianDateStr);
        if (!$dt) return $gregorianDateStr;
        [$jy, $jm, $jd] = self::gregorianToJalali((int)$dt->format('Y'), (int)$dt->format('m'), (int)$dt->format('d'));
        return sprintf('%04d/%02d/%02d', $jy, $jm, $jd);
    }

    /**
     * Convert a `Y-m-d H:i:s` string to Jalali `Y/m/d H:i`.
     */
    public static function toJalaliDateTime($gregorianDateTimeStr) {
        $dt = DateTime::createFromFormat('Y-m-d H:i:s', $gregorianDateTimeStr);
        if (!$dt) return $gregorianDateTimeStr;
        [$jy, $jm, $jd] = self::gregorianToJalali((int)$dt->format('Y'), (int)$dt->format('m'), (int)$dt->format('d'));
        return sprintf('%04d/%02d/%02d %02d:%02d', $jy, $jm, $jd, (int)$dt->format('H'), (int)$dt->format('i'));
    }

    private static function div($a, $b) { return intdiv($a, $b); }
    private static function isGregorianLeap($year) { return ($year % 4 == 0 && $year % 100 != 0) || ($year % 400 == 0); }
}