<?php
/**
 * Response helper functions
 */

class Response {
    
    /**
     * Send JSON response
     */
    public static function json($data, $statusCode = 200) {
        http_response_code($statusCode);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    /**
     * Send success response
     */
    public static function success($message, $data = null, $statusCode = 200) {
        // Allow passing array payload directly as the first argument.
        // If $message is an array and no explicit $data given, treat it as the full body.
        if (is_array($message) && $data === null) {
            // Merge with success flag to keep a consistent top-level shape.
            $payload = array_merge(['success' => true], $message);
            self::json($payload, $statusCode);
        } else {
            self::json([
                'success' => true,
                'message' => $message,
                'data' => $data
            ], $statusCode);
        }
    }
    
    /**
     * Send error response
     */
    public static function error($message, $statusCode = 400, $data = null) {
        self::json([
            'success' => false,
            'message' => $message,
            'data' => $data
        ], $statusCode);
    }
    
    /**
     * Send unauthorized response
     */
    public static function unauthorized($message = 'دسترسی غیرمجاز') {
        self::error($message, 401);
    }
    
    /**
     * Send forbidden response
     */
    public static function forbidden($message = 'دسترسی ممنوع') {
        self::error($message, 403);
    }
    
    /**
     * Send not found response
     */
    public static function notFound($message = 'موردی یافت نشد') {
        self::error($message, 404);
    }
    
    /**
     * Send validation error
     */
    public static function validationError($errors) {
        self::error('خطای اعتبارسنجی', 422, ['errors' => $errors]);
    }
    
    /**
     * Send paginated response
     */
    public static function paginated($data, $total, $page, $perPage, $message = 'موفقیت آمیز') {
        self::success($message, [
            'items' => $data,
            'total' => $total,
            'page' => $page,
            'per_page' => $perPage,
            'total_pages' => ceil($total / $perPage)
        ]);
    }
}

/**
 * Request helper functions
 */
class Request {
    
    /**
     * Get JSON input from request body
     */
    public static function getJsonInput() {
        $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
        
        if (strpos($contentType, 'application/json') !== false) {
            $input = file_get_contents('php://input');
            return json_decode($input, true);
        }
        
        return null;
    }
    
    /**
     * Get input data (supports both JSON and form data)
     */
    public static function getInput() {
        $jsonInput = self::getJsonInput();
        if ($jsonInput !== null) {
            return $jsonInput;
        }
        
        return $_POST;
    }
    
    /**
     * Get specific input value
     */
    public static function input($key, $default = null) {
        $data = self::getInput();
        return $data[$key] ?? $default;
    }
    
    /**
     * Validate required fields
     */
    public static function validateRequired($fields, $data = null) {
        if ($data === null) {
            $data = self::getInput();
        }
        
        $errors = [];
        foreach ($fields as $field) {
            if (!isset($data[$field]) || empty(trim($data[$field]))) {
                $errors[$field] = "فیلد {$field} الزامی است";
            }
        }
        
        if (!empty($errors)) {
            Response::validationError($errors);
        }
        
        return true;
    }
    
    /**
     * Get current method
     */
    public static function method() {
        return $_SERVER['REQUEST_METHOD'];
    }
    
    /**
     * Check if request is AJAX
     */
    public static function isAjax() {
        return isset($_SERVER['HTTP_X_REQUESTED_WITH']) && 
               strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    }
    
    /**
     * Get uploaded file
     */
    public static function file($key) {
        return $_FILES[$key] ?? null;
    }
    
    /**
     * Validate file upload
     */
    public static function validateFile($file, $allowedTypes = [], $maxSize = null) {
        if (!$file || $file['error'] !== UPLOAD_ERR_OK) {
            return 'فایل آپلود نشده است';
        }
        
        if (!empty($allowedTypes) && !in_array($file['type'], $allowedTypes)) {
            return 'نوع فایل مجاز نیست';
        }
        
        if ($maxSize && $file['size'] > $maxSize) {
            return 'حجم فایل بیش از حد مجاز است';
        }
        
        return true;
    }
}