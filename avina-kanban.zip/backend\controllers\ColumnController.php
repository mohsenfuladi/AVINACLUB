<?php
/**
 * Column Controller
 * Handles kanban column management operations
 */

require_once '../helpers/response.php';
require_once '../helpers/security.php';
require_once '../models/Column.php';

class ColumnController {
    
    private $db;
    private $columnModel;
    
    public function __construct($database) {
        $this->db = $database;
        $this->columnModel = new Column($database);
    }
    
    public function list() {
        $columns = $this->columnModel->list();
        
        Response::success([
            'columns' => $columns
        ]);
    }
    
    public function create() {
        $data = Request::getJsonInput();
        
        // Validate required fields
        $required = ['name'];
        $validation = Request::validateRequired($data, $required);
        
        if (!$validation['valid']) {
            Response::validationError('فیلدهای الزامی: ' . implode(', ', $validation['missing']));
        }
        
        // Sanitize input
        $columnData = [
            'name' => Security::sanitize($data['name']),
            'color' => isset($data['color']) ? Security::sanitize($data['color']) : '#6B7280',
            'position' => isset($data['position']) ? (int)$data['position'] : 0,
            'is_default' => isset($data['is_default']) ? (int)$data['is_default'] : 0
        ];
        
        // Validate color format
        if (!preg_match('/^#[0-9A-F]{6}$/i', $columnData['color'])) {
            Response::validationError('فرمت رنگ نامعتبر است');
        }
        
        $columnId = $this->columnModel->create($columnData);
        
        if (!$columnId) {
            Response::error('خطا در ایجاد ستون', 500);
        }
        
        // Get created column
        $createdColumn = $this->columnModel->findById($columnId);
        
        Response::success([
            'column' => $createdColumn
        ], 'ستون با موفقیت ایجاد شد', 201);
    }
    
    public function update($id) {
        $data = Request::getJsonInput();
        
        // Check if column exists
        $existingColumn = $this->columnModel->findById($id);
        if (!$existingColumn) {
            Response::error('ستون یافت نشد', 404);
        }
        
        // Prepare update data
        $updateData = [];
        
        if (isset($data['name'])) {
            $updateData['name'] = Security::sanitize($data['name']);
        }
        
        if (isset($data['color'])) {
            $color = Security::sanitize($data['color']);
            if (!preg_match('/^#[0-9A-F]{6}$/i', $color)) {
                Response::validationError('فرمت رنگ نامعتبر است');
            }
            $updateData['color'] = $color;
        }
        
        if (isset($data['position'])) {
            $updateData['position'] = (int)$data['position'];
        }
        
        if (isset($data['is_default'])) {
            $updateData['is_default'] = (int)$data['is_default'];
        }
        
        if (empty($updateData)) {
            Response::error('داده‌ای برای به‌روزرسانی وجود ندارد', 400);
        }
        
        $updateData['updated_at'] = date('Y-m-d H:i:s');
        
        $success = $this->columnModel->update($id, $updateData);
        
        if (!$success) {
            Response::error('خطا در به‌روزرسانی ستون', 500);
        }
        
        // Get updated column
        $updatedColumn = $this->columnModel->findById($id);
        
        Response::success([
            'column' => $updatedColumn
        ], 'ستون با موفقیت به‌روزرسانی شد');
    }
    
    public function delete($id) {
        // Check if column exists
        $existingColumn = $this->columnModel->findById($id);
        if (!$existingColumn) {
            Response::error('ستون یافت نشد', 404);
        }
        
        // Prevent deleting default columns
        if ($existingColumn['is_default']) {
            Response::error('امکان حذف ستون‌های پیش‌فرض وجود ندارد', 400);
        }
        
        // Check if column has tasks
        $taskCount = $this->columnModel->getTaskCount($id);
        if ($taskCount > 0) {
            Response::error('امکان حذف ستون با تسک‌های فعال وجود ندارد', 400);
        }
        
        $success = $this->columnModel->delete($id);
        
        if (!$success) {
            Response::error('خطا در حذف ستون', 500);
        }
        
        Response::success(null, 'ستون با موفقیت حذف شد');
    }
}