<?php
/**
 * Task Controller
 * Handles kanban task management operations
 */

require_once '../helpers/response.php';
require_once '../helpers/security.php';
require_once '../models/Task.php';
require_once '../models/Column.php';
require_once '../models/Customer.php';
require_once '../models/User.php';

class TaskController {
    
    private $db;
    private $taskModel;
    private $columnModel;
    private $customerModel;
    private $userModel;
    
    public function __construct($database) {
        $this->db = $database;
        $this->taskModel = new Task($database);
        $this->columnModel = new Column($database);
        $this->customerModel = new Customer($database);
        $this->userModel = new User($database);
    }
    
    public function list() {
        $filters = [];
        
        // Get filters from request
        if (isset($_GET['column_id'])) {
            $filters['column_id'] = (int)$_GET['column_id'];
        }
        
        if (isset($_GET['assigned_to'])) {
            $filters['assigned_to'] = (int)$_GET['assigned_to'];
        }
        
        if (isset($_GET['customer_id'])) {
            $filters['customer_id'] = (int)$_GET['customer_id'];
        }
        
        if (isset($_GET['priority'])) {
            $filters['priority'] = Security::sanitize($_GET['priority']);
        }
        
        if (isset($_GET['status'])) {
            $filters['status'] = Security::sanitize($_GET['status']);
        }
        
        if (isset($_GET['search'])) {
            $filters['search'] = Security::sanitize($_GET['search']);
        }
        
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $perPage = isset($_GET['per_page']) ? (int)$_GET['per_page'] : 20;
        
        $result = $this->taskModel->list($filters, $page, $perPage);
        
        Response::success([
            'tasks' => $result['data'],
            'pagination' => [
                'total' => $result['total'],
                'page' => $result['page'],
                'per_page' => $result['per_page'],
                'total_pages' => $result['total_pages']
            ]
        ]);
    }
    
    public function create() {
        $data = Request::getJsonInput();
        
        // Validate required fields
        $required = ['title', 'column_id'];
        $validation = Request::validateRequired($data, $required);
        
        if (!$validation['valid']) {
            Response::validationError('فیلدهای الزامی: ' . implode(', ', $validation['missing']));
        }
        
        // Check if column exists
        $column = $this->columnModel->findById($data['column_id']);
        if (!$column) {
            Response::error('ستون یافت نشد', 404);
        }
        
        // Check if customer exists (if provided)
        if (isset($data['customer_id']) && $data['customer_id']) {
            $customer = $this->customerModel->findById($data['customer_id']);
            if (!$customer) {
                Response::error('مشتری یافت نشد', 404);
            }
        }
        
        // Check if assigned user exists (if provided)
        if (isset($data['assigned_to']) && $data['assigned_to']) {
            $user = $this->userModel->findById($data['assigned_to']);
            if (!$user) {
                Response::error('کاربر یافت نشد', 404);
            }
        }
        
        // Sanitize input
        $taskData = [
            'title' => Security::sanitize($data['title']),
            'description' => isset($data['description']) ? Security::sanitize($data['description']) : null,
            'column_id' => (int)$data['column_id'],
            'priority' => isset($data['priority']) ? Security::sanitize($data['priority']) : 'medium',
            'status' => isset($data['status']) ? Security::sanitize($data['status']) : 'pending',
            'assigned_to' => isset($data['assigned_to']) ? (int)$data['assigned_to'] : null,
            'customer_id' => isset($data['customer_id']) ? (int)$data['customer_id'] : null,
            'due_date' => isset($data['due_date']) ? Security::sanitize($data['due_date']) : null,
            'tags' => isset($data['tags']) ? $data['tags'] : [],
            'attachments' => isset($data['attachments']) ? $data['attachments'] : [],
            'created_by' => $_SESSION['user']['user_id']
        ];
        
        // Validate priority
        $validPriorities = ['low', 'medium', 'high', 'urgent'];
        if (!in_array($taskData['priority'], $validPriorities)) {
            Response::validationError('اولویت نامعتبر است');
        }
        
        // Validate status
        $validStatuses = ['pending', 'in_progress', 'completed', 'cancelled'];
        if (!in_array($taskData['status'], $validStatuses)) {
            Response::validationError('وضعیت نامعتبر است');
        }
        
        // Validate due date format if provided
        if ($taskData['due_date'] && !strtotime($taskData['due_date'])) {
            Response::validationError('تاریخ سررسید نامعتبر است');
        }
        
        $taskId = $this->taskModel->create($taskData);
        
        if (!$taskId) {
            Response::error('خطا در ایجاد تسک', 500);
        }
        
        // Get created task with related data
        $createdTask = $this->taskModel->findById($taskId);
        
        Response::success([
            'task' => $createdTask
        ], 'تسک با موفقیت ایجاد شد', 201);
    }
    
    public function update($id) {
        $data = Request::getJsonInput();
        
        // Check if task exists
        $existingTask = $this->taskModel->findById($id);
        if (!$existingTask) {
            Response::error('تسک یافت نشد', 404);
        }
        
        // Check if column exists (if provided)
        if (isset($data['column_id'])) {
            $column = $this->columnModel->findById($data['column_id']);
            if (!$column) {
                Response::error('ستون یافت نشد', 404);
            }
        }
        
        // Check if customer exists (if provided)
        if (isset($data['customer_id']) && $data['customer_id']) {
            $customer = $this->customerModel->findById($data['customer_id']);
            if (!$customer) {
                Response::error('مشتری یافت نشد', 404);
            }
        }
        
        // Check if assigned user exists (if provided)
        if (isset($data['assigned_to']) && $data['assigned_to']) {
            $user = $this->userModel->findById($data['assigned_to']);
            if (!$user) {
                Response::error('کاربر یافت نشد', 404);
            }
        }
        
        // Prepare update data
        $updateData = [];
        
        if (isset($data['title'])) {
            $updateData['title'] = Security::sanitize($data['title']);
        }
        
        if (isset($data['description'])) {
            $updateData['description'] = Security::sanitize($data['description']);
        }
        
        if (isset($data['column_id'])) {
            $updateData['column_id'] = (int)$data['column_id'];
        }
        
        if (isset($data['priority'])) {
            $priority = Security::sanitize($data['priority']);
            $validPriorities = ['low', 'medium', 'high', 'urgent'];
            if (!in_array($priority, $validPriorities)) {
                Response::validationError('اولویت نامعتبر است');
            }
            $updateData['priority'] = $priority;
        }
        
        if (isset($data['status'])) {
            $status = Security::sanitize($data['status']);
            $validStatuses = ['pending', 'in_progress', 'completed', 'cancelled'];
            if (!in_array($status, $validStatuses)) {
                Response::validationError('وضعیت نامعتبر است');
            }
            $updateData['status'] = $status;
        }
        
        if (isset($data['assigned_to'])) {
            $updateData['assigned_to'] = $data['assigned_to'] ? (int)$data['assigned_to'] : null;
        }
        
        if (isset($data['customer_id'])) {
            $updateData['customer_id'] = $data['customer_id'] ? (int)$data['customer_id'] : null;
        }
        
        if (isset($data['due_date'])) {
            $dueDate = Security::sanitize($data['due_date']);
            if ($dueDate && !strtotime($dueDate)) {
                Response::validationError('تاریخ سررسید نامعتبر است');
            }
            $updateData['due_date'] = $dueDate;
        }
        
        if (isset($data['tags'])) {
            $updateData['tags'] = $data['tags'];
        }
        
        if (isset($data['attachments'])) {
            $updateData['attachments'] = $data['attachments'];
        }
        
        if (empty($updateData)) {
            Response::error('داده‌ای برای به‌روزرسانی وجود ندارد', 400);
        }
        
        $updateData['updated_at'] = date('Y-m-d H:i:s');
        
        $success = $this->taskModel->update($id, $updateData);
        
        if (!$success) {
            Response::error('خطا در به‌روزرسانی تسک', 500);
        }
        
        // Get updated task with related data
        $updatedTask = $this->taskModel->findById($id);
        
        Response::success([
            'task' => $updatedTask
        ], 'تسک با موفقیت به‌روزرسانی شد');
    }
    
    public function delete($id) {
        // Check if task exists
        $existingTask = $this->taskModel->findById($id);
        if (!$existingTask) {
            Response::error('تسک یافت نشد', 404);
        }
        
        $success = $this->taskModel->delete($id);
        
        if (!$success) {
            Response::error('خطا در حذف تسک', 500);
        }
        
        Response::success(null, 'تسک با موفقیت حذف شد');
    }
    
    public function assign() {
        $data = Request::getJsonInput();
        
        if (!isset($data['task_id']) || !isset($data['user_id'])) {
            Response::validationError('شناسه تسک و کاربر الزامی است');
        }
        
        $taskId = (int)$data['task_id'];
        $userId = (int)$data['user_id'];
        
        // Check if task exists
        $task = $this->taskModel->findById($taskId);
        if (!$task) {
            Response::error('تسک یافت نشد', 404);
        }
        
        // Check if user exists
        $user = $this->userModel->findById($userId);
        if (!$user) {
            Response::error('کاربر یافت نشد', 404);
        }
        
        // Assign task to user
        $success = $this->taskModel->assignToUser($taskId, $userId);
        
        if (!$success) {
            Response::error('خطا در تخصیص تسک', 500);
        }
        
        Response::success([
            'task_id' => $taskId,
            'assigned_to' => $userId,
            'assigned_to_name' => $user['full_name']
        ], 'تسک با موفقیت تخصیص داده شد');
    }
}