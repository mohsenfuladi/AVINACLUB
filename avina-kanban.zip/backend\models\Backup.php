<?php
/**
 * Backup Model
 * Handles database operations for backup management
 */

class Backup {
    
    private $db;
    
    public function __construct($database) {
        $this->db = $database;
    }
    
    /**
     * Find backup by ID
     */
    public function findById($id) {
        $query = "SELECT * FROM backup_log WHERE id = ?";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute([$id]);
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    /**
     * Find backup by filename
     */
    public function findByFilename($filename) {
        $query = "SELECT * FROM backup_log WHERE filename = ?";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute([$filename]);
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    /**
     * Create backup record
     */
    public function create($data) {
        $query = "INSERT INTO backup_log (name, filename, type, size, path, is_uploaded, created_at) 
                  VALUES (?, ?, ?, ?, ?, ?, NOW())";
        
        $stmt = $this->db->prepare($query);
        $result = $stmt->execute([
            $data['name'],
            $data['filename'],
            $data['type'],
            $data['size'],
            $data['path'],
            isset($data['is_uploaded']) ? $data['is_uploaded'] : 0
        ]);
        
        return $result ? $this->db->lastInsertId() : false;
    }
    
    /**
     * Update backup record
     */
    public function update($id, $data) {
        $fields = [];
        $params = [];
        
        foreach ($data as $key => $value) {
            $fields[] = "$key = ?";
            $params[] = $value;
        }
        
        $params[] = $id;
        
        $query = "UPDATE backup_log SET " . implode(', ', $fields) . " WHERE id = ?";
        
        $stmt = $this->db->prepare($query);
        return $stmt->execute($params);
    }
    
    /**
     * Soft delete backup record
     */
    public function delete($id) {
        $query = "UPDATE backup_log SET deleted_at = NOW() WHERE id = ?";
        
        $stmt = $this->db->prepare($query);
        return $stmt->execute([$id]);
    }
    
    /**
     * List backups with pagination
     */
    public function list($filters = []) {
        $where = ["deleted_at IS NULL"];
        $params = [];
        
        // Type filter
        if (!empty($filters['type'])) {
            $where[] = "type = ?";
            $params[] = $filters['type'];
        }
        
        // Source filter (uploaded or created)
        if (isset($filters['is_uploaded'])) {
            $where[] = "is_uploaded = ?";
            $params[] = $filters['is_uploaded'];
        }
        
        // Date range filter
        if (!empty($filters['date_from'])) {
            $where[] = "created_at >= ?";
            $params[] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $where[] = "created_at <= ?";
            $params[] = $filters['date_to'];
        }
        
        // Pagination
        $page = max(1, (int)($filters['page'] ?? 1));
        $limit = max(1, min(100, (int)($filters['limit'] ?? 10)));
        $offset = ($page - 1) * $limit;
        
        // Count query
        $countQuery = "SELECT COUNT(*) FROM backup_log WHERE " . implode(' AND ', $where);
        
        $countStmt = $this->db->prepare($countQuery);
        $countStmt->execute($params);
        $total = $countStmt->fetchColumn();
        
        // Main query
        $query = "SELECT * FROM backup_log WHERE " . implode(' AND ', $where) . " 
                  ORDER BY created_at DESC LIMIT $limit OFFSET $offset";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute($params);
        $backups = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $totalPages = ceil($total / $limit);
        
        return [
            'backups' => $backups,
            'pagination' => [
                'total' => $total,
                'page' => $page,
                'limit' => $limit,
                'total_pages' => $totalPages
            ]
        ];
    }
    
    /**
     * Record restore operation
     */
    public function recordRestore($backupId) {
        $query = "UPDATE backup_log SET restored_at = NOW() WHERE id = ?";
        
        $stmt = $this->db->prepare($query);
        return $stmt->execute([$backupId]);
    }
    
    /**
     * Get backup statistics
     */
    public function getStatistics() {
        $stats = [];
        
        // Total backups
        $query = "SELECT COUNT(*) FROM backup_log WHERE deleted_at IS NULL";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $stats['total_backups'] = $stmt->fetchColumn();
        
        // Backups by type
        $query = "SELECT type, COUNT(*) as count FROM backup_log WHERE deleted_at IS NULL GROUP BY type";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $stats['by_type'] = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
        
        // Total size
        $query = "SELECT SUM(size) FROM backup_log WHERE deleted_at IS NULL";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $stats['total_size'] = $stmt->fetchColumn() ?? 0;
        
        // Recent backups (last 7 days)
        $query = "SELECT COUNT(*) FROM backup_log WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) AND deleted_at IS NULL";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $stats['recent_backups'] = $stmt->fetchColumn();
        
        // Oldest backup
        $query = "SELECT created_at FROM backup_log WHERE deleted_at IS NULL ORDER BY created_at ASC LIMIT 1";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $stats['oldest_backup'] = $stmt->fetchColumn();
        
        // Latest backup
        $query = "SELECT created_at FROM backup_log WHERE deleted_at IS NULL ORDER BY created_at DESC LIMIT 1";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $stats['latest_backup'] = $stmt->fetchColumn();
        
        return $stats;
    }
    
    /**
     * Clean old backups based on retention policy
     */
    public function cleanup($retentionDays = 7) {
        $query = "SELECT id, path FROM backup_log WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY) AND deleted_at IS NULL";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute([$retentionDays]);
        
        $oldBackups = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $deletedCount = 0;
        
        foreach ($oldBackups as $backup) {
            try {
                // Delete physical file
                if (file_exists($backup['path'])) {
                    unlink($backup['path']);
                }
                
                // Mark as deleted in database
                $this->delete($backup['id']);
                
                $deletedCount++;
                
            } catch (Exception $e) {
                // Log error but continue with other backups
                error_log("Failed to delete backup {$backup['id']}: " . $e->getMessage());
            }
        }
        
        return $deletedCount;
    }
    
    /**
     * Get backup by date range
     */
    public function getByDateRange($startDate, $endDate) {
        $query = "SELECT * FROM backup_log WHERE created_at BETWEEN ? AND ? AND deleted_at IS NULL ORDER BY created_at DESC";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute([$startDate, $endDate]);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Check if backup name exists
     */
    public function nameExists($name, $excludeId = null) {
        $query = "SELECT COUNT(*) FROM backup_log WHERE name = ? AND deleted_at IS NULL";
        $params = [$name];
        
        if ($excludeId) {
            $query .= " AND id != ?";
            $params[] = $excludeId;
        }
        
        $stmt = $this->db->prepare($query);
        $stmt->execute($params);
        
        return $stmt->fetchColumn() > 0;
    }
    
    /**
     * Update backup verification status
     */
    public function updateVerification($id, $isValid, $error = null) {
        $query = "UPDATE backup_log SET is_verified = ?, verification_error = ?, verified_at = NOW() WHERE id = ?";
        
        $stmt = $this->db->prepare($query);
        return $stmt->execute([$isValid ? 1 : 0, $error, $id]);
    }
}