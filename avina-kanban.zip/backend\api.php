<?php
/**
 * Main API router for Avina Kanban
 * Handles all API endpoints and routes requests to appropriate controllers
 */

require_once 'config/database.php';
require_once 'helpers/response.php';
require_once 'helpers/security.php';

// Set headers for CORS and JSON response
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Start session for CSRF protection
session_start();

class ApiRouter {
    
    private $db;
    private $endpoint;
    private $action;
    private $method;
    
    public function __construct() {
        $this->db = getDatabase();
        $this->method = $_SERVER['REQUEST_METHOD'];
        $this->parseRequest();
    }
    
    private function parseRequest() {
        $this->endpoint = isset($_GET['endpoint']) ? $_GET['endpoint'] : '';
        $this->action = isset($_GET['action']) ? $_GET['action'] : '';
    }
    
    public function route() {
        try {
            if (empty($this->endpoint)) {
                Response::error('endpoint مورد نیاز است', 400);
            }
            
            switch ($this->endpoint) {
                case 'auth':
                    $this->handleAuth();
                    break;
                    
                case 'users':
                    $this->handleUsers();
                    break;
                    
                case 'customers':
                    $this->handleCustomers();
                    break;
                    
                case 'tasks':
                    $this->handleTasks();
                    break;
                    
                case 'columns':
                    $this->handleColumns();
                    break;
                    
                case 'contacts':
                    $this->handleContacts();
                    break;
                    
                case 'invoices':
                    $this->handleInvoices();
                    break;
                    
                case 'settings':
                    $this->handleSettings();
                    break;
                    
                case 'system':
                    $this->handleSystem();
                    break;
                    
                case 'services':
                    $this->handleServices();
                    break;
                    
                default:
                    Response::error('endpoint ناشناخته', 404);
            }
            
        } catch (Exception $e) {
            Response::error('خطای سرور: ' . $e->getMessage(), 500);
        }
    }
    
    private function handleAuth() {
        require_once 'controllers/AuthController.php';
        $controller = new AuthController($this->db);
        
        switch ($this->action) {
            case 'login':
                $this->requireMethod('POST');
                $controller->login();
                break;
                
            case 'register':
                $this->requireMethod('POST');
                $controller->register();
                break;

            case 'requestOtp':
                $this->requireMethod('POST');
                $controller->requestOtp();
                break;

            case 'verifyOtp':
                $this->requireMethod('POST');
                $controller->verifyOtp();
                break;
                
            case 'logout':
                $this->requireMethod('POST');
                $this->requireAuth();
                $controller->logout();
                break;
                
            case 'profile':
                $this->requireMethod('GET');
                $this->requireAuth();
                $controller->profile();
                break;
                
            case 'updateProfile':
                $this->requireMethod('PUT');
                $this->requireAuth();
                $controller->updateProfile();
                break;
                
            case 'changePassword':
                $this->requireMethod('POST');
                $this->requireAuth();
                $controller->changePassword();
                break;
                
            default:
                Response::error('action نامعتبر برای auth', 400);
        }
    }
    
    private function handleUsers() {
        require_once 'controllers/UserController.php';
        $controller = new UserController($this->db);
        
        switch ($this->action) {
            case 'list':
                $this->requireMethod('GET');
                $this->requireAuth();
                $this->requirePermission('read');
                $controller->list();
                break;
                
            case 'create':
                $this->requireMethod('POST');
                $this->requireAuth();
                $this->requirePermission('write');
                $controller->create();
                break;
                
            case 'update':
                $this->requireMethod('PUT');
                $this->requireAuth();
                $this->requirePermission('update');
                $id = $_GET['id'] ?? null;
                if (!$id) {
                    Response::error('ID کاربر مورد نیاز است', 400);
                }
                $controller->update($id);
                break;
                
            case 'delete':
                $this->requireMethod('DELETE');
                $this->requireAuth();
                $this->requirePermission('delete');
                $id = $_GET['id'] ?? null;
                if (!$id) {
                    Response::error('ID کاربر مورد نیاز است', 400);
                }
                $controller->delete($id);
                break;
                
            default:
                Response::error('action نامعتبر برای users', 400);
        }
    }
    
    private function handleCustomers() {
        require_once 'controllers/CustomerController.php';
        $controller = new CustomerController($this->db);
        
        switch ($this->action) {
            case 'list':
                $this->requireMethod('GET');
                $this->requireAuth();
                $controller->list();
                break;
                
            case 'view':
                $this->requireMethod('GET');
                $this->requireAuth();
                $id = $_GET['id'] ?? null;
                if (!$id) {
                    Response::error('ID مخاطب مورد نیاز است', 400);
                }
                $controller->view($id);
                break;

            case 'create':
                $this->requireMethod('POST');
                $this->requireAuth();
                $controller->create();
                break;
                
            case 'update':
                $this->requireMethod('PUT');
                $this->requireAuth();
                $id = $_GET['id'] ?? null;
                if (!$id) {
                    Response::error('ID مشتری مورد نیاز است', 400);
                }
                $controller->update($id);
                break;
                
            case 'delete':
                $this->requireMethod('DELETE');
                $this->requireAuth();
                $id = $_GET['id'] ?? null;
                if (!$id) {
                    Response::error('ID مشتری مورد نیاز است', 400);
                }
                $controller->delete($id);
                break;

            case 'export':
                $this->requireMethod('GET');
                $this->requireAuth();
                $this->requirePermission('read');
                $controller->exportCsv();
                break;
                
            default:
                Response::error('action نامعتبر برای customers', 400);
        }
    }
    
    private function handleTasks() {
        require_once 'controllers/TaskController.php';
        $controller = new TaskController($this->db);
        
        switch ($this->action) {
            case 'list':
                $this->requireMethod('GET');
                $this->requireAuth();
                $controller->list();
                break;
                
            case 'create':
                $this->requireMethod('POST');
                $this->requireAuth();
                $controller->create();
                break;
                
            case 'update':
                $this->requireMethod('PUT');
                $this->requireAuth();
                $id = $_GET['id'] ?? null;
                if (!$id) {
                    Response::error('ID تسک مورد نیاز است', 400);
                }
                $controller->update($id);
                break;
                
            case 'delete':
                $this->requireMethod('DELETE');
                $this->requireAuth();
                $id = $_GET['id'] ?? null;
                if (!$id) {
                    Response::error('ID تسک مورد نیاز است', 400);
                }
                $controller->delete($id);
                break;
                
            case 'assign':
                $this->requireMethod('POST');
                $this->requireAuth();
                $controller->assign();
                break;
                
            default:
                Response::error('action نامعتبر برای tasks', 400);
        }
    }
    
    private function handleColumns() {
        require_once 'controllers/ColumnController.php';
        $controller = new ColumnController($this->db);
        
        switch ($this->action) {
            case 'list':
                $this->requireMethod('GET');
                $this->requireAuth();
                $controller->list();
                break;
                
            case 'create':
                $this->requireMethod('POST');
                $this->requireAuth();
                $controller->create();
                break;
                
            case 'update':
                $this->requireMethod('PUT');
                $this->requireAuth();
                $id = $_GET['id'] ?? null;
                if (!$id) {
                    Response::error('ID ستون مورد نیاز است', 400);
                }
                $controller->update($id);
                break;
                
            case 'delete':
                $this->requireMethod('DELETE');
                $this->requireAuth();
                $id = $_GET['id'] ?? null;
                if (!$id) {
                    Response::error('ID ستون مورد نیاز است', 400);
                }
                $controller->delete($id);
                break;
                
            default:
                Response::error('action نامعتبر برای columns', 400);
        }
    }
    
    private function handleContacts() {
        require_once 'controllers/ContactController.php';
        $controller = new ContactController($this->db);
        
        switch ($this->action) {
            case 'list':
                $this->requireMethod('GET');
                $this->requireAuth();
                $controller->list();
                break;
                
            case 'create':
                $this->requireMethod('POST');
                $this->requireAuth();
                $controller->create();
                break;
                
            case 'update':
                $this->requireMethod('PUT');
                $this->requireAuth();
                $id = $_GET['id'] ?? null;
                if (!$id) {
                    Response::error('ID مخاطب مورد نیاز است', 400);
                }
                $controller->update($id);
                break;
                
            case 'delete':
                $this->requireMethod('DELETE');
                $this->requireAuth();
                $id = $_GET['id'] ?? null;
                if (!$id) {
                    Response::error('ID مخاطب مورد نیاز است', 400);
                }
                $controller->delete($id);
                break;
                
            default:
                Response::error('action نامعتبر برای contacts', 400);
        }
    }
    
    private function handleInvoices() {
        require_once 'controllers/InvoiceController.php';
        $controller = new InvoiceController($this->db);
        
        switch ($this->action) {
            case 'list':
                $this->requireMethod('GET');
                $this->requireAuth();
                $controller->list();
                break;
                
            case 'create':
                $this->requireMethod('POST');
                $this->requireAuth();
                $controller->create();
                break;
                
            case 'update':
                $this->requireMethod('PUT');
                $this->requireAuth();
                $id = $_GET['id'] ?? null;
                if (!$id) {
                    Response::error('ID فاکتور مورد نیاز است', 400);
                }
                $controller->update($id);
                break;
                
            case 'delete':
                $this->requireMethod('DELETE');
                $this->requireAuth();
                $id = $_GET['id'] ?? null;
                if (!$id) {
                    Response::error('ID فاکتور مورد نیاز است', 400);
                }
                $controller->delete($id);
                break;

            case 'export':
                $this->requireMethod('GET');
                $this->requireAuth();
                $this->requirePermission('read');
                $controller->exportCsv();
                break;
                
            default:
                Response::error('action نامعتبر برای invoices', 400);
        }
    }
    
    private function handleSettings() {
        require_once 'controllers/SettingsController.php';
        $controller = new SettingsController($this->db);
        
        switch ($this->action) {
            case 'get':
                $this->requireMethod('GET');
                $this->requireAuth();
                $controller->get();
                break;
                
            case 'update':
                $this->requireMethod('PUT');
                $this->requireAuth();
                $controller->update();
                break;
                
            case 'reset':
                $this->requireMethod('POST');
                $this->requireAuth();
                $controller->reset();
                break;
                
            default:
                Response::error('action نامعتبر برای settings', 400);
        }
    }
    
    private function handleSystem() {
        require_once 'controllers/SystemController.php';
        $controller = new SystemController($this->db);
        
        switch ($this->action) {
            case 'status':
                $this->requireMethod('GET');
                $controller->status();
                break;
                
            case 'backup':
                $this->requireMethod('POST');
                $this->requireAuth();
                $this->requirePermission('admin');
                $controller->backup();
                break;
                
            case 'restore':
                $this->requireMethod('POST');
                $this->requireAuth();
                $this->requirePermission('admin');
                $controller->restore();
                break;
                
            case 'stats':
                $this->requireMethod('GET');
                $this->requireAuth();
                $controller->stats();
                break;
                
            default:
                Response::error('action نامعتبر برای system', 400);
        }
    }
    
    private function handleServices() {
        require_once 'controllers/ServiceController.php';
        $controller = new ServiceController($this->db);
        
        switch ($this->action) {
            case 'sms':
                $this->requireMethod('POST');
                $this->requireAuth();
                $controller->sendSms();
                break;
                
            default:
                Response::error('action نامعتبر برای services', 400);
        }
    }
    
    private function requireMethod($method) {
        if ($this->method !== $method) {
            Response::error("متد درخواست باید {$method} باشد", 405);
        }
    }
    
    private function requireAuth() {
        $user = Security::isAuthenticated();
        if (!$user) {
            Response::unauthorized('نیاز به احراز هویت دارید');
        }
        
        // Store user data for later use
        $_SESSION['user'] = $user;
    }
    
    private function requirePermission($permission) {
        if (!isset($_SESSION['user'])) {
            Response::unauthorized('نیاز به احراز هویت دارید');
        }
        
        $userRole = $_SESSION['user']['role'] ?? 'viewer';
        if (!Security::hasPermission($userRole, $permission)) {
            Response::forbidden('شما دسترسی لازم برای این عملیات را ندارید');
        }
    }
}

// Initialize and route the request
try {
    $router = new ApiRouter();
    $router->route();
} catch (Exception $e) {
    Response::error('خطای سرور: ' . $e->getMessage(), 500);
}