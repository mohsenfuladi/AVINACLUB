<?php
/**
 * Invoice Model
 * Handles database operations for invoices
 */

class Invoice {
    
    private $db;
    
    public function __construct($database) {
        $this->db = $database;
    }
    
    /**
     * Find invoice by ID
     */
    public function findById($id) {
        $query = "SELECT i.*, c.name as customer_name, c.company, c.mobile, c.email 
                  FROM invoices i 
                  LEFT JOIN customers c ON i.customer_id = c.id 
                  WHERE i.id = ? AND i.deleted_at IS NULL";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute([$id]);
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    /**
     * Find invoice by number
     */
    public function findByNumber($invoiceNumber) {
        $query = "SELECT i.*, c.name as customer_name, c.company, c.mobile, c.email 
                  FROM invoices i 
                  LEFT JOIN customers c ON i.customer_id = c.id 
                  WHERE i.invoice_number = ? AND i.deleted_at IS NULL";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute([$invoiceNumber]);
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    /**
     * Check if invoice number exists
     */
    public function invoiceNumberExists($invoiceNumber, $excludeId = null) {
        $query = "SELECT COUNT(*) FROM invoices WHERE invoice_number = ? AND deleted_at IS NULL";
        $params = [$invoiceNumber];
        
        if ($excludeId) {
            $query .= " AND id != ?";
            $params[] = $excludeId;
        }
        
        $stmt = $this->db->prepare($query);
        $stmt->execute($params);
        
        return $stmt->fetchColumn() > 0;
    }
    
    /**
     * Create new invoice
     */
    public function create($data) {
        $query = "INSERT INTO invoices (invoice_number, customer_id, issue_date, due_date, 
                  subtotal, tax, discount, total, status, notes, terms, created_at, updated_at) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";
        
        $stmt = $this->db->prepare($query);
        $result = $stmt->execute([
            $data['invoice_number'],
            $data['customer_id'],
            $data['issue_date'],
            $data['due_date'],
            $data['subtotal'],
            $data['tax'],
            $data['discount'],
            $data['total'],
            $data['status'],
            $data['notes'],
            $data['terms']
        ]);
        
        return $result ? $this->db->lastInsertId() : false;
    }
    
    /**
     * Update invoice
     */
    public function update($id, $data) {
        $fields = [];
        $params = [];
        
        foreach ($data as $key => $value) {
            $fields[] = "$key = ?";
            $params[] = $value;
        }
        
        $params[] = $id;
        
        $query = "UPDATE invoices SET " . implode(', ', $fields) . " WHERE id = ?";
        
        $stmt = $this->db->prepare($query);
        return $stmt->execute($params);
    }
    
    /**
     * Soft delete invoice
     */
    public function delete($id) {
        $query = "UPDATE invoices SET deleted_at = NOW() WHERE id = ?";
        
        $stmt = $this->db->prepare($query);
        return $stmt->execute([$id]);
    }
    
    /**
     * List invoices with filters and pagination
     */
    public function list($filters = []) {
        $where = ["i.deleted_at IS NULL"];
        $params = [];
        
        // Search filter
        if (!empty($filters['search'])) {
            $where[] = "(i.invoice_number LIKE ? OR c.name LIKE ? OR c.company LIKE ?)";
            $searchTerm = "%{$filters['search']}%";
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
        }
        
        // Status filter
        if (!empty($filters['status'])) {
            $where[] = "i.status = ?";
            $params[] = $filters['status'];
        }
        
        // Customer filter
        if (!empty($filters['customer_id'])) {
            $where[] = "i.customer_id = ?";
            $params[] = $filters['customer_id'];
        }
        
        // Date range filter
        if (!empty($filters['date_from'])) {
            $where[] = "i.issue_date >= ?";
            $params[] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $where[] = "i.issue_date <= ?";
            $params[] = $filters['date_to'];
        }
        
        // Pagination
        $page = max(1, (int)($filters['page'] ?? 1));
        $limit = max(1, min(100, (int)($filters['limit'] ?? 10)));
        $offset = ($page - 1) * $limit;
        
        // Count query
        $countQuery = "SELECT COUNT(*) FROM invoices i 
                      LEFT JOIN customers c ON i.customer_id = c.id 
                      WHERE " . implode(' AND ', $where);
        
        $countStmt = $this->db->prepare($countQuery);
        $countStmt->execute($params);
        $total = $countStmt->fetchColumn();
        
        // Main query
        $query = "SELECT i.*, c.name as customer_name, c.company, c.mobile, c.email 
                  FROM invoices i 
                  LEFT JOIN customers c ON i.customer_id = c.id 
                  WHERE " . implode(' AND ', $where) . " 
                  ORDER BY i.created_at DESC 
                  LIMIT $limit OFFSET $offset";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute($params);
        $invoices = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $totalPages = ceil($total / $limit);
        
        return [
            'invoices' => $invoices,
            'pagination' => [
                'total' => $total,
                'page' => $page,
                'limit' => $limit,
                'total_pages' => $totalPages
            ]
        ];
    }
    
    /**
     * Get invoice items
     */
    public function getItems($invoiceId) {
        $query = "SELECT * FROM invoice_items WHERE invoice_id = ? ORDER BY id";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute([$invoiceId]);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Add invoice item
     */
    public function addItem($data) {
        $query = "INSERT INTO invoice_items (invoice_id, description, quantity, unit_price, total) 
                  VALUES (?, ?, ?, ?, ?)";
        
        $stmt = $this->db->prepare($query);
        return $stmt->execute([
            $data['invoice_id'],
            $data['description'],
            $data['quantity'],
            $data['unit_price'],
            $data['total']
        ]);
    }
    
    /**
     * Update invoice item
     */
    public function updateItem($id, $data) {
        $fields = [];
        $params = [];
        
        foreach ($data as $key => $value) {
            $fields[] = "$key = ?";
            $params[] = $value;
        }
        
        $params[] = $id;
        
        $query = "UPDATE invoice_items SET " . implode(', ', $fields) . " WHERE id = ?";
        
        $stmt = $this->db->prepare($query);
        return $stmt->execute($params);
    }
    
    /**
     * Delete invoice item
     */
    public function deleteItem($id) {
        $query = "DELETE FROM invoice_items WHERE id = ?";
        
        $stmt = $this->db->prepare($query);
        return $stmt->execute([$id]);
    }
    
    /**
     * Delete all items for an invoice
     */
    public function deleteAllItems($invoiceId) {
        $query = "DELETE FROM invoice_items WHERE invoice_id = ?";
        
        $stmt = $this->db->prepare($query);
        return $stmt->execute([$invoiceId]);
    }
    
    /**
     * Get invoice statistics
     */
    public function getStatistics() {
        $stats = [];
        
        // Total invoices
        $query = "SELECT COUNT(*) FROM invoices WHERE deleted_at IS NULL";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $stats['total_invoices'] = $stmt->fetchColumn();
        
        // Invoices by status
        $query = "SELECT status, COUNT(*) as count FROM invoices WHERE deleted_at IS NULL GROUP BY status";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $stats['by_status'] = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
        
        // Total revenue
        $query = "SELECT SUM(total) FROM invoices WHERE status = 'paid' AND deleted_at IS NULL";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $stats['total_revenue'] = $stmt->fetchColumn() ?? 0;
        
        // Monthly revenue
        $query = "SELECT DATE_FORMAT(issue_date, '%Y-%m') as month, SUM(total) as revenue 
                  FROM invoices WHERE status = 'paid' AND deleted_at IS NULL 
                  AND issue_date >= DATE_SUB(NOW(), INTERVAL 12 MONTH) 
                  GROUP BY month ORDER BY month";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $stats['monthly_revenue'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Overdue invoices
        $query = "SELECT COUNT(*) FROM invoices WHERE due_date < CURDATE() AND status != 'paid' AND deleted_at IS NULL";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $stats['overdue_invoices'] = $stmt->fetchColumn();
        
        return $stats;
    }
    
    /**
     * Update invoice status
     */
    public function updateStatus($id, $status) {
        $query = "UPDATE invoices SET status = ?, updated_at = NOW() WHERE id = ?";
        
        $stmt = $this->db->prepare($query);
        return $stmt->execute([$status, $id]);
    }
    
    /**
     * Get last invoice number
     */
    public function getLastInvoiceNumber() {
        $query = "SELECT invoice_number FROM invoices ORDER BY id DESC LIMIT 1";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $lastInvoice = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$lastInvoice) {
            return 0;
        }
        
        // Extract number from invoice number (INV2024030001 -> 1)
        preg_match('/(\d+)$/', $lastInvoice['invoice_number'], $matches);
        return isset($matches[1]) ? (int)$matches[1] : 0;
    }
}