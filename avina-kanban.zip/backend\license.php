<?php
/**
 * License Management System
 * Handles license generation, validation, and activation
 */

class LicenseManager {
    private $encryption_key = 'CRM_SYSTEM_LICENSE_KEY_2024_SECURE_ENCRYPTION';
    private $validation_url = 'https://license.crm-system.com/validate';
    private $local_license_file = '../config/license.key';
    
    /**
     * Generate license key based on domain and mobile
     */
    public function generateLicenseKey($domain, $mobile) {
        // Clean inputs
        $domain = strtolower(trim($domain));
        $mobile = $this->cleanMobileNumber($mobile);
        
        // Create base string
        $base_string = $domain . '|' . $mobile . '|' . date('Y-m-d');
        
        // Add random salt
        $salt = bin2hex(random_bytes(16));
        $string_with_salt = $base_string . '|' . $salt;
        
        // Create hash
        $hash = hash('sha256', $string_with_salt . $this->encryption_key);
        
        // Combine and encode
        $license_data = $hash . ':' . base64_encode($string_with_salt);
        
        // Format as license key (XXXX-XXXX-XXXX-XXXX-XXXX-XXXX)
        $encoded = base64_encode($license_data);
        $encoded = str_replace(['+', '/', '='], ['-', '_', ''], $encoded);
        
        return $this->formatLicenseKey($encoded);
    }
    
    /**
     * Validate license key format and structure
     */
    public function validateLicenseKey($license_key) {
        // Remove formatting
        $license_key = str_replace(['-', ' '], '', $license_key);
        
        // Check length
        if (strlen($license_key) < 40) {
            return ['valid' => false, 'error' => 'کلید لایسنس کوتاه است'];
        }
        
        // Decode
        $license_data = base64_decode(str_replace(['-', '_'], ['+', '/'], $license_key));
        
        if (!$license_data) {
            return ['valid' => false, 'error' => 'فرمت کلید لایسنس نامعتبر است'];
        }
        
        // Split hash and data
        $parts = explode(':', $license_data);
        if (count($parts) !== 2) {
            return ['valid' => false, 'error' => 'ساختار کلید لایسنس نامعتبر است'];
        }
        
        list($provided_hash, $encoded_data) = $parts;
        
        // Decode data
        $decoded_data = base64_decode($encoded_data);
        if (!$decoded_data) {
            return ['valid' => false, 'error' => 'داده‌های کلید لایسنس نامعتبر است'];
        }
        
        // Verify hash
        $calculated_hash = hash('sha256', $decoded_data . $this->encryption_key);
        
        if (!hash_equals($provided_hash, $calculated_hash)) {
            return ['valid' => false, 'error' => 'کلید لایسنس معتبر نیست'];
        }
        
        // Parse data
        $data_parts = explode('|', $decoded_data);
        if (count($data_parts) < 3) {
            return ['valid' => false, 'error' => 'داده‌های کلید لایسنس ناقص است'];
        }
        
        return [
            'valid' => true,
            'domain' => $data_parts[0],
            'mobile' => $data_parts[1],
            'generated_date' => $data_parts[2]
        ];
    }
    
    /**
     * Save license key to local file
     */
    public function saveLicenseKey($license_key) {
        try {
            $license_data = [
                'key' => $license_key,
                'activated_at' => date('Y-m-d H:i:s'),
                'server_info' => $this->getServerInfo()
            ];
            
            $encrypted_data = $this->encryptData(json_encode($license_data));
            
            // Ensure config directory exists
            $config_dir = dirname($this->local_license_file);
            if (!is_dir($config_dir)) {
                mkdir($config_dir, 0755, true);
            }
            
            // Save license file
            file_put_contents($this->local_license_file, $encrypted_data);
            
            return ['success' => true, 'message' => 'لایسنس با موفقیت ذخیره شد'];
        } catch (Exception $e) {
            return ['success' => false, 'error' => 'خطا در ذخیره لایسنس: ' . $e->getMessage()];
        }
    }
    
    /**
     * Load and validate local license
     */
    public function loadLocalLicense() {
        if (!file_exists($this->local_license_file)) {
            return ['valid' => false, 'error' => 'فایل لایسنس یافت نشد'];
        }
        
        try {
            $encrypted_data = file_get_contents($this->local_license_file);
            $license_data = json_decode($this->decryptData($encrypted_data), true);
            
            if (!$license_data || !isset($license_data['key'])) {
                return ['valid' => false, 'error' => 'داده‌های لایسنس نامعتبر است'];
            }
            
            // Validate license key
            $validation = $this->validateLicenseKey($license_data['key']);
            
            if (!$validation['valid']) {
                return $validation;
            }
            
            // Check domain match
            $current_domain = $this->getCurrentDomain();
            if ($validation['domain'] !== $current_domain) {
                return ['valid' => false, 'error' => 'لایسنس برای دامنه دیگری صادر شده است'];
            }
            
            return [
                'valid' => true,
                'license' => $license_data,
                'validation' => $validation
            ];
        } catch (Exception $e) {
            return ['valid' => false, 'error' => 'خطا در بارگذاری لایسنس: ' . $e->getMessage()];
        }
    }
    
    /**
     * Check if system is licensed
     */
    public function isSystemLicensed() {
        $license = $this->loadLocalLicense();
        return $license['valid'] ?? false;
    }
    
    /**
     * Get license information
     */
    public function getLicenseInfo() {
        $license = $this->loadLocalLicense();
        
        if (!$license['valid']) {
            return ['licensed' => false, 'error' => $license['error']];
        }
        
        return [
            'licensed' => true,
            'key' => $license['license']['key'],
            'activated_at' => $license['license']['activated_at'],
            'domain' => $license['validation']['domain'],
            'mobile' => $license['validation']['mobile'],
            'generated_date' => $license['validation']['generated_date']
        ];
    }
    
    /**
     * Generate offline activation code
     */
    public function generateOfflineActivationCode($mobile) {
        $domain = $this->getCurrentDomain();
        $timestamp = time();
        $random = bin2hex(random_bytes(8));
        
        $code_data = $domain . '|' . $this->cleanMobileNumber($mobile) . '|' . $timestamp . '|' . $random;
        $hash = hash('sha256', $code_data . $this->encryption_key);
        
        $activation_code = substr($hash, 0, 8) . '-' . substr($hash, 8, 8) . '-' . substr($hash, 16, 8) . '-' . substr($hash, 24, 8);
        
        // Save activation request
        $this->saveActivationRequest($activation_code, $code_data);
        
        return $activation_code;
    }
    
    /**
     * Validate offline activation code
     */
    public function validateOfflineActivationCode($activation_code, $license_key) {
        $request = $this->getActivationRequest($activation_code);
        
        if (!$request) {
            return ['valid' => false, 'error' => 'کد فعال‌سازی یافت نشد'];
        }
        
        // Check if code is expired (24 hours)
        if (time() - $request['timestamp'] > 86400) {
            return ['valid' => false, 'error' => 'کد فعال‌سازی منقضی شده است'];
        }
        
        // Validate license key
        $validation = $this->validateLicenseKey($license_key);
        
        if (!$validation['valid']) {
            return $validation;
        }
        
        // Check domain match
        $current_domain = $this->getCurrentDomain();
        if ($validation['domain'] !== $current_domain) {
            return ['valid' => false, 'error' => 'لایسنس برای دامنه دیگری صادر شده است'];
        }
        
        // Save license
        $save_result = $this->saveLicenseKey($license_key);
        
        if (!$save_result['success']) {
            return $save_result;
        }
        
        // Remove activation request
        $this->removeActivationRequest($activation_code);
        
        return ['valid' => true, 'message' => 'فعال‌سازی با موفقیت انجام شد'];
    }
    
    /**
     * Clean mobile number
     */
    private function cleanMobileNumber($mobile) {
        // Remove all non-digit characters
        $mobile = preg_replace('/[^0-9]/', '', $mobile);
        
        // Convert Persian/Arabic digits to English
        $persian_digits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        $arabic_digits = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
        $english_digits = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
        
        $mobile = str_replace($persian_digits, $english_digits, $mobile);
        $mobile = str_replace($arabic_digits, $english_digits, $mobile);
        
        // Ensure it starts with 0 or 98
        if (substr($mobile, 0, 2) === '98') {
            $mobile = '0' . substr($mobile, 2);
        } elseif (substr($mobile, 0, 1) !== '0') {
            $mobile = '0' . $mobile;
        }
        
        return $mobile;
    }
    
    /**
     * Format license key
     */
    private function formatLicenseKey($key) {
        $key = str_replace(['-', ' '], '', $key);
        $chunks = str_split($key, 4);
        return implode('-', $chunks);
    }
    
    /**
     * Get current domain
     */
    private function getCurrentDomain() {
        if (isset($_SERVER['HTTP_HOST'])) {
            return strtolower($_SERVER['HTTP_HOST']);
        }
        
        // Fallback for CLI
        return gethostname() ?: 'localhost';
    }
    
    /**
     * Get server information
     */
    private function getServerInfo() {
        return [
            'php_version' => PHP_VERSION,
            'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
            'server_name' => $_SERVER['SERVER_NAME'] ?? 'Unknown',
            'document_root' => $_SERVER['DOCUMENT_ROOT'] ?? 'Unknown',
            'ip_address' => $_SERVER['SERVER_ADDR'] ?? 'Unknown'
        ];
    }
    
    /**
     * Encrypt data
     */
    private function encryptData($data) {
        $key = hash('sha256', $this->encryption_key, true);
        $iv = openssl_random_pseudo_bytes(16);
        $encrypted = openssl_encrypt($data, 'AES-256-CBC', $key, 0, $iv);
        return base64_encode($iv . $encrypted);
    }
    
    /**
     * Decrypt data
     */
    private function decryptData($encrypted_data) {
        $data = base64_decode($encrypted_data);
        $iv = substr($data, 0, 16);
        $encrypted = substr($data, 16);
        $key = hash('sha256', $this->encryption_key, true);
        return openssl_decrypt($encrypted, 'AES-256-CBC', $key, 0, $iv);
    }
    
    /**
     * Save activation request
     */
    private function saveActivationRequest($code, $data) {
        $requests_file = '../config/activation_requests.json';
        $requests = [];
        
        if (file_exists($requests_file)) {
            $requests = json_decode(file_get_contents($requests_file), true) ?? [];
        }
        
        $requests[$code] = [
            'data' => $data,
            'timestamp' => time(),
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        file_put_contents($requests_file, json_encode($requests, JSON_PRETTY_PRINT));
    }
    
    /**
     * Get activation request
     */
    private function getActivationRequest($code) {
        $requests_file = '../config/activation_requests.json';
        
        if (!file_exists($requests_file)) {
            return null;
        }
        
        $requests = json_decode(file_get_contents($requests_file), true) ?? [];
        return $requests[$code] ?? null;
    }
    
    /**
     * Remove activation request
     */
    private function removeActivationRequest($code) {
        $requests_file = '../config/activation_requests.json';
        
        if (!file_exists($requests_file)) {
            return;
        }
        
        $requests = json_decode(file_get_contents($requests_file), true) ?? [];
        unset($requests[$code]);
        
        file_put_contents($requests_file, json_encode($requests, JSON_PRETTY_PRINT));
    }
}

// API Handler for license operations
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    
    $license_manager = new LicenseManager();
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'generate':
            $domain = $_POST['domain'] ?? '';
            $mobile = $_POST['mobile'] ?? '';
            
            if (empty($domain) || empty($mobile)) {
                echo json_encode(['success' => false, 'error' => 'دامنه و موبایل الزامی هستند']);
                break;
            }
            
            $license_key = $license_manager->generateLicenseKey($domain, $mobile);
            echo json_encode([
                'success' => true,
                'license_key' => $license_key,
                'message' => 'کلید لایسنس با موفقیت ایجاد شد'
            ]);
            break;
            
        case 'validate':
            $license_key = $_POST['license_key'] ?? '';
            
            if (empty($license_key)) {
                echo json_encode(['success' => false, 'error' => 'کلید لایسنس الزامی است']);
                break;
            }
            
            $result = $license_manager->validateLicenseKey($license_key);
            echo json_encode($result);
            break;
            
        case 'activate':
            $activation_code = $_POST['activation_code'] ?? '';
            $license_key = $_POST['license_key'] ?? '';
            
            if (empty($activation_code) || empty($license_key)) {
                echo json_encode(['success' => false, 'error' => 'کد فعال‌سازی و کلید لایسنس الزامی هستند']);
                break;
            }
            
            $result = $license_manager->validateOfflineActivationCode($activation_code, $license_key);
            echo json_encode($result);
            break;
            
        case 'status':
            $is_licensed = $license_manager->isSystemLicensed();
            $license_info = $license_manager->getLicenseInfo();
            
            echo json_encode([
                'licensed' => $is_licensed,
                'license_info' => $license_info
            ]);
            break;
            
        default:
            echo json_encode(['success' => false, 'error' => 'عملیات نامعتبر']);
    }
}