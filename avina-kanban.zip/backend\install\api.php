<?php
/**
 * Installation API for Avina Kanban
 * Handles installation requests from frontend
 */

require_once '../config/database.php';
require_once '../helpers/response.php';
require_once '../helpers/security.php';
require_once 'install.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

class InstallAPI {
    
    private $installer;
    
    public function __construct() {
        $this->installer = new Installer();
    }
    
    public function handleRequest() {
        try {
            $input = json_decode(file_get_contents('php://input'), true);
            
            if (!$input) {
                Response::error('داده‌های ورودی معتبر نیستند');
                return;
            }
            
            $action = $input['action'] ?? '';
            
            switch ($action) {
                case 'check_status':
                    $this->checkStatus();
                    break;
                    
                case 'test_db':
                    $this->testDatabaseConnection($input);
                    break;
                    
                case 'install':
                    $this->installSystem($input);
                    break;
                    
                default:
                    Response::error('عملیات نامعتبر');
            }
            
        } catch (Exception $e) {
            Response::error('خطای سرور: ' . $e->getMessage());
        }
    }
    
    private function checkStatus() {
        $configPath = __DIR__ . '/../config/config.json';
        
        if (file_exists($configPath)) {
            Response::success('سیستم قبلاً نصب شده است', ['installed' => true]);
        } else {
            Response::success('سیستم نصب نشده است', ['installed' => false]);
        }
    }
    
    private function testDatabaseConnection($data) {
        try {
            $required = ['host', 'name', 'user'];
            foreach ($required as $field) {
                if (empty($data[$field])) {
                    throw new Exception("فیلد {$field} برای تست اتصال الزامی است");
                }
            }
            
            $dsn = "mysql:host={$data['host']};charset=utf8mb4";
            $pdo = new PDO($dsn, $data['user'], $data['password'] ?? '', [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
            
            // Test basic query
            $pdo->query("SELECT 1");
            
            // Try to create database if not exists
            $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$data['name']}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            
            Response::success('اتصال به دیتابیس با موفقیت برقرار شد');
            
        } catch (PDOException $e) {
            Response::error('اتصال به دیتابیس ناموفق بود: ' . $e->getMessage());
        }
    }
    
    private function installSystem($data) {
        try {
            // Validate license key if provided
            $validatedLicense = null;
            if (!empty($data['license']['licenseKey'])) {
                $validatedLicense = $this->validateLicense($data['license']['licenseKey']);
            }
            
            // Install using the installer class
            $this->installer->install([
                'dbHost' => $data['dbHost'],
                'dbName' => $data['dbName'],
                'dbUser' => $data['dbUser'],
                'dbPass' => $data['dbPass'] ?? '',
                'admin' => [
                    'name' => $data['admin']['name'],
                    'email' => $data['admin']['email'],
                    'password' => $data['admin']['password']
                ],
                'company' => $data['company'] ?? [],
                'license' => $data['license'] ?? []
            ]);
            
            // Save installation info
            $this->saveInstallationInfo($data);

            Response::success('نصب با موفقیت انجام شد', [
                'redirect' => '../index.html',
                'message' => 'سیستم با موفقیت نصب شد. در حال انتقال...'
            ]);

            // Mark license as used only after successful installation
            if ($validatedLicense && isset($validatedLicense['code'])) {
                $this->markLicenseUsed($validatedLicense['code']);
            }

        } catch (Exception $e) {
            Response::error('خطا در نصب سیستم: ' . $e->getMessage());
        }
    }
    
    private function validateLicense($licenseKey) {
        // Normalize: strip non-digits to allow hyphenated keys
        $normalized = preg_replace('/\D/', '', (string)$licenseKey);
        if (!preg_match('/^\d{16}$/', $normalized)) {
            throw new Exception('کلید لایسنس ۱۶ رقمی نامعتبر است');
        }

        $licenseFile = __DIR__ . '/licenses.json';
        if (!file_exists($licenseFile)) {
            throw new Exception('فایل لایسنس‌ها یافت نشد');
        }

        $licenses = json_decode(file_get_contents($licenseFile), true);
        if (!is_array($licenses)) {
            throw new Exception('ساختار فایل لایسنس‌ها نامعتبر است');
        }

        foreach ($licenses as $lic) {
            if (($lic['code'] ?? null) === $normalized) {
                if (($lic['status'] ?? 'new') === 'used') {
                    throw new Exception('این لایسنس قبلاً مصرف شده است');
                }
                return $lic; // valid and not used
            }
        }

        throw new Exception('کلید لایسنس معتبر نیست');
    }

    private function markLicenseUsed($licenseKey) {
        $licenseFile = __DIR__ . '/licenses.json';
        if (!file_exists($licenseFile)) return;
        $licenses = json_decode(file_get_contents($licenseFile), true);
        if (!is_array($licenses)) return;

        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        $changed = false;
        $normalized = preg_replace('/\D/', '', (string)$licenseKey);
        foreach ($licenses as &$lic) {
            if (($lic['code'] ?? null) === $normalized) {
                $lic['status'] = 'used';
                $lic['used_at'] = date('Y-m-d H:i:s');
                $lic['domain'] = strtolower($host);
                $changed = true;
                break;
            }
        }
        if ($changed) {
            file_put_contents($licenseFile, json_encode($licenses, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        }
    }
    
    private function saveInstallationInfo($data) {
        $info = [
            'installed_at' => date('Y-m-d H:i:s'),
            'company_name' => $data['company']['name'] ?? '',
            'company_phone' => $data['company']['phone'] ?? '',
            'admin_email' => $data['admin']['email'],
            'license_key' => $data['license']['licenseKey'] ?? ''
        ];
        
        $infoFile = __DIR__ . '/installation_info.json';
        file_put_contents($infoFile, json_encode($info, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }
}

// Initialize and handle request
$api = new InstallAPI();
$api->handleRequest();