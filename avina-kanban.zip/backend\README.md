# CRM System Backend API

## Overview
This is the backend API for the CRM System, providing RESTful endpoints for managing customers, invoices, tasks, and system settings.

## Requirements
- PHP 7.4 or higher
- MySQL 5.7 or higher
- Apache/Nginx web server
- Composer

## Installation

1. **Clone the repository**
   ```bash
   git clone [repository-url]
   cd backend
   ```

2. **Install dependencies**
   ```bash
   composer install
   ```

3. **Configure database**
   - Create a MySQL database
   - Copy `config/config.example.php` to `config/config.php`
   - Update database credentials in `config/config.php`

4. **Run installation**
   - Navigate to `/install/` in your browser
   - Follow the installation wizard

5. **Configure web server**
   - Point your web server to the `backend` directory
   - Ensure `.htaccess` is enabled (for Apache)

## API Documentation

### Authentication
All API endpoints require authentication except for login and register.

**Login**
```http
POST /api/auth/login
Content-Type: application/json

{
    "email": "user@example.com",
    "password": "password"
}
```

**Register**
```http
POST /api/auth/register
Content-Type: application/json

{
    "name": "John Doe",
    "email": "user@example.com",
    "password": "password",
    "role": "user"
}
```

### API Endpoints

#### Users
- `GET /api/users` - List all users
- `GET /api/users/{id}` - Get user by ID
- `POST /api/users` - Create new user
- `PUT /api/users/{id}` - Update user
- `DELETE /api/users/{id}` - Delete user

#### Customers
- `GET /api/customers` - List all customers
- `GET /api/customers/{id}` - Get customer by ID
- `POST /api/customers` - Create new customer
- `PUT /api/customers/{id}` - Update customer
- `DELETE /api/customers/{id}` - Delete customer

#### Invoices
- `GET /api/invoices` - List all invoices
- `GET /api/invoices/{id}` - Get invoice by ID
- `POST /api/invoices` - Create new invoice
- `PUT /api/invoices/{id}` - Update invoice
- `DELETE /api/invoices/{id}` - Delete invoice

#### Tasks
- `GET /api/tasks` - List all tasks
- `GET /api/tasks/{id}` - Get task by ID
- `POST /api/tasks` - Create new task
- `PUT /api/tasks/{id}` - Update task
- `DELETE /api/tasks/{id}` - Delete task

#### Settings
- `GET /api/settings` - Get all settings
- `PUT /api/settings` - Update settings
- `GET /api/settings/{key}` - Get specific setting
- `POST /api/settings/import` - Import settings
- `GET /api/settings/export` - Export settings

#### Backup
- `GET /api/backup` - List backups
- `POST /api/backup/create` - Create backup
- `GET /api/backup/{id}/download` - Download backup
- `POST /api/backup/{id}/restore` - Restore backup
- `DELETE /api/backup/{id}` - Delete backup

## Response Format
All API responses follow this format:
```json
{
    "success": true,
    "message": "Operation successful",
    "data": {},
    "error": null
}
```

## Error Codes
- `400` - Bad Request
- `401` - Unauthorized
- `403` - Forbidden
- `404` - Not Found
- `500` - Internal Server Error

## Security
- JWT token-based authentication
- Input validation and sanitization
- SQL injection protection
- XSS protection
- Rate limiting
- CORS configuration

## Development

### Running Tests
```bash
composer test
```

### Development Server
```bash
composer serve
```

## License
This project is licensed under the MIT License.