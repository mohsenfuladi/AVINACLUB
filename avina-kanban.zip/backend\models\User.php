<?php
/**
 * User Model
 * Handles all user-related database operations
 */

require_once '../config/database.php';

class User {
    
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * Create a new user
     */
    public function create($data) {
        return $this->db->insert('users', $data);
    }
    
    /**
     * Find user by ID
     */
    public function findById($id) {
        $sql = "SELECT * FROM users WHERE id = :id AND deleted_at IS NULL";
        return $this->db->fetch($sql, ['id' => $id]);
    }
    
    /**
     * Find user by email
     */
    public function findByEmail($email) {
        $sql = "SELECT * FROM users WHERE email = :email AND deleted_at IS NULL";
        return $this->db->fetch($sql, ['email' => $email]);
    }

    /**
     * Find user by mobile
     */
    public function findByMobile($mobile) {
        $sql = "SELECT * FROM users WHERE mobile = :mobile AND deleted_at IS NULL";
        return $this->db->fetch($sql, ['mobile' => $mobile]);
    }
    
    /**
     * Find user by username
     */
    public function findByUsername($username) {
        $sql = "SELECT * FROM users WHERE username = :username AND deleted_at IS NULL";
        return $this->db->fetch($sql, ['username' => $username]);
    }
    
    /**
     * Find user by username or email
     */
    public function findByUsernameOrEmail($usernameOrEmail) {
        $sql = "SELECT * FROM users WHERE (username = :username OR email = :email) AND deleted_at IS NULL";
        return $this->db->fetch($sql, ['username' => $usernameOrEmail, 'email' => $usernameOrEmail]);
    }
    
    /**
     * Find user by reset token
     */
    public function findByResetToken($token) {
        $sql = "SELECT * FROM users WHERE reset_token = :token AND deleted_at IS NULL";
        return $this->db->fetch($sql, ['token' => $token]);
    }
    
    /**
     * Get all users with pagination
     */
    public function getAll($page = 1, $perPage = 10, $search = '', $role = '') {
        $offset = ($page - 1) * $perPage;
        $params = [];
        
        $where = "WHERE deleted_at IS NULL";
        
        if ($search) {
            $where .= " AND (name LIKE :search OR email LIKE :search OR username LIKE :search)";
            $params['search'] = "%{$search}%";
        }
        
        if ($role) {
            $where .= " AND role = :role";
            $params['role'] = $role;
        }
        
        // Get total count
        $countSql = "SELECT COUNT(*) as total FROM users {$where}";
        $total = $this->db->fetch($countSql, $params)['total'];
        
        // Get users
        $sql = "SELECT * FROM users {$where} ORDER BY created_at DESC LIMIT :limit OFFSET :offset";
        $params['limit'] = $perPage;
        $params['offset'] = $offset;
        
        $users = $this->db->fetchAll($sql, $params);
        
        return [
            'users' => $users,
            'total' => $total,
            'page' => $page,
            'per_page' => $perPage,
            'total_pages' => ceil($total / $perPage)
        ];
    }
    
    /**
     * Update user
     */
    public function update($id, $data) {
        $data['updated_at'] = date('Y-m-d H:i:s');
        return $this->db->update('users', $data, 'id = :id', ['id' => $id]);
    }
    
    /**
     * Update user password
     */
    public function updatePassword($id, $hashedPassword) {
        return $this->db->update('users', [
            'password' => $hashedPassword,
            'updated_at' => date('Y-m-d H:i:s')
        ], 'id = :id', ['id' => $id]);
    }
    
    /**
     * Update last login
     */
    public function updateLastLogin($id) {
        return $this->db->update('users', [
            'last_login' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ], 'id = :id', ['id' => $id]);
    }
    
    /**
     * Save reset token
     */
    public function saveResetToken($id, $token, $expiry) {
        return $this->db->update('users', [
            'reset_token' => $token,
            'reset_token_expiry' => $expiry,
            'updated_at' => date('Y-m-d H:i:s')
        ], 'id = :id', ['id' => $id]);
    }
    
    /**
     * Clear reset token
     */
    public function clearResetToken($id) {
        return $this->db->update('users', [
            'reset_token' => null,
            'reset_token_expiry' => null,
            'updated_at' => date('Y-m-d H:i:s')
        ], 'id = :id', ['id' => $id]);
    }
    
    /**
     * Soft delete user
     */
    public function delete($id) {
        return $this->db->update('users', [
            'deleted_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ], 'id = :id', ['id' => $id]);
    }
    
    /**
     * Check if email exists (excluding specific user)
     */
    public function emailExists($email, $excludeId = null) {
        $sql = "SELECT COUNT(*) as count FROM users WHERE email = :email AND deleted_at IS NULL";
        $params = ['email' => $email];
        
        if ($excludeId) {
            $sql .= " AND id != :exclude_id";
            $params['exclude_id'] = $excludeId;
        }
        
        $result = $this->db->fetch($sql, $params);
        return $result['count'] > 0;
    }
    
    /**
     * Check if username exists (excluding specific user)
     */
    public function usernameExists($username, $excludeId = null) {
        $sql = "SELECT COUNT(*) as count FROM users WHERE username = :username AND deleted_at IS NULL";
        $params = ['username' => $username];
        
        if ($excludeId) {
            $sql .= " AND id != :exclude_id";
            $params['exclude_id'] = $excludeId;
        }
        
        $result = $this->db->fetch($sql, $params);
        return $result['count'] > 0;
    }
    
    /**
     * Get user statistics
     */
    public function getStats() {
        $sql = "SELECT 
                    COUNT(*) as total_users,
                    COUNT(CASE WHEN status = 'active' THEN 1 END) as active_users,
                    COUNT(CASE WHEN role = 'admin' THEN 1 END) as admin_users,
                    COUNT(CASE WHEN DATE(created_at) = CURDATE() THEN 1 END) as today_users
                FROM users 
                WHERE deleted_at IS NULL";
        
        return $this->db->fetch($sql);
    }
    
    /**
     * Get recent users
     */
    public function getRecent($limit = 5) {
        $sql = "SELECT * FROM users WHERE deleted_at IS NULL ORDER BY created_at DESC LIMIT :limit";
        return $this->db->fetchAll($sql, ['limit' => $limit]);
    }
}