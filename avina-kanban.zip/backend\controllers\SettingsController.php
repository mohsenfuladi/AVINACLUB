<?php
/**
 * Settings Controller
 * Handles system settings and configuration management
 */

require_once '../helpers/response.php';
require_once '../helpers/security.php';
require_once '../models/Settings.php';

class SettingsController {
    
    private $db;
    private $settingsModel;
    
    public function __construct($database) {
        $this->db = $database;
        $this->settingsModel = new Settings($database);
    }
    
    public function get() {
        $settings = $this->settingsModel->getAll();
        
        Response::success([
            'settings' => $settings
        ]);
    }
    
    public function update() {
        $data = Request::getJsonInput();
        
        // Validate settings data
        $validatedSettings = [];
        
        // Company settings
        if (isset($data['company_name'])) {
            $validatedSettings['company_name'] = Security::sanitize($data['company_name']);
        }
        
        if (isset($data['company_address'])) {
            $validatedSettings['company_address'] = Security::sanitize($data['company_address']);
        }
        
        if (isset($data['company_phone'])) {
            $validatedSettings['company_phone'] = Security::sanitize($data['company_phone']);
        }
        
        if (isset($data['company_email'])) {
            $email = Security::sanitize($data['company_email']);
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                Response::validationError('ایمیل شرکت نامعتبر است');
            }
            $validatedSettings['company_email'] = $email;
        }
        
        if (isset($data['company_website'])) {
            $validatedSettings['company_website'] = Security::sanitize($data['company_website']);
        }
        
        if (isset($data['company_logo'])) {
            $validatedSettings['company_logo'] = Security::sanitize($data['company_logo']);
        }
        
        // Invoice settings
        if (isset($data['invoice_prefix'])) {
            $validatedSettings['invoice_prefix'] = Security::sanitize($data['invoice_prefix']);
        }
        
        if (isset($data['invoice_terms'])) {
            $validatedSettings['invoice_terms'] = Security::sanitize($data['invoice_terms']);
        }
        
        if (isset($data['invoice_notes'])) {
            $validatedSettings['invoice_notes'] = Security::sanitize($data['invoice_notes']);
        }
        
        if (isset($data['tax_rate'])) {
            $taxRate = (float)$data['tax_rate'];
            if ($taxRate < 0 || $taxRate > 100) {
                Response::validationError('نرخ مالیات باید بین 0 تا 100 باشد');
            }
            $validatedSettings['tax_rate'] = $taxRate;
        }
        
        // System settings
        if (isset($data['timezone'])) {
            $validatedSettings['timezone'] = Security::sanitize($data['timezone']);
        }
        
        if (isset($data['date_format'])) {
            $validatedSettings['date_format'] = Security::sanitize($data['date_format']);
        }
        
        if (isset($data['currency'])) {
            $validatedSettings['currency'] = Security::sanitize($data['currency']);
        }
        
        if (isset($data['language'])) {
            $validatedSettings['language'] = Security::sanitize($data['language']);
        }
        
        // Email settings
        if (isset($data['smtp_host'])) {
            $validatedSettings['smtp_host'] = Security::sanitize($data['smtp_host']);
        }
        
        if (isset($data['smtp_port'])) {
            $port = (int)$data['smtp_port'];
            if ($port <= 0 || $port > 65535) {
                Response::validationError('پورت SMTP نامعتبر است');
            }
            $validatedSettings['smtp_port'] = $port;
        }
        
        if (isset($data['smtp_username'])) {
            $validatedSettings['smtp_username'] = Security::sanitize($data['smtp_username']);
        }
        
        if (isset($data['smtp_password'])) {
            $validatedSettings['smtp_password'] = Security::sanitize($data['smtp_password']);
        }
        
        if (isset($data['smtp_encryption'])) {
            $encryption = Security::sanitize($data['smtp_encryption']);
            if (!in_array($encryption, ['none', 'ssl', 'tls'])) {
                Response::validationError('نوع رمزنگاری SMTP نامعتبر است');
            }
            $validatedSettings['smtp_encryption'] = $encryption;
        }
        
        // Theme settings
        if (isset($data['theme_mode'])) {
            $themeMode = Security::sanitize($data['theme_mode']);
            if (!in_array($themeMode, ['light', 'dark', 'auto'])) {
                Response::validationError('حالت تم نامعتبر است');
            }
            $validatedSettings['theme_mode'] = $themeMode;
        }
        
        if (isset($data['primary_color'])) {
            $color = Security::sanitize($data['primary_color']);
            if (!preg_match('/^#[0-9A-F]{6}$/i', $color)) {
                Response::validationError('فرمت رنگ اصلی نامعتبر است');
            }
            $validatedSettings['primary_color'] = $color;
        }
        
        if (isset($data['sidebar_collapsed'])) {
            $validatedSettings['sidebar_collapsed'] = (int)$data['sidebar_collapsed'];
        }
        
        // Security settings
        if (isset($data['session_timeout'])) {
            $timeout = (int)$data['session_timeout'];
            if ($timeout < 5 || $timeout > 1440) {
                Response::validationError('زمان پایان جلسه باید بین 5 دقیقه تا 24 ساعت باشد');
            }
            $validatedSettings['session_timeout'] = $timeout;
        }
        
        if (isset($data['max_login_attempts'])) {
            $attempts = (int)$data['max_login_attempts'];
            if ($attempts < 3 || $attempts > 10) {
                Response::validationError('حداکثر تلاش‌های ورود باید بین 3 تا 10 باشد');
            }
            $validatedSettings['max_login_attempts'] = $attempts;
        }
        
        if (isset($data['lockout_duration'])) {
            $duration = (int)$data['lockout_duration'];
            if ($duration < 5 || $duration > 60) {
                Response::validationError('مدت زمان قفل شدن باید بین 5 تا 60 دقیقه باشد');
            }
            $validatedSettings['lockout_duration'] = $duration;
        }
        
        if (empty($validatedSettings)) {
            Response::error('داده‌ای برای به‌روزرسانی وجود ندارد', 400);
        }
        
        // Update settings
        $success = true;
        foreach ($validatedSettings as $key => $value) {
            if (!$this->settingsModel->set($key, $value)) {
                $success = false;
                break;
            }
        }
        
        if (!$success) {
            Response::error('خطا در به‌روزرسانی تنظیمات', 500);
        }
        
        // Get updated settings
        $updatedSettings = $this->settingsModel->getAll();
        
        Response::success([
            'settings' => $updatedSettings
        ], 'تنظیمات با موفقیت به‌روزرسانی شد');
    }
    
    public function getByKey($key) {
        $value = $this->settingsModel->get($key);
        
        if ($value === null) {
            Response::error('تنظیم مورد نظر یافت نشد', 404);
        }
        
        Response::success([
            'key' => $key,
            'value' => $value
        ]);
    }
    
    public function setByKey($key) {
        $data = Request::getJsonInput();
        
        if (!isset($data['value'])) {
            Response::error('مقدار تنظیم الزامی است', 400);
        }
        
        $value = Security::sanitize($data['value']);
        
        // Validate specific settings based on key
        switch ($key) {
            case 'company_email':
                if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
                    Response::validationError('ایمیل شرکت نامعتبر است');
                }
                break;
                
            case 'tax_rate':
                $value = (float)$value;
                if ($value < 0 || $value > 100) {
                    Response::validationError('نرخ مالیات باید بین 0 تا 100 باشد');
                }
                break;
                
            case 'smtp_port':
                $value = (int)$value;
                if ($value <= 0 || $value > 65535) {
                    Response::validationError('پورت SMTP نامعتبر است');
                }
                break;
                
            case 'smtp_encryption':
                if (!in_array($value, ['none', 'ssl', 'tls'])) {
                    Response::validationError('نوع رمزنگاری SMTP نامعتبر است');
                }
                break;
                
            case 'theme_mode':
                if (!in_array($value, ['light', 'dark', 'auto'])) {
                    Response::validationError('حالت تم نامعتبر است');
                }
                break;
                
            case 'primary_color':
                if (!preg_match('/^#[0-9A-F]{6}$/i', $value)) {
                    Response::validationError('فرمت رنگ اصلی نامعتبر است');
                }
                break;
                
            case 'session_timeout':
                $value = (int)$value;
                if ($value < 5 || $value > 1440) {
                    Response::validationError('زمان پایان جلسه باید بین 5 دقیقه تا 24 ساعت باشد');
                }
                break;
                
            case 'max_login_attempts':
                $value = (int)$value;
                if ($value < 3 || $value > 10) {
                    Response::validationError('حداکثر تلاش‌های ورود باید بین 3 تا 10 باشد');
                }
                break;
                
            case 'lockout_duration':
                $value = (int)$value;
                if ($value < 5 || $value > 60) {
                    Response::validationError('مدت زمان قفل شدن باید بین 5 تا 60 دقیقه باشد');
                }
                break;
        }
        
        $success = $this->settingsModel->set($key, $value);
        
        if (!$success) {
            Response::error('خطا در به‌روزرسانی تنظیم', 500);
        }
        
        Response::success([
            'key' => $key,
            'value' => $value
        ], 'تنظیم با موفقیت به‌روزرسانی شد');
    }
    
    public function resetToDefaults() {
        $success = $this->settingsModel->resetToDefaults();
        
        if (!$success) {
            Response::error('خطا در بازنشانی تنظیمات', 500);
        }
        
        // Get reset settings
        $settings = $this->settingsModel->getAll();
        
        Response::success([
            'settings' => $settings
        ], 'تنظیمات با موفقیت به حالت پیش‌فرض بازنشانی شد');
    }
    
    public function export() {
        $settings = $this->settingsModel->getAll();
        
        // Create export data
        $exportData = [
            'export_date' => date('Y-m-d H:i:s'),
            'version' => '1.0.0',
            'settings' => $settings
        ];
        
        $filename = 'settings_export_' . date('Y-m-d_H-i-s') . '.json';
        
        Response::success([
            'filename' => $filename,
            'data' => $exportData
        ]);
    }
    
    public function import() {
        // Check if file was uploaded
        if (!isset($_FILES['settings_file'])) {
            Response::error('فایل تنظیمات ارسال نشده است', 400);
        }
        
        $file = $_FILES['settings_file'];
        
        // Validate file
        if ($file['error'] !== UPLOAD_ERR_OK) {
            Response::error('خطا در آپلود فایل', 400);
        }
        
        if ($file['type'] !== 'application/json') {
            Response::error('فرمت فایل باید JSON باشد', 400);
        }
        
        // Read and parse file
        $content = file_get_contents($file['tmp_name']);
        $importData = json_decode($content, true);
        
        if (!$importData || !isset($importData['settings'])) {
            Response::error('فایل تنظیمات نامعتبر است', 400);
        }
        
        // Import settings
        $success = true;
        foreach ($importData['settings'] as $key => $value) {
            if (!$this->settingsModel->set($key, $value)) {
                $success = false;
                break;
            }
        }
        
        if (!$success) {
            Response::error('خطا در وارد کردن تنظیمات', 500);
        }
        
        // Get imported settings
        $settings = $this->settingsModel->getAll();
        
        Response::success([
            'settings' => $settings
        ], 'تنظیمات با موفقیت وارد شد');
    }
}