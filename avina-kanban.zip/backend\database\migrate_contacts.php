<?php
/**
 * Safe migration script to update contacts table to phonebook schema
 * Checks existing columns and applies ALTERs only when needed
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../helpers/response.php';

function columnExists($db, $table, $column) {
    $sql = "SELECT COUNT(*) AS cnt FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?";
    $row = $db->fetch($sql, [$table, $column]);
    return isset($row['cnt']) && intval($row['cnt']) > 0;
}

function runSafeMigration() {
    $db = getDatabase();

    try {
        $db->beginTransaction();

        $table = 'contacts';

        // Add category
        if (!columnExists($db, $table, 'category')) {
            $db->execute("ALTER TABLE contacts ADD COLUMN category VARCHAR(50) DEFAULT NULL AFTER phone");
        }

        // Add notes
        if (!columnExists($db, $table, 'notes')) {
            $db->execute("ALTER TABLE contacts ADD COLUMN notes TEXT DEFAULT NULL AFTER category");
        }

        // Add customer_id
        if (!columnExists($db, $table, 'customer_id')) {
            $db->execute("ALTER TABLE contacts ADD COLUMN customer_id INT DEFAULT NULL AFTER notes");
            $db->execute("ALTER TABLE contacts ADD CONSTRAINT fk_contacts_customer_id FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL");
        }

        // Add created_by
        if (!columnExists($db, $table, 'created_by')) {
            $db->execute("ALTER TABLE contacts ADD COLUMN created_by INT DEFAULT NULL AFTER replied_by");
            $db->execute("ALTER TABLE contacts ADD CONSTRAINT fk_contacts_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL");
        }

        // Add deleted_at
        if (!columnExists($db, $table, 'deleted_at')) {
            $db->execute("ALTER TABLE contacts ADD COLUMN deleted_at DATETIME DEFAULT NULL AFTER updated_at");
        }

        // Make message nullable if exists
        if (columnExists($db, $table, 'message')) {
            $db->execute("ALTER TABLE contacts MODIFY COLUMN message TEXT NULL");
        }

        // Add helpful indexes for performance (if not exists)
        $indexExists = function($name) use ($db, $table) {
            $sql = "SELECT COUNT(*) AS cnt FROM INFORMATION_SCHEMA.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ?";
            $row = $db->fetch($sql, [$table, $name]);
            return isset($row['cnt']) && intval($row['cnt']) > 0;
        };

        if (!$indexExists('idx_contacts_phone') && columnExists($db, $table, 'phone')) {
            $db->execute("ALTER TABLE contacts ADD INDEX idx_contacts_phone (phone)");
        }
        if (!$indexExists('idx_contacts_name') && columnExists($db, $table, 'name')) {
            $db->execute("ALTER TABLE contacts ADD INDEX idx_contacts_name (name)");
        }
        if (!$indexExists('idx_contacts_category') && columnExists($db, $table, 'category')) {
            $db->execute("ALTER TABLE contacts ADD INDEX idx_contacts_category (category)");
        }
        if (!$indexExists('idx_contacts_created_at') && columnExists($db, $table, 'created_at')) {
            $db->execute("ALTER TABLE contacts ADD INDEX idx_contacts_created_at (created_at)");
        }

        $db->commit();

        Response::success('مهاجرت جدول contacts با موفقیت انجام شد');
    } catch (Exception $e) {
        $db->rollback();
        Response::error('خطا در مهاجرت contacts: ' . $e->getMessage());
    }
}

// Run if invoked directly
if (php_sapi_name() === 'cli' || basename($_SERVER['PHP_SELF']) === 'migrate_contacts.php') {
    runSafeMigration();
}