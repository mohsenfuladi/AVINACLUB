<?php
/**
 * Customer Model
 * Handles all database operations related to customers
 */

class Customer {
    
    private $db;
    
    public function __construct($database) {
        $this->db = $database;
    }
    
    public function findById($id) {
        $sql = "SELECT * FROM customers WHERE id = ? AND deleted_at IS NULL";
        return $this->db->fetch($sql, [$id]);
    }
    
    public function findByMobile($mobile) {
        $sql = "SELECT * FROM customers WHERE mobile = ? AND deleted_at IS NULL";
        return $this->db->fetch($sql, [$mobile]);
    }
    
    public function findByEmail($email) {
        $sql = "SELECT * FROM customers WHERE email = ? AND deleted_at IS NULL";
        return $this->db->fetch($sql, [$email]);
    }
    
    public function mobileExists($mobile, $excludeCustomerId = null) {
        $sql = "SELECT COUNT(*) as count FROM customers WHERE mobile = ? AND deleted_at IS NULL";
        $params = [$mobile];
        
        if ($excludeCustomerId) {
            $sql .= " AND id != ?";
            $params[] = $excludeCustomerId;
        }
        
        $result = $this->db->fetch($sql, $params);
        return $result['count'] > 0;
    }
    
    public function emailExists($email, $excludeCustomerId = null) {
        if (!$email) return false;
        
        $sql = "SELECT COUNT(*) as count FROM customers WHERE email = ? AND deleted_at IS NULL";
        $params = [$email];
        
        if ($excludeCustomerId) {
            $sql .= " AND id != ?";
            $params[] = $excludeCustomerId;
        }
        
        $result = $this->db->fetch($sql, $params);
        return $result['count'] > 0;
    }
    
    public function create($data) {
        $sql = "INSERT INTO customers (
                    first_name, last_name, mobile, phone, email, company, type, status,
                    address, notes, birth_date, national_id, economic_code, registration_number,
                    created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $params = [
            $data['first_name'],
            $data['last_name'],
            $data['mobile'],
            $data['phone'],
            $data['email'],
            $data['company'],
            $data['type'],
            $data['status'],
            $data['address'],
            $data['notes'],
            $data['birth_date'],
            $data['national_id'],
            $data['economic_code'],
            $data['registration_number'],
            $data['created_at']
        ];
        
        return $this->db->insert($sql, $params);
    }
    
    public function update($id, $data) {
        $fields = [];
        $params = [];
        
        foreach ($data as $key => $value) {
            $fields[] = "{$key} = ?";
            $params[] = $value;
        }
        
        $params[] = $id;
        
        $sql = "UPDATE customers SET " . implode(', ', $fields) . " WHERE id = ? AND deleted_at IS NULL";
        
        return $this->db->execute($sql, $params);
    }
    
    public function delete($id) {
        $sql = "UPDATE customers SET deleted_at = ? WHERE id = ? AND deleted_at IS NULL";
        return $this->db->execute($sql, [date('Y-m-d H:i:s'), $id]);
    }
    
    public function list($filters = [], $page = 1, $perPage = 20) {
        $where = "WHERE deleted_at IS NULL";
        $params = [];
        
        if (isset($filters['type'])) {
            $where .= " AND type = ?";
            $params[] = $filters['type'];
        }
        
        if (isset($filters['status'])) {
            $where .= " AND status = ?";
            $params[] = $filters['status'];
        }
        
        if (isset($filters['search'])) {
            $where .= " AND (first_name LIKE ? OR last_name LIKE ? OR mobile LIKE ? OR email LIKE ? OR company LIKE ?)";
            $searchTerm = "%{$filters['search']}%";
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
        }
        
        // Get total count
        $countSql = "SELECT COUNT(*) as total FROM customers {$where}";
        $totalResult = $this->db->fetch($countSql, $params);
        $total = $totalResult['total'];
        
        // Get paginated results
        $offset = ($page - 1) * $perPage;
        $sql = "SELECT * FROM customers {$where} ORDER BY created_at DESC LIMIT {$perPage} OFFSET {$offset}";
        
        $customers = $this->db->fetchAll($sql, $params);
        
        return [
            'data' => $customers,
            'total' => $total,
            'page' => $page,
            'per_page' => $perPage,
            'total_pages' => ceil($total / $perPage)
        ];
    }
    
    public function hasRelatedData($customerId) {
        // Check invoices
        $sql = "SELECT COUNT(*) as count FROM invoices WHERE customer_id = ?";
        $result = $this->db->fetch($sql, [$customerId]);
        if ($result['count'] > 0) return true;
        
        // Check contacts
        $sql = "SELECT COUNT(*) as count FROM contacts WHERE customer_id = ?";
        $result = $this->db->fetch($sql, [$customerId]);
        if ($result['count'] > 0) return true;
        
        return false;
    }
    
    public function getStats() {
        $stats = [];
        
        // Total customers
        $sql = "SELECT COUNT(*) as total FROM customers WHERE deleted_at IS NULL";
        $result = $this->db->fetch($sql);
        $stats['total'] = $result['total'];
        
        // Customers by type
        $sql = "SELECT type, COUNT(*) as count FROM customers WHERE deleted_at IS NULL GROUP BY type";
        $typeStats = $this->db->fetchAll($sql);
        $stats['by_type'] = array_column($typeStats, 'count', 'type');
        
        // Customers by status
        $sql = "SELECT status, COUNT(*) as count FROM customers WHERE deleted_at IS NULL GROUP BY status";
        $statusStats = $this->db->fetchAll($sql);
        $stats['by_status'] = array_column($statusStats, 'count', 'status');
        
        // Recent customers (last 30 days)
        $sql = "SELECT COUNT(*) as recent FROM customers WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) AND deleted_at IS NULL";
        $result = $this->db->fetch($sql);
        $stats['recent'] = $result['recent'];
        
        return $stats;
    }
    
    public function search($query, $limit = 10) {
        $sql = "SELECT id, first_name, last_name, mobile, email, company, type 
                FROM customers 
                WHERE deleted_at IS NULL 
                AND (first_name LIKE ? OR last_name LIKE ? OR mobile LIKE ? OR email LIKE ? OR company LIKE ?)
                ORDER BY first_name ASC, last_name ASC
                LIMIT {$limit}";
        
        $searchTerm = "%{$query}%";
        return $this->db->fetchAll($sql, [$searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm]);
    }
}