<?php
/**
 * Settings Model
 * Handles database operations for system settings
 */

class Settings {
    
    private $db;
    
    // Default settings
    private $defaults = [
        // Company settings
        'company_name' => 'شرکت من',
        'company_address' => '',
        'company_phone' => '',
        'company_email' => '',
        'company_website' => '',
        'company_logo' => '',
        
        // Invoice settings
        'invoice_prefix' => 'INV',
        'invoice_terms' => 'پرداخت ظرف 30 روز پس از تاریخ صدور فاکتور',
        'invoice_notes' => 'با تشکر از انتخاب شما',
        'tax_rate' => 0,
        
        // System settings
        'timezone' => 'Asia/Tehran',
        'date_format' => 'Y-m-d',
        'currency' => 'IRR',
        'language' => 'fa',
        
        // Email settings
        'smtp_host' => '',
        'smtp_port' => 587,
        'smtp_username' => '',
        'smtp_password' => '',
        'smtp_encryption' => 'tls',
        
        // Theme settings
        'theme_mode' => 'light',
        'primary_color' => '#3B82F6',
        'sidebar_collapsed' => 0,
        
        // Security settings
        'session_timeout' => 60,
        'max_login_attempts' => 5,
        'lockout_duration' => 15
    ];
    
    public function __construct($database) {
        $this->db = $database;
        $this->ensureDefaultsExist();
    }
    
    /**
     * Get setting value by key
     */
    public function get($key) {
        $query = "SELECT value FROM settings WHERE key_name = ?";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute([$key]);
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($result) {
            // Decode JSON value
            $decoded = json_decode($result['value'], true);
            return $decoded !== null ? $decoded : $result['value'];
        }
        
        // Return default if not found
        return $this->defaults[$key] ?? null;
    }
    
    /**
     * Set setting value by key
     */
    public function set($key, $value) {
        // Encode value to JSON
        $encodedValue = is_string($value) ? $value : json_encode($value);
        
        // Check if key exists
        $query = "SELECT COUNT(*) FROM settings WHERE key_name = ?";
        $stmt = $this->db->prepare($query);
        $stmt->execute([$key]);
        
        if ($stmt->fetchColumn() > 0) {
            // Update existing
            $query = "UPDATE settings SET value = ?, updated_at = NOW() WHERE key_name = ?";
            $stmt = $this->db->prepare($query);
            return $stmt->execute([$encodedValue, $key]);
        } else {
            // Insert new
            $query = "INSERT INTO settings (key_name, value, created_at, updated_at) VALUES (?, ?, NOW(), NOW())";
            $stmt = $this->db->prepare($query);
            return $stmt->execute([$key, $encodedValue]);
        }
    }
    
    /**
     * Get all settings
     */
    public function getAll() {
        $query = "SELECT key_name, value FROM settings";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        
        $settings = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            // Decode JSON value
            $decoded = json_decode($row['value'], true);
            $settings[$row['key_name']] = $decoded !== null ? $decoded : $row['value'];
        }
        
        // Add missing defaults
        foreach ($this->defaults as $key => $defaultValue) {
            if (!isset($settings[$key])) {
                $settings[$key] = $defaultValue;
            }
        }
        
        return $settings;
    }
    
    /**
     * Delete setting by key
     */
    public function delete($key) {
        $query = "DELETE FROM settings WHERE key_name = ?";
        
        $stmt = $this->db->prepare($query);
        return $stmt->execute([$key]);
    }
    
    /**
     * Reset settings to defaults
     */
    public function resetToDefaults() {
        $this->db->beginTransaction();
        
        try {
            // Delete all existing settings
            $query = "DELETE FROM settings";
            $stmt = $this->db->prepare($query);
            $stmt->execute();
            
            // Insert default settings
            foreach ($this->defaults as $key => $value) {
                $encodedValue = is_string($value) ? $value : json_encode($value);
                
                $query = "INSERT INTO settings (key_name, value, created_at, updated_at) VALUES (?, ?, NOW(), NOW())";
                $stmt = $this->db->prepare($query);
                $stmt->execute([$key, $encodedValue]);
            }
            
            $this->db->commit();
            return true;
            
        } catch (Exception $e) {
            $this->db->rollback();
            return false;
        }
    }
    
    /**
     * Ensure default settings exist in database
     */
    private function ensureDefaultsExist() {
        // Get existing keys
        $query = "SELECT key_name FROM settings";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        
        $existingKeys = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $existingKeys[] = $row['key_name'];
        }
        
        // Insert missing defaults
        foreach ($this->defaults as $key => $value) {
            if (!in_array($key, $existingKeys)) {
                $encodedValue = is_string($value) ? $value : json_encode($value);
                
                $query = "INSERT INTO settings (key_name, value, created_at, updated_at) VALUES (?, ?, NOW(), NOW())";
                $stmt = $this->db->prepare($query);
                $stmt->execute([$key, $encodedValue]);
            }
        }
    }
    
    /**
     * Get settings by category
     */
    public function getByCategory($category) {
        $categories = [
            'company' => [
                'company_name', 'company_address', 'company_phone', 'company_email', 
                'company_website', 'company_logo'
            ],
            'invoice' => [
                'invoice_prefix', 'invoice_terms', 'invoice_notes', 'tax_rate'
            ],
            'system' => [
                'timezone', 'date_format', 'currency', 'language'
            ],
            'email' => [
                'smtp_host', 'smtp_port', 'smtp_username', 'smtp_password', 'smtp_encryption'
            ],
            'theme' => [
                'theme_mode', 'primary_color', 'sidebar_collapsed'
            ],
            'security' => [
                'session_timeout', 'max_login_attempts', 'lockout_duration'
            ]
        ];
        
        if (!isset($categories[$category])) {
            return [];
        }
        
        $settings = [];
        foreach ($categories[$category] as $key) {
            $settings[$key] = $this->get($key);
        }
        
        return $settings;
    }
    
    /**
     * Bulk update settings
     */
    public function bulkUpdate($settings) {
        $this->db->beginTransaction();
        
        try {
            foreach ($settings as $key => $value) {
                if (!$this->set($key, $value)) {
                    throw new Exception("Failed to update setting: $key");
                }
            }
            
            $this->db->commit();
            return true;
            
        } catch (Exception $e) {
            $this->db->rollback();
            return false;
        }
    }
    
    /**
     * Get settings as key-value array for specific keys
     */
    public function getMultiple($keys) {
        $settings = [];
        
        foreach ($keys as $key) {
            $settings[$key] = $this->get($key);
        }
        
        return $settings;
    }
}