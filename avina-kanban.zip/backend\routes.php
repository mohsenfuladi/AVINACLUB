<?php
/**
 * API Routes Configuration
 * Defines all API endpoints and their corresponding controllers
 */

require_once 'helpers/response.php';
require_once 'helpers/security.php';
require_once 'middleware/auth.php';
require_once 'middleware/cors.php';

// Enable CORS
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Get request URI and method
$requestUri = $_SERVER['REQUEST_URI'];
$requestMethod = $_SERVER['REQUEST_METHOD'];

// Remove query string and base path
$basePath = '/api';
$uri = parse_url($requestUri, PHP_URL_PATH);
$uri = str_replace($basePath, '', $uri);
$uri = trim($uri, '/');

// Split URI into segments
$segments = explode('/', $uri);

// Get database connection
require_once 'config/database.php';
$database = new Database();
$db = $database->getConnection();

// Define routes
$routes = [
    // Authentication routes
    'auth/login' => [
        'POST' => 'AuthController@login',
        'public' => true
    ],
    'auth/register' => [
        'POST' => 'AuthController@register',
        'public' => true
    ],
    'auth/logout' => [
        'POST' => 'AuthController@logout',
        'public' => false
    ],
    'auth/profile' => [
        'GET' => 'AuthController@profile',
        'PUT' => 'AuthController@updateProfile',
        'public' => false
    ],
    'auth/change-password' => [
        'POST' => 'AuthController@changePassword',
        'public' => false
    ],
    
    // User management routes
    'users' => [
        'GET' => 'UserController@list',
        'POST' => 'UserController@create',
        'public' => false
    ],
    'users/{id}' => [
        'GET' => 'UserController@view',
        'PUT' => 'UserController@update',
        'DELETE' => 'UserController@delete',
        'public' => false
    ],
    
    // Customer management routes
    'customers' => [
        'GET' => 'CustomerController@list',
        'POST' => 'CustomerController@create',
        'public' => false
    ],
    'customers/{id}' => [
        'GET' => 'CustomerController@view',
        'PUT' => 'CustomerController@update',
        'DELETE' => 'CustomerController@delete',
        'public' => false
    ],

    // Contact management routes
    'contacts' => [
        'GET' => 'ContactController@list',
        'POST' => 'ContactController@create',
        'public' => false
    ],
    'contacts/{id}' => [
        'GET' => 'ContactController@view',
        'PUT' => 'ContactController@update',
        'DELETE' => 'ContactController@delete',
        'public' => false
    ],
    
    // Task management routes
    'tasks' => [
        'GET' => 'TaskController@list',
        'POST' => 'TaskController@create',
        'public' => false
    ],
    'tasks/{id}' => [
        'GET' => 'TaskController@view',
        'PUT' => 'TaskController@update',
        'DELETE' => 'TaskController@delete',
        'public' => false
    ],
    'tasks/{id}/assign' => [
        'POST' => 'TaskController@assign',
        'public' => false
    ],
    
    // Column management routes
    'columns' => [
        'GET' => 'ColumnController@list',
        'POST' => 'ColumnController@create',
        'public' => false
    ],
    'columns/{id}' => [
        'PUT' => 'ColumnController@update',
        'DELETE' => 'ColumnController@delete',
        'public' => false
    ],
    
    // Invoice management routes
    'invoices' => [
        'GET' => 'InvoiceController@list',
        'POST' => 'InvoiceController@create',
        'public' => false
    ],
    'invoices/{id}' => [
        'GET' => 'InvoiceController@view',
        'PUT' => 'InvoiceController@update',
        'DELETE' => 'InvoiceController@delete',
        'public' => false
    ],
    'invoices/statistics' => [
        'GET' => 'InvoiceController@statistics',
        'public' => false
    ],
    
    // Settings routes
    'settings' => [
        'GET' => 'SettingsController@get',
        'PUT' => 'SettingsController@update',
        'public' => false
    ],
    'settings/{key}' => [
        'GET' => 'SettingsController@getByKey',
        'PUT' => 'SettingsController@setByKey',
        'public' => false
    ],
    'settings/reset' => [
        'POST' => 'SettingsController@resetToDefaults',
        'public' => false
    ],
    'settings/export' => [
        'GET' => 'SettingsController@export',
        'public' => false
    ],
    'settings/import' => [
        'POST' => 'SettingsController@import',
        'public' => false
    ],
    
    // Backup routes
    'backups' => [
        'GET' => 'BackupController@list',
        'POST' => 'BackupController@create',
        'public' => false
    ],
    'backups/{id}' => [
        'DELETE' => 'BackupController@delete',
        'public' => false
    ],
    'backups/{id}/download' => [
        'GET' => 'BackupController@download',
        'public' => false
    ],
    'backups/{id}/restore' => [
        'POST' => 'BackupController@restore',
        'public' => false
    ],
    'backups/upload' => [
        'POST' => 'BackupController@upload',
        'public' => false
    ],
    'backups/schedule' => [
        'GET' => 'BackupController@getSchedule',
        'PUT' => 'BackupController@schedule',
        'public' => false
    ]
    ,
    // Services routes (SMS)
    'services/sms' => [
        'POST' => 'ServiceController@sendSms',
        // Marked public to support existing session-based auth flow; adjust later if JWT is enabled client-side
        'public' => true
    ]
];

// Function to match route
function matchRoute($segments, $route) {
    $routeSegments = explode('/', $route);
    
    if (count($segments) !== count($routeSegments)) {
        return false;
    }
    
    $params = [];
    
    for ($i = 0; $i < count($segments); $i++) {
        if (preg_match('/^{(.+)}$/', $routeSegments[$i], $matches)) {
            // This is a parameter
            $params[$matches[1]] = $segments[$i];
        } elseif ($segments[$i] !== $routeSegments[$i]) {
            // This segment doesn't match
            return false;
        }
    }
    
    return $params;
}

// Find matching route
$matchedRoute = null;
$routeParams = [];

foreach ($routes as $route => $methods) {
    $params = matchRoute($segments, $route);
    if ($params !== false) {
        $matchedRoute = $route;
        $routeParams = $params;
        break;
    }
}

// Check if route was found
if (!$matchedRoute) {
    Response::error('مسیر درخواست یافت نشد', 404);
}

// Check if method is allowed
if (!isset($routes[$matchedRoute][$requestMethod])) {
    Response::error('متد درخواست مجاز نیست', 405);
}

// Check authentication if required
if (!isset($routes[$matchedRoute]['public']) || !$routes[$matchedRoute]['public']) {
    $auth = new AuthMiddleware();
    $auth->authenticate();
}

// Parse controller and method
$controllerMethod = $routes[$matchedRoute][$requestMethod];
list($controllerName, $methodName) = explode('@', $controllerMethod);

// Include controller file
$controllerFile = "controllers/{$controllerName}.php";
if (!file_exists($controllerFile)) {
    Response::error('کنترلر یافت نشد', 500);
}

require_once $controllerFile;

// Create controller instance
$controllerClass = str_replace('Controller', '', $controllerName) . 'Controller';
if (!class_exists($controllerClass)) {
    Response::error('کلاس کنترلر یافت نشد', 500);
}

$controller = new $controllerClass($db);

// Check if method exists
if (!method_exists($controller, $methodName)) {
    Response::error('متد کنترلر یافت نشد', 500);
}

// Call controller method
try {
    // Pass route parameters to method
    if (!empty($routeParams)) {
        $result = call_user_func_array([$controller, $methodName], array_values($routeParams));
    } else {
        $result = $controller->$methodName();
    }
} catch (Exception $e) {
    Response::error('خطای سرور: ' . $e->getMessage(), 500);
}