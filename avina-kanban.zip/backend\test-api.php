<?php
// Simple PHP server for testing
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Simple test endpoints
$endpoint = $_GET['endpoint'] ?? '';
$action = $_GET['action'] ?? '';

switch ($endpoint) {
    case 'system':
        if ($action === 'status') {
            echo json_encode([
                'installed' => true,
                'settings' => [
                    'theme' => 'light',
                    'accentColor' => '#3b82f6',
                    'companyName' => 'آوینا'
                ],
                'dbConfig' => null
            ]);
        }
        break;
        
    case 'auth':
        if ($action === 'login') {
            $data = json_decode(file_get_contents('php://input'), true);
            if ($data['username'] === 'admin' && $data['password'] === 'admin') {
                echo json_encode([
                    'success' => true,
                    'user' => [
                        'id' => '1',
                        'username' => 'admin',
                        'role' => 'admin',
                        'name' => 'مدیر سیستم'
                    ]
                ]);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'نام کاربری یا رمز عبور اشتباه است'
                ]);
            }
        }
        break;
        
    case 'data':
        if ($action === 'load') {
            echo json_encode([
                'data' => [
                    'settings' => ['theme' => 'light', 'accentColor' => '#3b82f6'],
                    'users' => [],
                    'tasks' => [],
                    'columns' => [
                        ['id' => 'col-1', 'title' => 'در انتظار', 'order' => 1],
                        ['id' => 'col-2', 'title' => 'در حال انجام', 'order' => 2],
                        ['id' => 'col-3', 'title' => 'تکمیل شده', 'order' => 3]
                    ],
                    'contacts' => [],
                    'submissions' => [],
                    'products' => [],
                    'customers' => [],
                    'invoices' => [],
                    'leads' => [],
                    'expenses' => [],
                    'cheques' => [],
                    'avinaData' => [],
                    'receptions' => []
                ]
            ]);
        }
        break;
        
    default:
        echo json_encode([
            'success' => false,
            'message' => 'Endpoint نامعتبر است'
        ]);
}
?>