<?php
/**
 * Kanban Column Model
 * Handles all database operations related to kanban columns
 */

class Column {
    
    private $db;
    
    public function __construct($database) {
        $this->db = $database;
    }
    
    public function findById($id) {
        $sql = "SELECT * FROM kanban_columns WHERE id = ? AND deleted_at IS NULL";
        return $this->db->fetch($sql, [$id]);
    }
    
    public function create($data) {
        $sql = "INSERT INTO kanban_columns (name, color, position, is_default, created_at) VALUES (?, ?, ?, ?, ?)";
        
        $params = [
            $data['name'],
            $data['color'] ?? '#6B7280',
            $data['position'] ?? 0,
            $data['is_default'] ?? 0,
            date('Y-m-d H:i:s')
        ];
        
        return $this->db->insert($sql, $params);
    }
    
    public function update($id, $data) {
        $fields = [];
        $params = [];
        
        foreach ($data as $key => $value) {
            $fields[] = "{$key} = ?";
            $params[] = $value;
        }
        
        $params[] = $id;
        
        $sql = "UPDATE kanban_columns SET " . implode(', ', $fields) . " WHERE id = ? AND deleted_at IS NULL";
        
        return $this->db->execute($sql, $params);
    }
    
    public function delete($id) {
        $sql = "UPDATE kanban_columns SET deleted_at = ? WHERE id = ? AND deleted_at IS NULL";
        return $this->db->execute($sql, [date('Y-m-d H:i:s'), $id]);
    }
    
    public function list($includeDeleted = false) {
        $where = $includeDeleted ? "" : "WHERE deleted_at IS NULL";
        $sql = "SELECT * FROM kanban_columns {$where} ORDER BY position ASC, created_at ASC";
        return $this->db->fetchAll($sql);
    }
    
    public function getDefaultColumns() {
        return [
            [
                'name' => 'در انتظار',
                'color' => '#F59E0B',
                'position' => 1,
                'is_default' => 1
            ],
            [
                'name' => 'در حال انجام',
                'color' => '#3B82F6',
                'position' => 2,
                'is_default' => 1
            ],
            [
                'name' => 'تکمیل شده',
                'color' => '#10B981',
                'position' => 3,
                'is_default' => 1
            ]
        ];
    }
    
    public function createDefaultColumns() {
        $defaultColumns = $this->getDefaultColumns();
        
        foreach ($defaultColumns as $column) {
            $this->create($column);
        }
        
        return true;
    }
    
    public function updatePosition($id, $position) {
        $sql = "UPDATE kanban_columns SET position = ? WHERE id = ? AND deleted_at IS NULL";
        return $this->db->execute($sql, [$position, $id]);
    }
    
    public function reorderPositions() {
        $columns = $this->list();
        
        foreach ($columns as $index => $column) {
            $this->updatePosition($column['id'], $index + 1);
        }
        
        return true;
    }
    
    public function getTaskCount($columnId) {
        $sql = "SELECT COUNT(*) as count FROM kanban_tasks WHERE column_id = ? AND deleted_at IS NULL";
        $result = $this->db->fetch($sql, [$columnId]);
        return $result['count'];
    }
    
    public function getColumnWithTasks($columnId) {
        $column = $this->findById($columnId);
        if (!$column) {
            return null;
        }
        
        // Get tasks for this column
        $taskModel = new Task($this->db);
        $column['tasks'] = $taskModel->getByColumn($columnId);
        
        return $column;
    }
    
    public function getAllColumnsWithTasks() {
        $columns = $this->list();
        
        $taskModel = new Task($this->db);
        foreach ($columns as &$column) {
            $column['tasks'] = $taskModel->getByColumn($column['id']);
            $column['task_count'] = count($column['tasks']);
        }
        
        return $columns;
    }
}