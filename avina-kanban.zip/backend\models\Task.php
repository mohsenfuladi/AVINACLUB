<?php
/**
 * Task Model
 * Handles all database operations related to kanban tasks
 */

class Task {
    
    private $db;
    
    public function __construct($database) {
        $this->db = $database;
    }
    
    public function findById($id) {
        $sql = "SELECT t.*, c.first_name as customer_first_name, c.last_name as customer_last_name, 
                       u.full_name as assigned_to_name, u.avatar as assigned_to_avatar
                FROM kanban_tasks t
                LEFT JOIN customers c ON t.customer_id = c.id
                LEFT JOIN users u ON t.assigned_to = u.id
                WHERE t.id = ? AND t.deleted_at IS NULL";
        return $this->db->fetch($sql, [$id]);
    }
    
    public function create($data) {
        $sql = "INSERT INTO kanban_tasks (
                    title, description, column_id, priority, status, assigned_to,
                    customer_id, due_date, tags, attachments, created_by, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $params = [
            $data['title'],
            $data['description'] ?? null,
            $data['column_id'],
            $data['priority'] ?? 'medium',
            $data['status'] ?? 'pending',
            $data['assigned_to'] ?? null,
            $data['customer_id'] ?? null,
            $data['due_date'] ?? null,
            isset($data['tags']) ? json_encode($data['tags']) : null,
            isset($data['attachments']) ? json_encode($data['attachments']) : null,
            $data['created_by'],
            date('Y-m-d H:i:s')
        ];
        
        return $this->db->insert($sql, $params);
    }
    
    public function update($id, $data) {
        $fields = [];
        $params = [];
        
        foreach ($data as $key => $value) {
            if ($key === 'tags' || $key === 'attachments') {
                $fields[] = "{$key} = ?";
                $params[] = json_encode($value);
            } else {
                $fields[] = "{$key} = ?";
                $params[] = $value;
            }
        }
        
        $params[] = $id;
        
        $sql = "UPDATE kanban_tasks SET " . implode(', ', $fields) . " WHERE id = ? AND deleted_at IS NULL";
        
        return $this->db->execute($sql, $params);
    }
    
    public function delete($id) {
        $sql = "UPDATE kanban_tasks SET deleted_at = ? WHERE id = ? AND deleted_at IS NULL";
        return $this->db->execute($sql, [date('Y-m-d H:i:s'), $id]);
    }
    
    public function list($filters = [], $page = 1, $perPage = 20) {
        $where = "WHERE t.deleted_at IS NULL";
        $params = [];
        
        if (isset($filters['column_id'])) {
            $where .= " AND t.column_id = ?";
            $params[] = $filters['column_id'];
        }
        
        if (isset($filters['assigned_to'])) {
            $where .= " AND t.assigned_to = ?";
            $params[] = $filters['assigned_to'];
        }
        
        if (isset($filters['customer_id'])) {
            $where .= " AND t.customer_id = ?";
            $params[] = $filters['customer_id'];
        }
        
        if (isset($filters['priority'])) {
            $where .= " AND t.priority = ?";
            $params[] = $filters['priority'];
        }
        
        if (isset($filters['status'])) {
            $where .= " AND t.status = ?";
            $params[] = $filters['status'];
        }
        
        if (isset($filters['search'])) {
            $where .= " AND (t.title LIKE ? OR t.description LIKE ?)";
            $searchTerm = "%{$filters['search']}%";
            $params[] = $searchTerm;
            $params[] = $searchTerm;
        }
        
        // Get total count
        $countSql = "SELECT COUNT(*) as total FROM kanban_tasks t {$where}";
        $totalResult = $this->db->fetch($countSql, $params);
        $total = $totalResult['total'];
        
        // Get paginated results
        $offset = ($page - 1) * $perPage;
        $sql = "SELECT t.*, c.first_name as customer_first_name, c.last_name as customer_last_name,
                       u.full_name as assigned_to_name, u.avatar as assigned_to_avatar,
                       col.name as column_name, col.color as column_color
                FROM kanban_tasks t
                LEFT JOIN customers c ON t.customer_id = c.id
                LEFT JOIN users u ON t.assigned_to = u.id
                LEFT JOIN kanban_columns col ON t.column_id = col.id
                {$where}
                ORDER BY t.priority DESC, t.created_at DESC
                LIMIT {$perPage} OFFSET {$offset}";
        
        $tasks = $this->db->fetchAll($sql, $params);
        
        // Decode JSON fields
        foreach ($tasks as &$task) {
            if ($task['tags']) {
                $task['tags'] = json_decode($task['tags'], true);
            }
            if ($task['attachments']) {
                $task['attachments'] = json_decode($task['attachments'], true);
            }
        }
        
        return [
            'data' => $tasks,
            'total' => $total,
            'page' => $page,
            'per_page' => $perPage,
            'total_pages' => ceil($total / $perPage)
        ];
    }
    
    public function moveToColumn($taskId, $columnId) {
        $sql = "UPDATE kanban_tasks SET column_id = ?, updated_at = ? WHERE id = ? AND deleted_at IS NULL";
        return $this->db->execute($sql, [$columnId, date('Y-m-d H:i:s'), $taskId]);
    }
    
    public function assignToUser($taskId, $userId) {
        $sql = "UPDATE kanban_tasks SET assigned_to = ?, updated_at = ? WHERE id = ? AND deleted_at IS NULL";
        return $this->db->execute($sql, [$userId, date('Y-m-d H:i:s'), $taskId]);
    }
    
    public function updateStatus($taskId, $status) {
        $sql = "UPDATE kanban_tasks SET status = ?, updated_at = ? WHERE id = ? AND deleted_at IS NULL";
        return $this->db->execute($sql, [$status, date('Y-m-d H:i:s'), $taskId]);
    }
    
    public function getByColumn($columnId) {
        $sql = "SELECT t.*, c.first_name as customer_first_name, c.last_name as customer_last_name,
                       u.full_name as assigned_to_name, u.avatar as assigned_to_avatar
                FROM kanban_tasks t
                LEFT JOIN customers c ON t.customer_id = c.id
                LEFT JOIN users u ON t.assigned_to = u.id
                WHERE t.column_id = ? AND t.deleted_at IS NULL
                ORDER BY t.priority DESC, t.created_at ASC";
        
        $tasks = $this->db->fetchAll($sql, [$columnId]);
        
        // Decode JSON fields
        foreach ($tasks as &$task) {
            if ($task['tags']) {
                $task['tags'] = json_decode($task['tags'], true);
            }
            if ($task['attachments']) {
                $task['attachments'] = json_decode($task['attachments'], true);
            }
        }
        
        return $tasks;
    }
    
    public function getStats() {
        $stats = [];
        
        // Total tasks
        $sql = "SELECT COUNT(*) as total FROM kanban_tasks WHERE deleted_at IS NULL";
        $result = $this->db->fetch($sql);
        $stats['total'] = $result['total'];
        
        // Tasks by status
        $sql = "SELECT status, COUNT(*) as count FROM kanban_tasks WHERE deleted_at IS NULL GROUP BY status";
        $statusStats = $this->db->fetchAll($sql);
        $stats['by_status'] = array_column($statusStats, 'count', 'status');
        
        // Tasks by priority
        $sql = "SELECT priority, COUNT(*) as count FROM kanban_tasks WHERE deleted_at IS NULL GROUP BY priority";
        $priorityStats = $this->db->fetchAll($sql);
        $stats['by_priority'] = array_column($priorityStats, 'count', 'priority');
        
        // Overdue tasks
        $sql = "SELECT COUNT(*) as overdue FROM kanban_tasks WHERE due_date < NOW() AND status != 'completed' AND deleted_at IS NULL";
        $result = $this->db->fetch($sql);
        $stats['overdue'] = $result['overdue'];
        
        // Recent tasks (last 7 days)
        $sql = "SELECT COUNT(*) as recent FROM kanban_tasks WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) AND deleted_at IS NULL";
        $result = $this->db->fetch($sql);
        $stats['recent'] = $result['recent'];
        
        return $stats;
    }
    
    public function addComment($taskId, $userId, $comment) {
        $sql = "INSERT INTO task_comments (task_id, user_id, comment, created_at) VALUES (?, ?, ?, ?)";
        return $this->db->insert($sql, [$taskId, $userId, $comment, date('Y-m-d H:i:s')]);
    }
    
    public function getComments($taskId) {
        $sql = "SELECT c.*, u.full_name, u.avatar
                FROM task_comments c
                JOIN users u ON c.user_id = u.id
                WHERE c.task_id = ?
                ORDER BY c.created_at ASC";
        
        return $this->db->fetchAll($sql, [$taskId]);
    }
}